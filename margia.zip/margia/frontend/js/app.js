(function () {
  const { el, mensaje } = UI;
  let meta = null;
  let empresas = [];
  let empresaId = null;
  let pantallaActual = 'dashboard';

  const GRUPOS_MENU = [
    { titulo: 'Panel', items: ['dashboard'] },
    { titulo: 'Datos generales', items: ['empresas', 'periodos', 'unidades_medida', 'centros_costo', 'productos'] },
    { titulo: 'Costeo directo', items: ['materias_primas', 'trabajadores', 'bases_aplicacion', 'cif_conceptos', 'hoja_costo', 'historico'] },
    { titulo: 'Producción', items: ['ordenes', 'inventario'] },
    { titulo: 'Reportes', items: ['reportes'] },
    { titulo: 'Administración', items: ['usuarios', 'bitacora', 'respaldo'] },
  ];
  const ETIQUETAS_EXTRA = {
    dashboard: 'Dashboard', hoja_costo: 'Hoja de costo', ordenes: 'Órdenes de producción',
    reportes: 'Reportes', usuarios: 'Usuarios', bitacora: 'Actividad',
    inventario: 'Inventario', respaldo: 'Respaldo', historico: 'Histórico de costos', bases_aplicacion: 'Bases de aplicación',
  };

  const SOLO_ADMIN = ['usuarios', 'bitacora', 'respaldo'];

  // Red de seguridad: ningún fallo debe pasar en silencio. Si una acción falla y su código no lo manejó, se le explica a la persona.
  window.addEventListener('unhandledrejection', (ev) => {
    ev.preventDefault();
    const r = ev.reason || {};
    if (r.status === 401) {
      UI.mensaje(r.mensaje || 'Tu sesión terminó. Inicia sesión de nuevo.', 'error');
      setTimeout(() => location.reload(), 1600);
      return;
    }
    console.error(r);
    UI.mensaje(typeof r.mensaje === 'string' ? r.mensaje : null, 'error');
  });
  window.addEventListener('error', (ev) => {
    console.error(ev.error || ev.message);
    UI.mensaje(null, 'error');
  });

  async function iniciar() {
    if (!Api.estaConectado()) { mostrarLogin(); return; }
    await cargarMeta();
    mostrarApp();
  }

  function mostrarLogin() {
    document.getElementById('pantalla-login').classList.remove('oculto');
    document.getElementById('app').classList.add('oculto');
  }

  document.getElementById('form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const usuario = document.getElementById('login-usuario').value.trim();
    const clave = document.getElementById('login-clave').value;
    const errorEl = document.getElementById('login-error');
    errorEl.classList.add('oculto');
    try {
      await Api.iniciarSesion(usuario, clave);
      await cargarMeta();
      mostrarApp();
    } catch (e2) {
      errorEl.textContent = e2.mensaje;
      errorEl.classList.remove('oculto');
    }
  });

  document.getElementById('btn-clave').addEventListener('click', () => ModuloSistema.abrirCambioClave(false));

  document.getElementById('btn-salir').addEventListener('click', async () => {
    await Api.cerrarSesion();
    location.reload();
  });

  async function cargarMeta() {
    meta = await Api.get('meta');
    empresas = await Api.get('empresas');
    const guardada = Number(localStorage.getItem('empresa_id'));
    empresaId = empresas.find((e) => e.id === guardada) ? guardada : (empresas[0] ? empresas[0].id : null);
  }

  function mostrarApp() {
    document.getElementById('pantalla-login').classList.add('oculto');
    document.getElementById('app').classList.remove('oculto');
    document.getElementById('usuario-actual').textContent = meta.usuario.nombre;
    document.getElementById('lateral-pie').textContent = `Margia ${meta.version || ''} · local y sin internet`;
    document.getElementById('usuario-rol').textContent = meta.usuario.rol === 'administrador' ? 'Administrador' : 'Estudiante';
    document.getElementById('avatar').textContent = meta.usuario.nombre.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');
    dibujarMarca();
    dibujarSelectorEmpresa();
    dibujarMenu();
    irA(pantallaActual);
    if (meta.usuario.clave_inicial && !sessionStorage.getItem('aviso_clave_mostrado')) {
      sessionStorage.setItem('aviso_clave_mostrado', '1');
      setTimeout(() => ModuloSistema.abrirCambioClave(true), 400);
    }
  }

  function avisoClaveInicial() {
    if (!meta.usuario.clave_inicial) return null;
    const aviso = el('div', { class: 'aviso aviso-alerta', id: 'aviso-clave' }, [
      el('span', {}, 'Sigues usando la contraseña de fábrica, que cualquiera conoce. '),
      el('button', { class: 'enlace', onclick: () => ModuloSistema.abrirCambioClave(true) }, 'Cámbiala ahora'),
    ]);
    return aviso;
  }

  function empresaActual() {
    return empresas.find((e) => e.id === empresaId) || null;
  }

  const TEMA_DEFECTO = { acento: '#0f766e', lateral: '#ffffff', fondo: '#f6f7f9' };

  function esOscuro(hex) {
    const h = hex.replace('#', '');
    const [r, g, b] = [0, 2, 4].map((i) => parseInt(h.substr(i, 2), 16) / 255)
      .map((c) => (c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)));
    return 0.2126 * r + 0.7152 * g + 0.0722 * b < 0.4;
  }

  function aplicarTema(tema) {
    const t = Object.assign({}, TEMA_DEFECTO, tema || {});
    const v = {
      '--acento': t.acento, '--acento-osc': UI.oscurecer(t.acento, 0.2), '--acento-suave': UI.aclarar(t.acento, 0.9),
      '--lateral': t.lateral, '--fondo': t.fondo,
    };
    document.getElementById('lateral').classList.toggle('oscuro', esOscuro(t.lateral));
    if (esOscuro(t.lateral)) {  // menú oscuro: texto claro
      Object.assign(v, { '--lateral-texto': 'rgba(255,255,255,.74)', '--lateral-fuerte': '#ffffff', '--lateral-titulo': 'rgba(255,255,255,.42)',
        '--lateral-hover': 'rgba(255,255,255,.07)', '--lateral-activo': 'rgba(255,255,255,.12)', '--lateral-activo-texto': '#ffffff',
        '--lateral-activo-borde': 'rgba(255,255,255,.16)',
        '--lateral-linea': 'rgba(255,255,255,.09)' });
    } else {                    // menú claro: texto oscuro y activo con el color principal
      Object.assign(v, { '--lateral-texto': '#4b5563', '--lateral-fuerte': '#111827', '--lateral-titulo': '#9ca3af',
        '--lateral-hover': UI.oscurecer(t.lateral, 0.035), '--lateral-activo': '#ffffff', '--lateral-activo-texto': '#111827',
        '--lateral-activo-borde': UI.aclarar(t.acento, 0.72),
        '--lateral-linea': UI.oscurecer(t.lateral, 0.07) });
    }
    const raiz = document.documentElement.style;
    for (const [k, val] of Object.entries(v)) raiz.setProperty(k, val);
  }

  function dibujarMarca() {
    const icono = document.getElementById('lateral-icono');
    const emp = empresaActual();
    icono.innerHTML = '';
    icono.classList.toggle('con-logo', !!(emp && emp.logo));
    if (emp && emp.logo) icono.appendChild(el('img', { src: emp.logo, alt: '' }));
    else icono.textContent = emp ? emp.razon_social.trim().charAt(0).toUpperCase() : '·';
    document.title = emp ? `${emp.razon_social} · Margia` : 'Margia — Costeo estándar';
    aplicarTema(emp ? emp.tema : null);
  }

  function dibujarSelectorEmpresa() {
    const sel = document.getElementById('sel-empresa');
    sel.innerHTML = '';
    if (empresas.length === 0) {
      sel.appendChild(el('option', {}, 'Sin empresas'));
      sel.disabled = true;
      return;
    }
    sel.disabled = false;
    for (const emp of empresas) sel.appendChild(el('option', { value: emp.id, selected: emp.id === empresaId ? 'selected' : null }, emp.razon_social));
    sel.onchange = () => {
      empresaId = Number(sel.value);
      localStorage.setItem('empresa_id', empresaId);
      dibujarMarca();
      irA(pantallaActual);
    };
  }

  // Íconos de línea (estilo Lucide, dibujados aquí para no depender de internet)
  const ICONOS = {
    dashboard: 'M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z',
    empresas: 'M3 21h18M5 21V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v16M15 9h4a2 2 0 0 1 2 2v10M9 7h2M9 11h2M9 15h2',
    periodos: 'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
    unidades_medida: 'M21.3 15.3 8.7 2.7a1 1 0 0 0-1.4 0L2.7 7.3a1 1 0 0 0 0 1.4l12.6 12.6a1 1 0 0 0 1.4 0l4.6-4.6a1 1 0 0 0 0-1.4zM7.5 10.5l2-2M10.5 13.5l2-2M13.5 16.5l2-2',
    centros_costo: 'M12 3v6M5 21v-4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v4M12 15v6M9 3h6v6H9z',
    productos: 'M21 8 12 3 3 8v8l9 5 9-5zM3 8l9 5 9-5M12 13v8',
    materias_primas: 'M12 2 2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
    trabajadores: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
    bases_aplicacion: 'M19 5 5 19M6.5 9a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM17.5 20a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
    cif_conceptos: 'M12 14l4-4M3.3 19a10 10 0 1 1 17.4 0',
    hoja_costo: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h5',
    historico: 'M3 3v18h18M7 15l4-4 3 3 6-6',
    ordenes: 'M2 20h20M4 20V10l5 3V10l5 3V6l6 4v10',
    inventario: 'M3 9h18v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zM3 9l2-5h14l2 5M10 13h4',
    reportes: 'M3 3v18h18M8 17v-5M13 17V8M18 17v-9',
    usuarios: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
    bitacora: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
    cierre: 'M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11',
    excel: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13l4 5M12 13l-4 5',
    respaldo: 'M12 3c4.97 0 9 1.34 9 3v12c0 1.66-4.03 3-9 3s-9-1.34-9-3V6c0-1.66 4.03-3 9-3zM3 6c0 1.66 4.03 3 9 3s9-1.34 9-3M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3',
  };
  const TONOS = {
    dashboard: '#0d9488', empresas: '#2563eb', periodos: '#db2777', unidades_medida: '#d97706', centros_costo: '#7c3aed',
    productos: '#ea580c', materias_primas: '#e11d48', trabajadores: '#059669', bases_aplicacion: '#0891b2', cif_conceptos: '#dc6803',
    hoja_costo: '#4f46e5', historico: '#0284c7', ordenes: '#16a34a', inventario: '#ca8a04', reportes: '#9333ea',
    usuarios: '#475467', bitacora: '#667085', respaldo: '#0f766e', cierre: '#16a34a', excel: '#16a34a',
  };
  // Cuadro de color con el ícono de cada opción (variantes para menú claro y oscuro)
  function tile(item) {
    const tono = TONOS[item] || '#667085';
    const t = el('span', { class: 'tile-icono' }, icono(item));
    t.style.setProperty('--tono', tono);
    t.style.setProperty('--tono-suave', UI.aclarar(tono, 0.88));
    t.style.setProperty('--tono-claro', UI.aclarar(tono, 0.45));
    t.style.setProperty('--tono-oscuro', tono + '40');
    return t;
  }

  function icono(item) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('class', 'icono-menu');
    svg.setAttribute('aria-hidden', 'true');
    const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    p.setAttribute('d', ICONOS[item] || ICONOS.dashboard);
    svg.appendChild(p);
    return svg;
  }

  function dibujarMenu() {
    const menu = document.getElementById('menu');
    menu.innerHTML = '';
    for (const grupo of GRUPOS_MENU) {
      const visibles = grupo.items.filter((item) => !SOLO_ADMIN.includes(item) || meta.usuario.rol === 'administrador');
      if (visibles.length === 0) continue;
      menu.appendChild(el('div', { class: 'menu-titulo' }, grupo.titulo));
      for (const item of visibles) {
        const etiqueta = ETIQUETAS_EXTRA[item] || (meta.entidades[item] ? meta.entidades[item].titulo : item);
        const btn = el('button', { 'data-item': item, onclick: () => irA(item), title: etiqueta }, [tile(item), el('span', {}, etiqueta)]);
        menu.appendChild(btn);
      }
    }
  }

  async function irA(item) {
    pantallaActual = item;
    document.querySelectorAll('#menu button').forEach((b) => b.classList.toggle('activo', b.dataset.item === item));
    const cont = document.getElementById('contenido');
    cont.innerHTML = '';
    try {
      if (item === 'usuarios') await ModuloUsuarios.render(cont, meta);
      else if (item === 'bitacora') await ModuloUsuarios.renderBitacora(cont);
      else if (item === 'hoja_costo') await ModuloCosteo.render(cont, meta, empresaId);
      else if (item === 'dashboard') await ModuloDashboard.render(cont, meta, empresaId);
      else if (item === 'ordenes') await ModuloProduccion.render(cont, meta, empresaId);
      else if (item === 'reportes') await ModuloReportes.render(cont, meta, empresaId);
      else if (item === 'inventario') await ModuloInventario.render(cont, meta, empresaId);
      else if (item === 'historico') await ModuloHistorico.render(cont, meta, empresaId);
      else if (item === 'respaldo') await ModuloSistema.renderRespaldo(cont);
      else await ModuloEntidad.render(cont, item, meta, empresaId);
      if (pantallaActual === item) {
        const aviso = avisoClaveInicial();
        if (aviso) cont.prepend(aviso);
      }
      if (item === 'empresas') {
        const nuevas = await Api.get('empresas');
        if (JSON.stringify(nuevas) !== JSON.stringify(empresas)) {
          empresas = nuevas;
          if (!empresas.find((e) => e.id === empresaId)) empresaId = empresas[0] ? empresas[0].id : null;
          dibujarSelectorEmpresa();
          dibujarMarca();
        }
      }
    } catch (e) {
      cont.appendChild(el('div', { class: 'vacio' }, e.mensaje));
    }
  }

  window.App = {
    async refrescarMarca() {
      empresas = await Api.get('empresas');
      dibujarSelectorEmpresa();
      dibujarMarca();
    },
    recargar() { irA(pantallaActual); },
    irA(item) { window.scrollTo(0, 0); return irA(item); },
    icono,
    tile,
    claveCambiada() { if (meta) meta.usuario.clave_inicial = false; },
  };

  // Mantiene alineados los encabezados numéricos aunque las tablas se redibujen (búsquedas, altas, bajas).
  new MutationObserver(() => UI.alinearEncabezados(document.getElementById('contenido')))
    .observe(document.getElementById('contenido'), { childList: true, subtree: true });

  iniciar();
})();
