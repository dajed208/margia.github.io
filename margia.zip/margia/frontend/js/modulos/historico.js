/* Histórico del costo estándar: congelar el costo de cada producto al cierre de un periodo y comparar periodos. */
const ModuloHistorico = (() => {
  const { el, mensaje, confirmar, moneda } = UI;

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    if (!empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa en el menú lateral para ver su histórico.'));
      return;
    }
    const puede = UI.puedeEscribir(meta, 'productos');
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Histórico del costo estándar'),
        el('p', { class: 'mod-desc' }, 'Guarda el costo estándar de todos los productos al cerrar cada periodo. Queda congelado: aunque después cambien recetas, costos o CIF, podrás ver cómo evolucionó.')]),
    ]));

    const [periodos, h] = await Promise.all([Api.get(`periodos?empresa_id=${empresaId}`), Api.get(`historico-costos?empresa_id=${empresaId}`)]);

    if (puede) {
      if (periodos.length === 0) {
        cont.appendChild(el('div', { class: 'aviso aviso-info' }, 'Crea un periodo contable en «Periodos contables» para poder guardar su costo estándar.'));
      } else {
        const guardados = new Set(h.periodos.map((p) => p.id));
        const sel = el('select', {}, periodos.map((p) => el('option', { value: p.id }, p.nombre + (guardados.has(p.id) ? ' (ya guardado)' : ''))));
        const btn = el('button', { class: 'primario' }, 'Guardar costo estándar');
        btn.addEventListener('click', () => {
          const per = periodos.find((p) => p.id === Number(sel.value));
          const texto = guardados.has(per.id)
            ? `«${per.nombre}» ya tiene un costo guardado. ¿Reemplazarlo por el costo estándar actual de todos los productos?`
            : `¿Guardar el costo estándar actual de todos los productos como el de «${per.nombre}»?`;
          confirmar(texto, async () => {
            try {
              const r = await Api.post('historico-costos', { periodo_id: per.id, empresa_id: empresaId });
              mensaje(`Costo de ${r.productos} producto${r.productos === 1 ? '' : 's'} guardado para ${r.periodo}.`);
              window.App.recargar();
            } catch (e) { mensaje(e.mensaje, 'error'); }
          }, guardados.has(per.id) ? 'Reemplazar' : 'Guardar');
        });
        cont.appendChild(el('div', { class: 'panel' }, [
          el('h3', {}, 'Guardar el cierre de un periodo'),
          el('p', { class: 'mod-desc', style: 'margin-bottom:.8em' }, 'Se calcula con la receta, los costos y el CIF vigentes hoy, usando las unidades presupuestadas del periodo elegido. Hazlo al terminar cada periodo.'),
          el('div', { class: 'filtros', style: 'margin:0' }, [el('label', {}, ['Periodo', sel]), btn]),
        ]));
      }
    }

    if (h.periodos.length === 0) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Todavía no has guardado el costo estándar de ningún periodo.'));
      return;
    }

    const selVista = el('select', {}, [
      el('option', { value: 'total' }, 'Costo estándar unitario'), el('option', { value: 'costo_mp' }, 'Solo materiales'),
      el('option', { value: 'costo_mod' }, 'Solo mano de obra'), el('option', { value: 'costo_cif' }, 'Solo CIF'),
    ]);
    const zona = el('div');
    cont.appendChild(el('div', { class: 'filtros' }, [el('label', {}, ['Comparar', selVista])]));
    cont.appendChild(zona);
    selVista.addEventListener('change', dibujar);
    dibujar();

    function dibujar() {
      const campo = selVista.value;
      zona.innerHTML = '';
      const encabezado = el('tr', {}, [el('th', {}, 'Código'), el('th', {}, 'Producto'),
        ...h.periodos.map((p) => el('th', { class: 'num', title: p.guardado ? 'Guardado el ' + p.guardado : '' }, p.nombre)),
        h.periodos.length > 1 ? el('th', { class: 'num' }, 'Variación total') : null]);
      const filas = h.productos.map((prod) => {
        let primero = null, ultimo = null, anterior = null;
        const celdas = h.periodos.map((p) => {
          const d = prod.periodos[p.id];
          if (!d) return el('td', { class: 'num', style: 'color:var(--tinta-tenue)' }, '—');
          const v = d[campo];
          if (primero === null) primero = v;
          ultimo = v;
          const pct = anterior ? ((v - anterior) / anterior) * 100 : null;
          anterior = v;
          return el('td', { class: 'num' }, [
            '$ ' + moneda(v),
            pct !== null && Math.abs(pct) >= 0.05 ? el('span', { class: 'delta ' + (pct > 0 ? 'sube' : 'baja') }, (pct > 0 ? '▲ ' : '▼ ') + Math.abs(pct).toLocaleString('es-CO', { maximumFractionDigits: 1 }) + ' %') : null,
          ]);
        });
        let total = null;
        if (h.periodos.length > 1) {
          const pct = primero ? ((ultimo - primero) / primero) * 100 : null;
          total = el('td', { class: 'num' }, pct === null ? '—' : el('span', { class: 'badge ' + (pct > 0.05 ? 'desfavorable' : pct < -0.05 ? 'favorable' : 'neutra') },
            (pct > 0 ? '+' : '') + pct.toLocaleString('es-CO', { maximumFractionDigits: 1 }) + ' %'));
        }
        return el('tr', {}, [el('td', {}, prod.codigo), el('td', {}, prod.descripcion), ...celdas, total]);
      });
      zona.appendChild(el('div', { class: 'tabla-envoltorio' }, el('table', {}, [el('thead', {}, encabezado), el('tbody', {}, filas)])));
      zona.appendChild(el('p', { class: 'logo-nota', style: 'margin-top:.7em' },
        'Las flechas muestran el cambio frente al periodo anterior. La variación total compara el primer y el último periodo guardado; una subida es desfavorable porque el producto cuesta más.'));
      if (puede) {
        zona.appendChild(el('div', { style: 'margin-top:1.2em; display:flex; gap:.6em; flex-wrap:wrap' },
          h.periodos.map((p) => el('button', { class: 'boton-texto', onclick: () => confirmar(`¿Borrar el costo guardado de «${p.nombre}»? El periodo y sus órdenes no se afectan.`, async () => {
            try { await Api.del(`historico-costos/${p.id}?empresa_id=${empresaId}`); mensaje('Histórico del periodo borrado.'); window.App.recargar(); }
            catch (e) { mensaje(e.mensaje, 'error'); }
          }, 'Borrar') }, `Borrar ${p.nombre}`))));
      }
    }
  }

  return { render };
})();
