/* Pantalla CRUD genérica para las entidades definidas por el backend (meta.entidades). */
const ModuloEntidad = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar, construirFormulario, leerFormulario, marcarErrores } = UI;

  async function cargarReferencias(campos, empresaId) {
    const refs = {};
    for (const c of campos) {
      if (c.tipo === 'ref' && !refs[c.ref]) {
        const q = c.scoped ? `?empresa_id=${empresaId}` : '';
        refs[c.ref] = await Api.get(c.ref + q);
      }
    }
    return refs;
  }

  function textoRef(refs, campo, id) {
    const lista = refs[campo.ref] || [];
    const r = lista.find((x) => x.id === id);
    if (!r) return id;
    return campo.ref_texto && r[campo.ref_texto] ? `${r.codigo} — ${r[campo.ref_texto]}` : r.codigo;
  }

  async function abrirModalTema(fila, refrescarDatos) {
    const actual = Object.assign({ acento: '#0f766e', lateral: '#ffffff', fondo: '#f6f7f9' }, fila.tema || {});
    const iAcento = el('input', { type: 'color', value: actual.acento });
    const iLateral = el('input', { type: 'color', value: actual.lateral });
    const iFondo = el('input', { type: 'color', value: actual.fondo });

    function filaColor(input, etiqueta, ayuda) {
      return el('div', { class: 'campo' }, [
        el('label', {}, etiqueta),
        el('div', { style: 'display:flex; align-items:center; gap:.8em' }, [input]),
        ayuda ? el('p', { style: 'font-size:.76em; color:var(--tinta-tenue); margin-top:.35em' }, ayuda) : null,
      ]);
    }

    const wrap = el('div', {}, [
      el('h3', {}, `Colores de ${fila.razon_social}`),
      el('p', { class: 'mod-desc', style: 'margin-bottom:1.2em' }, 'Personaliza los colores de la interfaz mientras esta empresa esté activa. Los cambios se aplican de inmediato.'),
      filaColor(iAcento, 'Color principal (botones, enlaces, menú activo)'),
      filaColor(iLateral, 'Fondo del menú lateral', 'Claro u oscuro: el color del texto del menú se ajusta solo para que siempre se lea bien.'),
      filaColor(iFondo, 'Fondo general de la página'),
      el('div', { class: 'modal-acciones' }, [
        el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
        el('button', { class: 'secundario', id: 'btn-restablecer-tema' }, 'Restablecer predeterminados'),
        el('button', { class: 'primario', id: 'btn-guardar-tema' }, 'Guardar'),
      ]),
    ]);
    abrirModal(wrap);

    wrap.querySelector('#btn-guardar-tema').addEventListener('click', async () => {
      try {
        const r = await Api.post(`empresas/${fila.id}/tema`, { tema: { acento: iAcento.value, lateral: iLateral.value, fondo: iFondo.value } });
        fila.tema = r.tema;
        cerrarModal();
        mensaje('Colores actualizados.');
        if (window.App) await window.App.refrescarMarca();
        refrescarDatos();
      } catch (e) {
        mensaje(e.mensaje, 'error');
      }
    });
    wrap.querySelector('#btn-restablecer-tema').addEventListener('click', async () => {
      try {
        await Api.post(`empresas/${fila.id}/tema`, { tema: null });
        fila.tema = null;
        cerrarModal();
        mensaje('Colores restablecidos.');
        if (window.App) await window.App.refrescarMarca();
        refrescarDatos();
      } catch (e) {
        mensaje(e.mensaje, 'error');
      }
    });
  }

  async function abrirModalLogo(fila, refrescarDatos) {
    const preview = el('div', { class: 'logo-preview logo-preview-grande' },
      fila.logo ? el('img', { src: fila.logo, alt: 'Logo de la empresa' }) : el('span', { class: 'sin-logo' }, 'Sin logo'));
    const inputArchivo = el('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/svg+xml', class: 'oculto' });
    const btnSubir = el('button', { class: 'secundario' }, fila.logo ? 'Cambiar imagen' : 'Elegir imagen');
    const btnQuitar = el('button', { class: 'secundario peligro', disabled: fila.logo ? null : 'disabled' }, 'Quitar logo');
    btnSubir.addEventListener('click', () => inputArchivo.click());

    inputArchivo.addEventListener('change', () => {
      const archivo = inputArchivo.files[0];
      if (!archivo) return;
      if (archivo.size > 260 * 1024) {
        mensaje('La imagen es muy pesada. Usa una de menos de 250 KB.', 'error');
        inputArchivo.value = '';
        return;
      }
      const lector = new FileReader();
      lector.onload = () => {
        preview.innerHTML = '';
        preview.appendChild(el('img', { src: lector.result, alt: 'Logo de la empresa' }));
        preview.dataset.pendiente = lector.result;
        btnQuitar.removeAttribute('disabled');
      };
      lector.readAsDataURL(archivo);
    });

    btnQuitar.addEventListener('click', () => {
      preview.innerHTML = '';
      preview.appendChild(el('span', { class: 'sin-logo' }, 'Sin logo'));
      preview.dataset.pendiente = '__quitar__';
      btnQuitar.setAttribute('disabled', 'disabled');
    });

    const wrap = el('div', {}, [
      el('h3', {}, `Logo de ${fila.razon_social}`),
      el('div', { class: 'logo-uploader' }, [
        preview,
        el('div', { class: 'logo-acciones' }, [
          el('div', { class: 'fila-botones' }, [btnSubir, btnQuitar, inputArchivo]),
          el('span', { class: 'logo-nota' }, 'PNG, JPG, WEBP o SVG, hasta 250 KB. Se usa en el menú lateral y en los reportes cuando esta empresa está activa.'),
        ]),
      ]),
      el('div', { class: 'modal-acciones' }, [
        el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
        el('button', { class: 'primario', id: 'btn-guardar-logo' }, 'Guardar'),
      ]),
    ]);
    abrirModal(wrap);

    wrap.querySelector('#btn-guardar-logo').addEventListener('click', async () => {
      const pendiente = preview.dataset.pendiente;
      try {
        if (pendiente === '__quitar__') {
          await Api.del(`empresas/${fila.id}/logo`);
          fila.logo = null;
        } else if (pendiente) {
          await Api.post(`empresas/${fila.id}/logo`, { data: pendiente });
          fila.logo = pendiente;
        }
        cerrarModal();
        mensaje('Logo actualizado.');
        if (window.App) await window.App.refrescarMarca();
        refrescarDatos();
      } catch (e) {
        mensaje(e.mensaje, 'error');
      }
    });
  }

  const IMPORTABLES = ['empresas', 'periodos', 'unidades_medida', 'centros_costo', 'productos', 'materias_primas',
    'trabajadores', 'bases_aplicacion', 'cif_conceptos'];

  async function exportarExcel(ent, empresaId) {
    try { await Api.descargar(`exportar/${ent}` + (empresaId ? `?empresa_id=${empresaId}` : '')); mensaje('Archivo de Excel descargado.'); }
    catch (e) { mensaje(e.mensaje, 'error'); }
  }

  // Botones «Exportar a Excel» (todos) e «Importar desde Excel» (quien puede modificar) para cualquier módulo
  function botonesExcel(ent, titulo, empresaId, puedeImportar) {
    return [
      el('button', { class: 'secundario', onclick: () => exportarExcel(ent, empresaId) }, 'Exportar a Excel'),
      puedeImportar ? el('button', { class: 'secundario', onclick: () => abrirImportacion(ent, { titulo }, empresaId) }, 'Importar desde Excel') : null,
    ];
  }

  function abrirImportacion(ent, spec, empresaId) {
    let archivoB64 = null, nombreArchivo = '';
    const inputArchivo = el('input', { type: 'file', accept: '.xlsx', class: 'oculto' });
    const btnElegir = el('button', { class: 'secundario' }, 'Elegir archivo…');
    const etiquetaArchivo = el('span', { class: 'logo-nota' }, 'Ningún archivo elegido');
    const chkActualizar = el('input', { type: 'checkbox', id: 'chk-actualizar' });
    const iCodigoImp = el('input', { type: 'password', autocomplete: 'off', placeholder: 'Código del administrador' });
    const campoCodigoImp = el('div', { class: 'campo oculto', id: 'campo-codigo-importar' }, [
      el('label', {}, 'Código de autorización (obligatorio para actualizar órdenes que ya existen)'), iCodigoImp]);
    const zonaResultado = el('div');
    const btnImportar = el('button', { class: 'primario', disabled: 'disabled' }, 'Importar');
    btnElegir.addEventListener('click', () => inputArchivo.click());

    const wrap = el('div', {}, [
      el('h3', {}, `Importar ${spec.titulo.toLowerCase()} desde Excel`),
      el('ol', { class: 'pasos' }, [
        el('li', {}, ['Descarga la ', el('button', { class: 'enlace', onclick: () => Api.descargar(`plantilla/${ent}?empresa_id=${empresaId}`).catch((e) => mensaje(e.mensaje, 'error')) }, 'plantilla de Excel'),
          ', que trae los títulos correctos, un ejemplo y las instrucciones.']),
        el('li', {}, 'Llénala con una fila por registro y guárdala.'),
        el('li', {}, 'Elige el archivo: el sistema revisa cada fila antes de guardar nada.'),
      ]),
      el('div', { class: 'fila-botones', style: 'display:flex; align-items:center; gap:.8em; margin:.4em 0 1em' }, [btnElegir, etiquetaArchivo, inputArchivo]),
      el('label', { class: 'check-linea' }, [chkActualizar, 'Si un código ya existe, actualizar ese registro con los datos del archivo']),
      campoCodigoImp,
      zonaResultado,
      el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'), btnImportar]),
    ]);
    abrirModal(wrap);
    document.getElementById('modal').classList.add('modal-ancho');

    async function revisar() {
      if (!archivoB64) return;
      zonaResultado.innerHTML = '';
      zonaResultado.appendChild(el('p', { class: 'mod-desc' }, 'Revisando el archivo…'));
      btnImportar.setAttribute('disabled', 'disabled');
      try {
        const r = await Api.post(`importar/${ent}/revisar`, { archivo: archivoB64, actualizar: chkActualizar.checked, empresa_id: empresaId });
        dibujarVistaPrevia(r);
      } catch (e) {
        zonaResultado.innerHTML = '';
        zonaResultado.appendChild(el('div', { class: 'aviso aviso-alerta' }, e.mensaje));
      }
    }

    function dibujarVistaPrevia(r) {
      zonaResultado.innerHTML = '';
      const validas = r.crear + r.actualizar;
      const partes = [];
      if (r.crear) partes.push(`${r.crear} para crear`);
      if (r.actualizar) partes.push(`${r.actualizar} para actualizar`);
      if (r.omitir) partes.push(`${r.omitir} se omiten (órdenes cerradas)`);
      if (r.con_error) partes.push(`${r.con_error} con errores (no se importarán)`);
      zonaResultado.appendChild(el('div', { class: 'aviso ' + (r.con_error ? 'aviso-alerta' : 'aviso-info') },
        `${r.filas.length} fila${r.filas.length === 1 ? '' : 's'} en «${nombreArchivo}»: ${partes.join(', ')}.`));
      const ETQ = { crear: ['favorable', 'Crear'], actualizar: ['neutra', 'Actualizar'], omitir: ['neutra', 'Se omite'], error: ['desfavorable', 'Error'] };
      const conHoja = r.filas.some((f) => f.hoja);
      zonaResultado.appendChild(el('div', { class: 'tabla-envoltorio vista-previa' }, el('table', {}, [
        el('thead', {}, el('tr', {}, [conHoja ? 'Hoja' : null, 'Fila', 'Código', 'Nombre', 'Resultado', 'Detalle'].filter(Boolean).map((t) => el('th', {}, t)))),
        el('tbody', {}, r.filas.map((f) => el('tr', { class: f.accion === 'error' ? 'fila-error' : null }, [
          conHoja ? el('td', {}, f.hoja || '') : null,
          el('td', { class: 'num' }, String(f.fila)), el('td', {}, f.codigo || '—'), el('td', {}, f.nombre || ''),
          el('td', {}, el('span', { class: 'badge ' + ETQ[f.accion][0] }, ETQ[f.accion][1])),
          el('td', { style: 'white-space:normal' }, f.errores.join(' · ')),
        ]))),
      ])));
      if (validas) {
        btnImportar.removeAttribute('disabled');
        btnImportar.textContent = `Importar ${validas} fila${validas === 1 ? '' : 's'}`;
      } else {
        btnImportar.textContent = 'Importar';
      }
    }

    inputArchivo.addEventListener('change', () => {
      const f = inputArchivo.files[0];
      if (!f) return;
      if (f.size > 4 * 1024 * 1024) { mensaje('El archivo pesa más de 4 MB. Divídelo en varios.', 'error'); return; }
      nombreArchivo = f.name;
      etiquetaArchivo.textContent = f.name;
      const lector = new FileReader();
      lector.onload = () => { archivoB64 = lector.result; revisar(); };
      lector.readAsDataURL(f);
    });
    chkActualizar.addEventListener('change', () => { campoCodigoImp.classList.toggle('oculto', !(ent === 'ordenes' && chkActualizar.checked)); });
    chkActualizar.addEventListener('change', revisar);

    btnImportar.addEventListener('click', async () => {
      btnImportar.setAttribute('disabled', 'disabled');
      try {
        const r = await Api.post(`importar/${ent}/confirmar`, { archivo: archivoB64, actualizar: chkActualizar.checked, empresa_id: empresaId, codigo: iCodigoImp.value });
        cerrarModal();
        const partes = [];
        if (r.creadas) partes.push(`${r.creadas} creado${r.creadas === 1 ? '' : 's'}`);
        if (r.actualizadas) partes.push(`${r.actualizadas} actualizado${r.actualizadas === 1 ? '' : 's'}`);
        if (r.omitidas) partes.push(`${r.omitidas} omitido${r.omitidas === 1 ? '' : 's'} por errores`);
        mensaje('Importación terminada: ' + partes.join(', ') + '.');
        if (ent === 'empresas' || ent === 'unidades_medida') await window.App.refrescarMarca();
        window.App.recargar();
      } catch (e) { mensaje(e.mensaje, 'error'); btnImportar.removeAttribute('disabled'); }
    });
  }

  async function render(cont, nombreEntidad, meta, empresaId) {
    const spec = meta.entidades[nombreEntidad];
    cont.innerHTML = '';
    if (spec.scoped && !empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa arriba a la derecha para ver este módulo. Si aún no has creado una, ve a «Empresas».'));
      return;
    }
    const esAdmin = meta.usuario.rol === 'administrador';
    const puedeEditar = UI.puedeEscribir(meta, nombreEntidad);
    const cabeza = el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, spec.titulo), spec.descLarga ? el('p', { class: 'mod-desc' }, spec.descLarga) : null]),
      el('div', { class: 'botones-cabeza' }, [
        ...(IMPORTABLES.includes(nombreEntidad) ? botonesExcel(nombreEntidad, spec.titulo, empresaId, puedeEditar) : []),
        puedeEditar ? el('button', { class: 'primario', onclick: () => abrirFormulario(null) }, (spec.femenino ? 'Nueva ' : 'Nuevo ') + spec.singular) : null,
      ]),
    ]);
    cont.appendChild(cabeza);

    const envoltorio = el('div', { class: 'tabla-envoltorio' });
    const cargando = el('p', { class: 'mod-desc' }, 'Cargando…');
    cont.appendChild(cargando);
    let datos, refs;
    try {
      [datos, refs] = await Promise.all([
        Api.get(nombreEntidad + (spec.scoped ? `?empresa_id=${empresaId}` : '')),
        cargarReferencias(spec.campos, empresaId),
      ]);
    } catch (e) {
      cargando.remove();
      cont.appendChild(el('div', { class: 'vacio' }, e.mensaje));
      return;
    }
    cargando.remove();
    let filtro = '';
    const buscador = el('input', { type: 'search', class: 'buscador', placeholder: `Buscar en ${spec.titulo.toLowerCase()}…` });
    buscador.addEventListener('input', () => { filtro = buscador.value.trim().toLowerCase(); dibujarTabla(); });
    const contador = el('span', { class: 'contador' });
    cont.appendChild(el('div', { class: 'barra-tabla' }, [buscador, contador]));
    cont.appendChild(envoltorio);
    dibujarTabla();

    function campoDe(nombre) {
      return spec.campos.find((c) => c.name === nombre);
    }

    function dibujarTabla() {
      envoltorio.innerHTML = '';
      if (datos.length === 0) {
        contador.textContent = '';
        envoltorio.appendChild(el('div', { class: 'vacio' }, `Aún no hay registros de ${spec.singular}s.`));
        return;
      }
      const columnas = spec.lista;
      const thead = el('tr', {}, columnas.map((c) => el('th', {}, campoDe(c) ? campoDe(c).label : c)).concat(puedeEditar ? [el('th', {}, '')] : []));
      const tbody = el('tbody');
      const visibles = filtro
        ? datos.filter((f) => spec.lista.some((c) => {
            const campo = campoDe(c);
            let v = f[c];
            if (campo && campo.tipo === 'ref') v = textoRef(refs, campo, v);
            else if (campo && campo.tipo === 'select') v = (campo.opciones.find((o) => o.valor === v) || {}).texto || v;
            return String(v ?? '').toLowerCase().includes(filtro);
          }))
        : datos;
      contador.textContent = filtro ? `${visibles.length} de ${datos.length}` : `${datos.length} registro${datos.length === 1 ? '' : 's'}`;
      if (visibles.length === 0) {
        envoltorio.appendChild(el('div', { class: 'vacio' }, `Ningún registro coincide con «${buscador.value}».`));
        return;
      }
      for (const fila of visibles) {
        const celdas = columnas.map((c) => {
          const campo = campoDe(c);
          let texto = fila[c];
          const esNum = campo && ['number', 'percent'].includes(campo.tipo);
          if (campo && campo.tipo === 'ref') texto = textoRef(refs, campo, fila[c]);
          else if (campo && campo.tipo === 'select') texto = (campo.opciones.find((o) => o.valor === fila[c]) || {}).texto || fila[c];
          else if (esNum) texto = UI.moneda(fila[c]) + (campo.tipo === 'percent' ? ' %' : '');
          if (nombreEntidad === 'empresas' && c === 'razon_social') {
            return el('td', {}, [fila.logo ? el('img', { src: fila.logo, class: 'mini-logo' }) : null, String(texto ?? '')]);
          }
          return el('td', { class: esNum ? 'num' : null }, String(texto ?? ''));
        });
        if (puedeEditar) {
          const acciones = [el('button', { onclick: () => abrirFormulario(fila) }, 'Editar')];
          if (nombreEntidad === 'empresas') {
            acciones.push(el('button', { onclick: () => abrirModalLogo(fila, () => dibujarTabla()) }, fila.logo ? 'Cambiar logo' : 'Agregar logo'));
            acciones.push(el('button', { onclick: () => abrirModalTema(fila, () => dibujarTabla()) }, 'Colores'));
          }
          acciones.push(el('button', { onclick: () => eliminar(fila) }, 'Eliminar'));
          celdas.push(el('td', {}, el('div', { class: 'acciones-fila' }, acciones)));
        }
        tbody.appendChild(el('tr', {}, celdas));
      }
      envoltorio.appendChild(el('table', {}, [thead, tbody]));
    }

    function eliminar(fila) {
      confirmar(`¿Eliminar este registro de ${spec.singular} (${fila.codigo || fila.nombre || fila.id})? Esta acción no se puede deshacer.`, async () => {
        try {
          await Api.del(`${nombreEntidad}/${fila.id}${spec.scoped ? `?empresa_id=${empresaId}` : ''}`);
          datos = datos.filter((d) => d.id !== fila.id);
          dibujarTabla();
          mensaje('Registro eliminado.');
        } catch (e) {
          mensaje(e.mensaje, 'error');
        }
      });
    }

    function abrirFormulario(fila) {
      const editando = !!fila;
      const { nodo, inputs } = construirFormulario(spec.campos, refs, fila || {});
      const wrap = el('div', {}, [
        el('h3', {}, editando ? `Editar ${spec.singular}` : `${spec.femenino ? 'Nueva' : 'Nuevo'} ${spec.singular}`),
        nodo,
        el('div', { class: 'modal-acciones' }, [
          el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
          el('button', { class: 'primario', id: 'btn-guardar' }, 'Guardar'),
        ]),
      ]);
      abrirModal(wrap);
      wrap.querySelector('#btn-guardar').addEventListener('click', async () => {
        const cuerpo = leerFormulario(inputs);
        if (spec.scoped) cuerpo.empresa_id = empresaId;
        try {
          if (editando) {
            await Api.put(`${nombreEntidad}/${fila.id}`, cuerpo);
            mensaje('Cambios guardados.');
          } else {
            await Api.post(nombreEntidad, cuerpo);
            mensaje(`${spec.singular[0].toUpperCase()}${spec.singular.slice(1)} ${spec.femenino ? 'creada' : 'creado'}.`);
          }
          cerrarModal();
          datos = await Api.get(nombreEntidad + (spec.scoped ? `?empresa_id=${empresaId}` : ''));
          dibujarTabla();
        } catch (e) {
          marcarErrores(nodo, e.campos);
          mensaje(e.mensaje, 'error');
        }
      });
    }
  }

  return { render, botonesExcel };
})();
