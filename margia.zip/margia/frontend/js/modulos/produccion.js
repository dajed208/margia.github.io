/* Órdenes de producción: creación, registro de consumos/MOD/CIF real y cierre con costo real y variaciones. */
const ModuloProduccion = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar, marcarErrores } = UI;

  const ETIQUETAS_VAR = {
    precio_materiales: 'Variación de precio — materiales', cantidad_materiales: 'Variación de cantidad — materiales',
    tarifa_mod: 'Variación de tarifa — MOD', eficiencia_mod: 'Variación de eficiencia — MOD',
    presupuesto_cif: 'Variación de presupuesto — CIF', volumen_cif: 'Variación de volumen — CIF', total: 'Variación total',
  };

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    if (!empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa arriba para ver las órdenes de producción.'));
      return;
    }
    const esAdmin = UI.puedeEscribir(meta, 'ordenes');
    let codigo = { configurado: true, puede_configurar: false };  // si falla la consulta, el servidor lo explicará al intentar
    try { codigo = await Api.get('ordenes/codigo'); } catch (e) { /* sin interrumpir la pantalla */ }
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Órdenes de producción'),
        el('p', { class: 'mod-desc' }, 'Registra el consumo real de cada orden y ciérrala para calcular el costo real y las variaciones.')]),
      el('div', { class: 'botones-cabeza' }, [
        ...ModuloEntidad.botonesExcel('ordenes', 'Órdenes de producción', empresaId, esAdmin),
        codigo.puede_configurar ? el('button', { class: 'secundario', onclick: abrirCodigo }, 'Código de autorización') : null,
        esAdmin ? el('button', { class: 'primario', onclick: nuevaOrden }, 'Nueva orden') : null,
      ]),
    ]));
    if (codigo.puede_configurar && !codigo.configurado) {
      cont.appendChild(el('div', { class: 'aviso aviso-info' }, [
        'Para poder corregir o eliminar órdenes necesitas crear el código de autorización: solo quien lo conozca podrá hacerlo. ',
        el('button', { class: 'enlace', onclick: abrirCodigo }, 'Crear el código ahora'),
      ]));
    }

    const envoltorio = el('div', { class: 'tabla-envoltorio' });
    cont.appendChild(envoltorio);
    let ordenes;
    try { ordenes = await Api.get(`ordenes?empresa_id=${empresaId}`); }
    catch (e) { envoltorio.appendChild(el('div', { class: 'vacio' }, e.mensaje)); return; }

    if (ordenes.length === 0) {
      envoltorio.appendChild(el('div', { class: 'vacio' }, 'Aún no hay órdenes de producción. Crea la primera con «Nueva orden».'));
    } else {
      envoltorio.appendChild(el('table', {}, [
        el('tr', {}, ['N° orden', 'Producto', 'Fecha', 'Cant. planeada', 'Cant. producida', 'Estado', ''].map((t) => el('th', {}, t))),
        el('tbody', {}, ordenes.map((o) => el('tr', {}, [
          el('td', {}, o.numero), el('td', {}, `${o.producto_codigo} — ${o.producto_descripcion}`),
          el('td', {}, o.fecha), el('td', { class: 'num' }, UI.cantidad(o.cantidad_planeada)),
          el('td', { class: 'num' }, UI.cantidad(o.cantidad_producida)),
          el('td', {}, el('span', { class: 'badge ' + (o.estado === 'terminada' ? 'favorable' : 'neutra') }, o.estado === 'terminada' ? 'Terminada' : 'Abierta')),
          el('td', {}, el('div', { class: 'acciones-fila' }, [
            el('button', { onclick: () => verOrden(o.id) }, 'Ver'),
            esAdmin ? el('button', { onclick: () => (o.estado === 'terminada' ? reabrirOrden(o) : editarOrden(o, () => window.App.recargar())) },
              o.estado === 'terminada' ? 'Reabrir' : 'Editar') : null,
            esAdmin ? el('button', { onclick: () => eliminarOrden(o) }, 'Eliminar') : null,
          ])),
        ]))),
      ]));
    }

    // ---- Corregir órdenes: todo lo que cambia o borra datos ya registrados pide el código del administrador ----
    function campoForm(nombre, etiqueta, input) {
      return el('div', { class: 'campo', 'data-campo': nombre }, [el('label', {}, etiqueta), input, el('p', { class: 'msg-error oculto' })]);
    }

    /** Cuadro con el código de autorización y el motivo. `extra` son campos propios de la acción (opcional). */
    function pedirCodigo({ titulo, aviso, destructivo, extra, etiqueta, alConfirmar }) {
      const iCodigo = el('input', { type: 'password', autocomplete: 'off', placeholder: 'Código del administrador' });
      const iMotivo = el('input', { type: 'text', maxlength: '200', placeholder: 'Ej. se digitó mal la cantidad' });
      const nodo = el('div', {}, [extra || null, campoForm('codigo', 'Código de autorización', iCodigo), campoForm('motivo', 'Motivo (opcional)', iMotivo)]);
      const btn = el('button', { class: 'primario' + (destructivo ? ' destructivo' : ''), id: 'btn-autorizar' }, etiqueta);
      abrirModal(el('div', {}, [
        el('h3', {}, titulo),
        aviso ? el('div', { class: 'aviso ' + (destructivo ? 'aviso-peligro' : 'aviso-alerta') }, aviso) : null,
        nodo,
        el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'), btn]),
      ]));
      iCodigo.focus();
      const enviar = async () => {
        btn.disabled = true;
        marcarErrores(nodo, {});
        try { await alConfirmar(iCodigo.value, iMotivo.value); }
        catch (e) {
          marcarErrores(nodo, e.campos);
          mensaje(e.mensaje, 'error');
          if (e.status === 403) { iCodigo.value = ''; iCodigo.focus(); }
        } finally { btn.disabled = false; }
      };
      btn.addEventListener('click', enviar);
      iCodigo.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') enviar(); });
    }

    /** true si todavía no hay código (y entonces explica qué hacer). */
    function faltaCodigo() {
      if (codigo.configurado) return false;
      if (codigo.puede_configurar) { mensaje('Antes de corregir una orden, crea el código de autorización.', 'error'); abrirCodigo(); }
      else mensaje('El administrador todavía no ha creado el código de autorización de las órdenes.', 'error');
      return true;
    }

    function abrirCodigo() {
      const iPass = el('input', { type: 'password', autocomplete: 'current-password' });
      const iCod = el('input', { type: 'password', autocomplete: 'new-password' });
      const iRep = el('input', { type: 'password', autocomplete: 'new-password' });
      const nodo = el('div', {}, [
        campoForm('password', 'Tu contraseña de administrador', iPass),
        campoForm('codigo', codigo.configurado ? 'Código nuevo (mínimo 4 caracteres)' : 'Código de autorización (mínimo 4 caracteres)', iCod),
        campoForm('repetir', 'Repite el código', iRep),
      ]);
      abrirModal(el('div', {}, [
        el('h3', {}, codigo.configurado ? 'Cambiar el código de autorización' : 'Crear el código de autorización'),
        el('p', { class: 'mod-desc', style: 'margin-bottom:1.1em' },
          'Con este código se podrán editar, reabrir y eliminar órdenes de producción. Compártelo solo con quien deba hacerlo. '
          + 'No se puede ver después: si lo olvidas, créalo de nuevo.'),
        nodo,
        el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
          el('button', { class: 'primario', id: 'btn-guardar-codigo' }, 'Guardar código')]),
      ]));
      iPass.focus();
      document.getElementById('btn-guardar-codigo').addEventListener('click', async () => {
        marcarErrores(nodo, {});
        if (iCod.value !== iRep.value) { marcarErrores(nodo, { repetir: 'Los códigos no coinciden.' }); return; }
        try {
          await Api.post('ordenes/codigo', { password: iPass.value, codigo: iCod.value });
          cerrarModal();
          mensaje('Código de autorización guardado. Compártelo solo con quien deba corregir órdenes.');
          window.App.recargar();
        } catch (e) { marcarErrores(nodo, e.campos); mensaje(e.mensaje, 'error'); }
      });
    }

    async function editarOrden(o, alTerminar) {
      if (faltaCodigo()) return;
      let productos, periodos;
      try { [productos, periodos] = await Promise.all([Api.get(`productos?empresa_id=${empresaId}`), Api.get(`periodos?empresa_id=${empresaId}`)]); }
      catch (e) { mensaje(e.mensaje, 'error'); return; }
      const iNumero = el('input', { type: 'text', value: o.numero });
      const selProd = el('select', {}, productos.map((p) => el('option', { value: p.id, selected: p.id === o.producto_id ? 'selected' : null }, `${p.codigo} — ${p.descripcion}`)));
      const selPer = el('select', {}, periodos.map((p) => el('option', { value: p.id, selected: p.id === o.periodo_id ? 'selected' : null }, p.nombre)));
      const iFecha = el('input', { type: 'date', value: o.fecha });
      const iCant = el('input', { type: 'number', step: 'any', min: '0', value: String(o.cantidad_planeada) });
      pedirCodigo({
        titulo: `Editar la orden ${o.numero}`, etiqueta: 'Guardar cambios',
        extra: el('div', {}, [campoForm('numero', 'Número de orden', iNumero), campoForm('producto_id', 'Producto', selProd),
          campoForm('periodo_id', 'Periodo contable', selPer), campoForm('fecha', 'Fecha', iFecha), campoForm('cantidad_planeada', 'Cantidad planeada', iCant)]),
        alConfirmar: async (cod, motivo) => {
          await Api.put(`ordenes/${o.id}`, { codigo: cod, motivo, numero: iNumero.value, producto_id: Number(selProd.value),
            periodo_id: Number(selPer.value), fecha: iFecha.value, cantidad_planeada: iCant.value, empresa_id: empresaId });
          cerrarModal(); mensaje('Orden actualizada.'); alTerminar();
        },
      });
    }

    function reabrirOrden(o) {
      if (faltaCodigo()) return;
      pedirCodigo({
        titulo: `Reabrir la orden ${o.numero}`, etiqueta: 'Reabrir orden',
        aviso: 'Al reabrirla se descartan su costo real y sus variaciones, y lo que descontó del inventario vuelve a la bodega. '
          + 'Corrige lo que haga falta y vuelve a cerrarla: todo se recalcula.',
        alConfirmar: async (cod, motivo) => {
          await Api.post(`ordenes/${o.id}/reabrir`, { codigo: cod, motivo, empresa_id: empresaId });
          cerrarModal(); mensaje('Orden reabierta. Corrígela y vuelve a cerrarla.'); window.scrollTo(0, 0); await verOrden(o.id);
        },
      });
    }

    function eliminarOrden(o) {
      if (faltaCodigo()) return;
      pedirCodigo({
        titulo: `Eliminar la orden ${o.numero}`, etiqueta: 'Eliminar orden', destructivo: true,
        aviso: 'Se eliminará la orden con todos sus consumos, horas y costos. Si estaba cerrada, el inventario que descontó vuelve a la bodega. '
          + 'No se puede deshacer.',
        alConfirmar: async (cod, motivo) => {
          await Api.post(`ordenes/${o.id}/eliminar`, { codigo: cod, motivo, empresa_id: empresaId });
          cerrarModal(); mensaje('Orden eliminada.'); window.App.recargar();
        },
      });
    }

    async function nuevaOrden() {
      const [productos, periodos] = await Promise.all([
        Api.get(`productos?empresa_id=${empresaId}`), Api.get(`periodos?empresa_id=${empresaId}`),
      ]);
      if (productos.length === 0 || periodos.length === 0) {
        mensaje('Necesitas al menos un producto y un periodo contable antes de crear una orden.', 'error');
        return;
      }
      const iNumero = el('input', { type: 'text', placeholder: 'Ej. OP-001' });
      const selProd = el('select', {}, productos.map((p) => el('option', { value: p.id }, `${p.codigo} — ${p.descripcion}`)));
      const selPer = el('select', {}, periodos.map((p) => el('option', { value: p.id }, p.nombre)));
      const iFecha = el('input', { type: 'date' });
      const iCant = el('input', { type: 'number', step: 'any', min: '0' });
      const nodo = el('div', {}, [
        campo('numero', 'Número de orden', iNumero), campo('producto_id', 'Producto', selProd),
        campo('periodo_id', 'Periodo contable', selPer), campo('fecha', 'Fecha', iFecha),
        campo('cantidad_planeada', 'Cantidad planeada', iCant),
      ]);
      const wrap = el('div', {}, [el('h3', {}, 'Nueva orden de producción'), nodo,
        el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
          el('button', { class: 'primario', id: 'btn-crear' }, 'Crear orden')])]);
      abrirModal(wrap);
      wrap.querySelector('#btn-crear').addEventListener('click', async () => {
        try {
          await Api.post('ordenes', {
            numero: iNumero.value, producto_id: Number(selProd.value), periodo_id: Number(selPer.value),
            fecha: iFecha.value, cantidad_planeada: iCant.value, empresa_id: empresaId,
          });
          cerrarModal(); mensaje('Orden creada.'); window.App.recargar();
        } catch (e) { marcarErrores(nodo, e.campos); mensaje(e.mensaje, 'error'); }
      });
    }

    function campo(nombre, etiqueta, input) {
      return el('div', { class: 'campo', 'data-campo': nombre }, [el('label', {}, etiqueta), input, el('p', { class: 'msg-error oculto' })]);
    }

    async function verOrden(oid) {
      cont.innerHTML = '';
      let d;
      try { d = await Api.get(`ordenes/${oid}?empresa_id=${empresaId}`); }
      catch (e) { cont.appendChild(el('div', { class: 'vacio' }, e.mensaje)); return; }
      const o = d.orden;
      const cerrada = o.estado === 'terminada';

      cont.appendChild(el('div', { class: 'mod-cabeza' }, [
        el('div', {}, [
          el('h2', {}, `Orden ${o.numero}`),
          el('p', { class: 'mod-desc' }, `${d.producto.codigo} — ${d.producto.descripcion} · ${o.fecha} · Planeada: ${o.cantidad_planeada}`),
        ]),
        el('div', { class: 'botones-cabeza' }, [
          (esAdmin && !cerrada) ? el('button', { class: 'secundario', onclick: () => editarOrden(o, () => verOrden(o.id)) }, 'Editar datos') : null,
          (esAdmin && cerrada) ? el('button', { class: 'secundario', onclick: () => reabrirOrden(o) }, 'Reabrir orden') : null,
          esAdmin ? el('button', { class: 'secundario peligro', onclick: () => eliminarOrden(o) }, 'Eliminar') : null,
          el('button', { class: 'secundario', onclick: () => window.App.recargar() }, '← Volver a la lista'),
        ]),
      ]));

      (d.advertencias || []).forEach((t) => cont.appendChild(el('div', { class: 'aviso aviso-alerta' }, t)));
      if (cerrada) {
        cont.appendChild(seccionResultado(d));
      } else {
        cont.appendChild(await seccionConsumos(d, esAdmin));
        cont.appendChild(await seccionMod(d, esAdmin));
        cont.appendChild(await seccionCif(d, esAdmin));
        cont.appendChild(await seccionBasesPersonalizadas(d, esAdmin));
        if (esAdmin) cont.appendChild(seccionCierre(d));
      }
    }

    async function seccionConsumos(d, esAdmin) {
      const o = d.orden;
      const materias = await Api.get(`materias_primas?empresa_id=${empresaId}`);
      const panel = el('div', { class: 'panel' }, [el('h3', {}, 'Consumo real de materiales')]);
      const tabla = el('div', { class: 'tabla-envoltorio', style: 'margin-bottom:1em' });
      dibujar();
      function dibujar() {
        tabla.innerHTML = '';
        if (d.consumo_mp.length === 0) { tabla.appendChild(el('div', { class: 'vacio' }, 'Sin consumos registrados.')); return; }
        tabla.appendChild(el('table', {}, [
          el('tr', {}, ['Material', 'Cantidad real', 'Precio real', esAdmin ? '' : null].filter(Boolean).map((t) => el('th', {}, t))),
          el('tbody', {}, d.consumo_mp.map((c) => el('tr', {}, [
            el('td', {}, `${c.codigo} — ${c.descripcion}`), el('td', { class: 'num' }, UI.cantidad(c.cantidad_real)),
            el('td', { class: 'num' }, UI.moneda(c.precio_real)),
            esAdmin ? el('td', {}, el('button', { class: 'boton-texto', onclick: async () => {
              await Api.del(`ordenes/${o.id}/consumo/${c.id}?empresa_id=${empresaId}`);
              d.consumo_mp = d.consumo_mp.filter((x) => x.id !== c.id); dibujar(); mensaje('Consumo eliminado.');
            } }, 'Quitar')) : null,
          ]))),
        ]));
      }
      panel.appendChild(tabla);
      if (esAdmin) {
        const selMp = el('select', {}, materias.map((m) => el('option', { value: m.id }, `${m.codigo} — ${m.descripcion}`)));
        const iCant = el('input', { type: 'number', step: 'any', placeholder: 'Cantidad real' });
        const iPrecio = el('input', { type: 'number', step: 'any', placeholder: 'Precio real' });
        const btn = el('button', { class: 'secundario' }, 'Agregar consumo');
        btn.addEventListener('click', async () => {
          try {
            const r = await Api.post(`ordenes/${o.id}/consumo`, { materia_prima_id: Number(selMp.value), cantidad_real: iCant.value, precio_real: iPrecio.value, empresa_id: empresaId });
            const mp = materias.find((m) => m.id === Number(selMp.value));
            d.consumo_mp.push({ id: r.id, materia_prima_id: mp.id, cantidad_real: Number(iCant.value), precio_real: Number(iPrecio.value), codigo: mp.codigo, descripcion: mp.descripcion });
            dibujar(); mensaje('Consumo agregado.'); iCant.value = ''; iPrecio.value = '';
          } catch (e) { mensaje(e.mensaje, 'error'); }
        });
        panel.appendChild(el('div', { class: 'filtros' }, [
          el('label', {}, ['Materia prima', selMp]), el('label', {}, ['Cantidad real', iCant]), el('label', {}, ['Precio real', iPrecio]), btn,
        ]));
      }
      return panel;
    }

    async function seccionMod(d, esAdmin) {
      const o = d.orden;
      const trabajadores = await Api.get(`trabajadores?empresa_id=${empresaId}`);
      const panel = el('div', { class: 'panel' }, [el('h3', {}, 'Horas de mano de obra directa')]);
      const tabla = el('div', { class: 'tabla-envoltorio', style: 'margin-bottom:1em' });
      dibujar();
      function dibujar() {
        tabla.innerHTML = '';
        if (d.horas_mod.length === 0) { tabla.appendChild(el('div', { class: 'vacio' }, 'Sin horas registradas.')); return; }
        tabla.appendChild(el('table', {}, [
          el('tr', {}, ['Trabajador', 'Horas reales', 'Tarifa real', esAdmin ? '' : null].filter(Boolean).map((t) => el('th', {}, t))),
          el('tbody', {}, d.horas_mod.map((h) => el('tr', {}, [
            el('td', {}, `${h.codigo} — ${h.nombre}`), el('td', { class: 'num' }, UI.cantidad(h.horas_reales)),
            el('td', { class: 'num' }, UI.moneda(h.tarifa_real)),
            esAdmin ? el('td', {}, el('button', { class: 'boton-texto', onclick: async () => {
              await Api.del(`ordenes/${o.id}/mod/${h.id}?empresa_id=${empresaId}`);
              d.horas_mod = d.horas_mod.filter((x) => x.id !== h.id); dibujar(); mensaje('Registro eliminado.');
            } }, 'Quitar')) : null,
          ]))),
        ]));
      }
      panel.appendChild(tabla);
      if (esAdmin) {
        const selT = el('select', {}, trabajadores.map((t) => el('option', { value: t.id }, `${t.codigo} — ${t.nombre}`)));
        const iHoras = el('input', { type: 'number', step: 'any', placeholder: 'Horas reales' });
        const iTarifa = el('input', { type: 'number', step: 'any', placeholder: 'Tarifa real' });
        const btn = el('button', { class: 'secundario' }, 'Agregar registro');
        btn.addEventListener('click', async () => {
          try {
            const r = await Api.post(`ordenes/${o.id}/mod`, { trabajador_id: Number(selT.value), horas_reales: iHoras.value, tarifa_real: iTarifa.value, empresa_id: empresaId });
            const t = trabajadores.find((x) => x.id === Number(selT.value));
            d.horas_mod.push({ id: r.id, trabajador_id: t.id, horas_reales: Number(iHoras.value), tarifa_real: Number(iTarifa.value), codigo: t.codigo, nombre: t.nombre });
            dibujar(); mensaje('Registro agregado.'); iHoras.value = ''; iTarifa.value = '';
          } catch (e) { mensaje(e.mensaje, 'error'); }
        });
        panel.appendChild(el('div', { class: 'filtros' }, [
          el('label', {}, ['Trabajador', selT]), el('label', {}, ['Horas reales', iHoras]), el('label', {}, ['Tarifa real', iTarifa]), btn,
        ]));
      }
      return panel;
    }

    async function seccionCif(d, esAdmin) {
      const o = d.orden;
      const conceptos = await Api.get(`cif_conceptos?empresa_id=${empresaId}`);
      const panel = el('div', { class: 'panel' }, [el('h3', {}, 'CIF real de la orden'),
        el('p', { class: 'mod-desc' }, 'Registra cuánto costó realmente cada concepto de CIF en esta orden.')]);
      const tabla = el('div', { class: 'tabla-envoltorio', style: 'margin-bottom:1em' });
      dibujar();
      function dibujar() {
        tabla.innerHTML = '';
        if (d.cif_real.length === 0) { tabla.appendChild(el('div', { class: 'vacio' }, 'Sin CIF real registrado.')); return; }
        tabla.appendChild(el('table', {}, [
          el('tr', {}, ['Concepto', 'Monto real', esAdmin ? '' : null].filter(Boolean).map((t) => el('th', {}, t))),
          el('tbody', {}, d.cif_real.map((c) => el('tr', {}, [
            el('td', {}, `${c.codigo} — ${c.descripcion}`), el('td', { class: 'num' }, UI.moneda(c.monto_real)),
            esAdmin ? el('td', {}, el('button', { class: 'boton-texto', onclick: async () => {
              try {
                await Api.del(`ordenes/${o.id}/cif/${c.id}?empresa_id=${empresaId}`);
                await verOrden(o.id);  // se redibuja todo para que el concepto quitado vuelva a estar disponible en la lista
                mensaje('Registro eliminado.');
              } catch (e) { mensaje(e.mensaje, 'error'); }
            } }, 'Quitar')) : null,
          ]))),
        ]));
      }
      panel.appendChild(tabla);
      if (esAdmin) {
        const disponibles = conceptos.filter((c) => !d.cif_real.some((r) => r.concepto_id === c.id));
        if (disponibles.length > 0) {
          const selC = el('select', {}, disponibles.map((c) => el('option', { value: c.id }, `${c.codigo} — ${c.descripcion}`)));
          const iMonto = el('input', { type: 'number', step: 'any', placeholder: 'Monto real' });
          const btn = el('button', { class: 'secundario' }, 'Agregar');
          btn.addEventListener('click', async () => {
            try {
              const r = await Api.post(`ordenes/${o.id}/cif`, { concepto_id: Number(selC.value), monto_real: iMonto.value, empresa_id: empresaId });
              const c = conceptos.find((x) => x.id === Number(selC.value));
              d.cif_real.push({ id: r.id, concepto_id: c.id, monto_real: Number(iMonto.value), codigo: c.codigo, descripcion: c.descripcion });
              await verOrden(o.id);
              mensaje('CIF real agregado.');
            } catch (e) { mensaje(e.mensaje, 'error'); }
          });
          panel.appendChild(el('div', { class: 'filtros' }, [el('label', {}, ['Concepto de CIF', selC]), el('label', {}, ['Monto real', iMonto]), btn]));
        }
      }
      return panel;
    }

    async function seccionBasesPersonalizadas(d, esAdmin) {
      const o = d.orden;
      const todasLasBases = await Api.get(`bases_aplicacion?empresa_id=${empresaId}`);
      const personalizadas = todasLasBases.filter((b) => !b.protegida);
      if (personalizadas.length === 0) return el('div', {});
      const panel = el('div', { class: 'panel' }, [el('h3', {}, 'Bases de aplicación personalizadas — consumo real'),
        el('p', { class: 'mod-desc' }, 'Registra cuánto se consumió realmente en esta orden de cada base personalizada que uses en tus conceptos de CIF.')]);
      const tabla = el('div', { class: 'tabla-envoltorio', style: 'margin-bottom:1em' });
      dibujar();
      function dibujar() {
        tabla.innerHTML = '';
        if (d.bases_reales.length === 0) { tabla.appendChild(el('div', { class: 'vacio' }, 'Sin bases personalizadas registradas.')); return; }
        tabla.appendChild(el('table', {}, [
          el('tr', {}, ['Base', 'Cantidad real', esAdmin ? '' : null].filter(Boolean).map((t) => el('th', {}, t))),
          el('tbody', {}, d.bases_reales.map((b) => el('tr', {}, [
            el('td', {}, b.nombre), el('td', { class: 'num' }, UI.cantidad(b.cantidad_real)),
            esAdmin ? el('td', {}, el('button', { class: 'boton-texto', onclick: async () => {
              try {
                await Api.del(`ordenes/${o.id}/base/${b.id}?empresa_id=${empresaId}`);
                await verOrden(o.id);  // se redibuja todo para que la base quitada vuelva a estar disponible en la lista
                mensaje('Registro eliminado.');
              } catch (e) { mensaje(e.mensaje, 'error'); }
            } }, 'Quitar')) : null,
          ]))),
        ]));
      }
      panel.appendChild(tabla);
      if (esAdmin) {
        const disponibles = personalizadas.filter((b) => !d.bases_reales.some((r) => r.base_id === b.id));
        if (disponibles.length > 0) {
          const selB = el('select', {}, disponibles.map((b) => el('option', { value: b.id }, b.nombre)));
          const iCant = el('input', { type: 'number', step: 'any', placeholder: 'Cantidad real' });
          const btn = el('button', { class: 'secundario' }, 'Agregar');
          btn.addEventListener('click', async () => {
            try {
              const r = await Api.post(`ordenes/${o.id}/base`, { base_id: Number(selB.value), cantidad_real: iCant.value, empresa_id: empresaId });
              const b = disponibles.find((x) => x.id === Number(selB.value));
              d.bases_reales.push({ id: r.id, base_id: b.id, cantidad_real: Number(iCant.value), nombre: b.nombre, codigo: b.codigo });
              await verOrden(o.id);
              mensaje('Base real agregada.');
            } catch (e) { mensaje(e.mensaje, 'error'); }
          });
          panel.appendChild(el('div', { class: 'filtros' }, [el('label', {}, ['Base', selB]), el('label', {}, ['Cantidad real', iCant]), btn]));
        }
      }
      return panel;
    }

    function seccionCierre(d) {
      const previa = d.orden;  // si la orden se reabrió, se conservan los valores con que se había cerrado
      const iCantProd = el('input', { type: 'number', step: 'any', placeholder: 'Cantidad producida', value: previa.cantidad_producida > 0 ? String(previa.cantidad_producida) : '' });
      const iEnProceso = el('input', { type: 'number', step: 'any', placeholder: '0', value: String(previa.unidades_en_proceso || 0) });
      const iHorasMaq = el('input', { type: 'number', step: 'any', placeholder: '0', value: String(previa.horas_maquina_reales || 0) });
      const panel = el('div', { class: 'panel' }, [
        el('h3', {}, 'Cerrar orden y calcular costo real'),
        el('p', { class: 'mod-desc' }, 'Al cerrar, el sistema calcula el costo real de MP, MOD y CIF, y las variaciones frente al estándar. La orden queda bloqueada para edición.'),
        el('div', { class: 'filtros', style: 'margin-top:1em' }, [
          el('label', {}, ['Cantidad producida', iCantProd]), el('label', {}, ['Unidades en proceso', iEnProceso]),
          el('label', {}, ['Horas máquina reales', iHorasMaq]),
          el('button', { class: 'primario', onclick: cerrar }, 'Cerrar orden'),
        ]),
      ]);
      async function cerrar() {
        confirmar('¿Cerrar esta orden de producción? Después de cerrarla no podrás editar sus consumos.', async () => {
          try {
            await Api.post(`ordenes/${d.orden.id}/cerrar`, {
              cantidad_producida: iCantProd.value, unidades_en_proceso: iEnProceso.value,
              horas_maquina_reales: iHorasMaq.value, empresa_id: empresaId,
            });
            mensaje('Orden cerrada. Costo real y variaciones calculados.');
            window.scrollTo(0, 0);
            await verOrden(d.orden.id);  // muestra el resultado de inmediato, en vez de volver a la lista
          } catch (e) { mensaje(e.mensaje, 'error'); }
        }, 'Cerrar orden');
      }
      return panel;
    }

    function seccionResultado(d) {
      const cr = d.costo_real;
      const frag = el('div', {}, []);
      frag.appendChild(el('div', { class: 'tarjetas-kpi' }, [
        kpi('Costo real total', cr.total), kpi('Costo real unitario', cr.total_unitario),
        kpi('Unidades producidas', d.orden.cantidad_producida, false),
      ]));
      frag.appendChild(el('div', { class: 'panel' }, [
        el('h3', {}, 'Variaciones'),
        el('table', {}, [
          el('tr', {}, ['Variación', 'Monto', 'Clasificación'].map((t) => el('th', {}, t))),
          el('tbody', {}, d.variaciones.map((v) => el('tr', {}, [
            el('td', {}, ETIQUETAS_VAR[v.tipo] || v.tipo), el('td', { class: 'num' }, UI.moneda(v.monto)),
            el('td', {}, el('span', { class: 'badge ' + v.clasificacion }, v.clasificacion)),
          ]))),
        ]),
      ]));
      return frag;
    }

    function kpi(etiqueta, valor, moneda) {
      return el('div', { class: 'kpi' }, [
        el('div', { class: 'valor' }, moneda === false ? String(valor) : '$ ' + UI.moneda(valor)),
        el('div', { class: 'etiqueta' }, etiqueta),
      ]);
    }
  }

  return { render };
})();
