/* Administración de usuarios (solo administrador): rol, permisos por módulo para estudiantes, y bitácora. */
const ModuloUsuarios = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar, marcarErrores } = UI;

  async function render(cont, meta) {
    cont.innerHTML = '';
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Usuarios'),
        el('p', { class: 'mod-desc' }, 'El administrador tiene acceso total. Para un estudiante, elige módulo por módulo qué puede crear, editar o eliminar; todo lo demás queda solo de consulta.')]),
      el('button', { class: 'primario', onclick: () => abrirFormulario(null) }, 'Nuevo usuario'),
    ]));
    const envoltorio = el('div', { class: 'tabla-envoltorio' });
    cont.appendChild(envoltorio);
    let usuarios = await Api.get('usuarios');
    dibujar();

    function resumenPermisos(u) {
      if (u.rol === 'administrador') return 'Acceso total';
      const activos = meta.modulos_permisos.filter((m) => u.permisos && u.permisos[m.id]);
      if (activos.length === 0) return 'Solo consulta';
      return activos.map((m) => m.titulo).join(', ');
    }

    function dibujar() {
      envoltorio.innerHTML = '';
      const filas = usuarios.map((u) => el('tr', {}, [
        el('td', {}, u.username), el('td', {}, u.nombre),
        el('td', {}, el('span', { class: 'badge ' + (u.rol === 'administrador' ? 'rol-admin' : 'rol-estudiante') }, u.rol === 'administrador' ? 'Administrador' : 'Estudiante')),
        el('td', { style: 'white-space:normal; max-width:300px; color:var(--tinta-suave)' }, resumenPermisos(u)),
        el('td', {}, el('span', { class: 'badge ' + (u.activo ? 'favorable' : 'neutra') }, u.activo ? 'Activo' : 'Inactivo')),
        el('td', {}, el('div', { class: 'acciones-fila' }, [
          el('button', { onclick: () => abrirFormulario(u) }, 'Editar'),
          u.id !== meta.usuario.id ? el('button', { onclick: () => eliminar(u) }, 'Eliminar') : null,
        ])),
      ]));
      envoltorio.appendChild(el('table', {}, [
        el('tr', {}, ['Usuario', 'Nombre', 'Rol', 'Permisos', 'Estado', ''].map((t) => el('th', {}, t))),
        el('tbody', {}, filas),
      ]));
    }

    function eliminar(u) {
      confirmar(`¿Eliminar al usuario «${u.username}»? Perderá el acceso al sistema.`, async () => {
        try {
          await Api.del(`usuarios/${u.id}`);
          usuarios = usuarios.filter((x) => x.id !== u.id);
          dibujar();
          mensaje('Usuario eliminado.');
        } catch (e) { mensaje(e.mensaje, 'error'); }
      });
    }

    function abrirFormulario(u) {
      const editando = !!u;
      const iUser = el('input', { type: 'text', value: u ? u.username : '', disabled: editando ? 'disabled' : null });
      const iNombre = el('input', { type: 'text', value: u ? u.nombre : '' });
      const selRol = el('select', {}, [
        el('option', { value: 'estudiante', selected: (!u || u.rol === 'estudiante') ? 'selected' : null }, 'Estudiante'),
        el('option', { value: 'administrador', selected: (u && u.rol === 'administrador') ? 'selected' : null }, 'Administrador'),
      ]);
      const iClave = el('input', { type: 'password', placeholder: editando ? 'Dejar en blanco para no cambiarla' : '' });
      const campos = [
        campo('username', 'Usuario', iUser),
        campo('nombre', 'Nombre completo', iNombre),
        campo('rol', 'Rol', selRol),
        campo('password', editando ? 'Nueva contraseña' : 'Contraseña', iClave),
      ];
      let iActivo;
      if (editando) {
        iActivo = el('select', {}, [
          el('option', { value: '1', selected: u.activo ? 'selected' : null }, 'Activo'),
          el('option', { value: '', selected: !u.activo ? 'selected' : null }, 'Inactivo'),
        ]);
        campos.push(campo('activo', 'Estado', iActivo));
      }

      const permisosActuales = (editando && u.permisos) || {};
      const checks = {};
      const panelPermisos = el('div', { class: 'campo' }, [
        el('label', {}, 'Puede crear, editar y eliminar en:'),
        el('div', { style: 'display:grid; grid-template-columns:1fr 1fr; gap:.4em .8em; margin-top:.3em' },
          meta.modulos_permisos.map((m) => {
            const chk = el('input', { type: 'checkbox', id: `perm-${m.id}`, checked: permisosActuales[m.id] ? 'checked' : null });
            checks[m.id] = chk;
            return el('label', { style: 'display:flex; align-items:center; gap:.5em; font-weight:400; font-size:.88em; color:var(--tinta)' }, [chk, m.titulo]);
          })),
        el('p', { style: 'font-size:.76em; color:var(--tinta-tenue); margin-top:.6em' },
          'Todo lo que no marques queda solo de consulta para este usuario. La gestión de usuarios y el registro de actividad son exclusivos del administrador.'),
      ]);

      function actualizarVisibilidadPermisos() {
        panelPermisos.classList.toggle('oculto', selRol.value !== 'estudiante');
      }
      selRol.addEventListener('change', actualizarVisibilidadPermisos);

      const nodo = el('div', {}, campos);
      const wrap = el('div', {}, [
        el('h3', {}, editando ? 'Editar usuario' : 'Nuevo usuario'),
        nodo,
        panelPermisos,
        el('div', { class: 'modal-acciones' }, [
          el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
          el('button', { class: 'primario', id: 'btn-guardar' }, 'Guardar'),
        ]),
      ]);
      abrirModal(wrap);
      actualizarVisibilidadPermisos();

      wrap.querySelector('#btn-guardar').addEventListener('click', async () => {
        const permisos = {};
        for (const [id, chk] of Object.entries(checks)) permisos[id] = chk.checked;
        const cuerpo = { username: iUser.value, nombre: iNombre.value, rol: selRol.value, password: iClave.value, permisos };
        if (editando) cuerpo.activo = !!iActivo.value;
        try {
          if (editando) await Api.put(`usuarios/${u.id}`, cuerpo);
          else await Api.post('usuarios', cuerpo);
          cerrarModal();
          usuarios = await Api.get('usuarios');
          dibujar();
          mensaje(editando ? 'Usuario actualizado.' : 'Usuario creado.');
        } catch (e) {
          marcarErrores(nodo, e.campos);
          mensaje(e.mensaje, 'error');
        }
      });
    }

    function campo(nombre, etiqueta, input) {
      return el('div', { class: 'campo', 'data-campo': nombre }, [
        el('label', {}, etiqueta), input, el('p', { class: 'msg-error oculto' }),
      ]);
    }
  }

  async function renderBitacora(cont) {
    cont.innerHTML = '';
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [el('h2', {}, 'Registro de actividades')]));
    const envoltorio = el('div', { class: 'tabla-envoltorio' });
    cont.appendChild(envoltorio);
    const filas = await Api.get('bitacora?limite=300');
    if (filas.length === 0) {
      envoltorio.appendChild(el('div', { class: 'vacio' }, 'Todavía no hay actividad registrada.'));
      return;
    }
    envoltorio.appendChild(el('table', {}, [
      el('tr', {}, ['Fecha', 'Usuario', 'Acción', 'Módulo', 'Detalle'].map((t) => el('th', {}, t))),
      el('tbody', {}, filas.map((f) => el('tr', {}, [
        el('td', {}, f.fecha), el('td', {}, f.usuario || '—'), el('td', {}, f.accion),
        el('td', {}, f.entidad || '—'), el('td', {}, f.detalle || ''),
      ]))),
    ]));
  }

  return { render, renderBitacora };
})();
