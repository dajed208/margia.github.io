/* Reportes: descarga en CSV (se abre directamente en Excel) e impresión / PDF vía el navegador. */
const ModuloReportes = (() => {
  const { el, mensaje } = UI;

  const REPORTES = [
    { id: 'hoja_costos', titulo: 'Hoja de costos', desc: 'Costo estándar de MP, MOD y CIF por producto, con margen frente al precio de venta.' },
    { id: 'materiales', titulo: 'Reporte de materiales', desc: 'Listado de materias primas con su costo estándar, proveedor y eficiencia.' },
    { id: 'mod', titulo: 'Reporte de mano de obra', desc: 'Trabajadores con salario, cargas y tarifa estándar por hora.' },
    { id: 'cif', titulo: 'Reporte de CIF', desc: 'Conceptos de CIF con su base de aplicación, presupuesto y valor real.' },
    { id: 'produccion', titulo: 'Reporte de producción', desc: 'Todas las órdenes de producción, planeadas vs. producidas.' },
    { id: 'variaciones', titulo: 'Reporte de variaciones', desc: 'Todas las variaciones calculadas al cerrar cada orden.' },
    { id: 'inventario', titulo: 'Reporte de inventario', desc: 'Existencias, costo promedio y valor del inventario de cada materia prima.' },
    { id: 'historico_costos', titulo: 'Histórico del costo estándar', desc: 'Costo estándar guardado de cada producto en cada periodo cerrado.' },
    { id: 'estado_costos_produccion', titulo: 'Estado de costos de producción', desc: 'Costo real de MP, MOD y CIF por orden terminada.' },
  ];

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    if (!empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa arriba para generar reportes.'));
      return;
    }
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Reportes'),
        el('p', { class: 'mod-desc' }, 'Descarga cada reporte en Excel (.xlsx) o en PDF con el logo y los colores de la empresa, o imprímelo (y guárdalo como PDF) desde el navegador.')]),
    ]));

    const lista = el('div', { class: 'tabla-envoltorio' });
    lista.appendChild(el('table', {}, [
      el('tr', {}, ['Reporte', 'Descripción', ''].map((t) => el('th', {}, t))),
      el('tbody', {}, REPORTES.map((r) => el('tr', {}, [
        el('td', {}, r.titulo), el('td', {}, r.desc),
        el('td', {}, el('div', { class: 'acciones-fila' }, [
          el('button', { onclick: () => descargar(`reportes/${r.id}`) }, 'Excel'),
          el('button', { onclick: () => descargar(`reportes/${r.id}/pdf`) }, 'PDF'),
          el('button', { onclick: () => imprimir(r) }, 'Vista previa'),
        ])),
      ]))),
    ]));
    cont.appendChild(lista);

    async function descargar(id) {
      try { await Api.descargar(`${id}?empresa_id=${empresaId}`); }
      catch (e) { mensaje(e.mensaje, 'error'); }
    }

    async function imprimir(r) {
      const zona = el('div', { class: 'panel', id: 'zona-impresion' }, [el('p', { class: 'mod-desc' }, 'Cargando…')]);
      cont.querySelectorAll('#zona-impresion').forEach((n) => n.remove());
      cont.appendChild(zona);
      let texto;
      try {
        const res = await fetch(`/api/reportes/${r.id}/vista?empresa_id=${empresaId}`, {
          headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token') },
        });
        texto = await res.text();
      } catch (e) {
        zona.innerHTML = ''; zona.appendChild(el('p', {}, 'No se pudo generar el reporte.'));
        return;
      }
      const filas = texto.replace(/^\ufeff/, '').trim().split('\n').map((l) => l.split(';'));
      zona.innerHTML = '';
      zona.appendChild(el('div', { class: 'mod-cabeza' }, [
        el('h3', {}, r.titulo),
        el('button', { class: 'primario', onclick: () => window.print() }, 'Imprimir'),
      ]));
      zona.appendChild(el('div', { class: 'tabla-envoltorio' }, [
        el('table', {}, [
          el('tr', {}, filas[0].map((t) => el('th', {}, t))),
          el('tbody', {}, filas.slice(1).map((f) => el('tr', {}, f.map((v) => el('td', {}, v))))),
        ]),
      ]));
    }
  }

  return { render };
})();
