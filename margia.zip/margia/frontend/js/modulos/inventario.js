/* Inventario de materias primas: existencias, costo promedio, alertas de reposición y kardex. */
const ModuloInventario = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar, marcarErrores, moneda, cantidad } = UI;

  const ESTADOS = {
    ok: ['favorable', 'Normal'], bajo: ['desfavorable', 'Reponer'],
    negativo: ['desfavorable', 'Negativo'], sin_datos: ['neutra', 'Sin movimientos'],
  };

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    if (!empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa en el menú lateral para ver su inventario.'));
      return;
    }
    const puede = UI.puedeEscribir(meta, 'inventario');
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Inventario de materias primas'),
        el('p', { class: 'mod-desc' }, 'Existencias valoradas a costo promedio ponderado. Las órdenes de producción descuentan automáticamente lo consumido al cerrarse.')]),
      puede ? el('button', { class: 'primario', onclick: () => nuevoMovimiento() }, 'Registrar movimiento') : null,
    ]));

    let datos;
    try { datos = await Api.get(`inventario/existencias?empresa_id=${empresaId}`); }
    catch (e) { cont.appendChild(el('div', { class: 'vacio' }, e.mensaje)); return; }

    if (datos.materiales.length === 0) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Aún no hay materias primas. Regístralas en «Materias primas» y luego carga sus compras aquí.'));
      return;
    }

    const conMov = datos.materiales.filter((m) => m.con_movimientos);
    const porReponer = datos.materiales.filter((m) => m.estado === 'bajo' || m.estado === 'negativo');
    cont.appendChild(el('div', { class: 'tarjetas-kpi' }, [
      kpi('$ ' + moneda(datos.valor_total), 'Valor total del inventario'),
      kpi(String(conMov.length) + ' / ' + datos.materiales.length, 'Materiales con inventario'),
      kpi(String(porReponer.length), 'Materiales por reponer', porReponer.length ? 'desfavorable' : ''),
    ]));

    if (porReponer.length) {
      cont.appendChild(el('div', { class: 'aviso aviso-alerta' },
        'Por debajo de la existencia mínima: ' + porReponer.map((m) => `${m.descripcion} (${cantidad(m.existencias)})`).join(', ') + '.'));
    }

    const tabla = el('div', { class: 'tabla-envoltorio' });
    tabla.appendChild(el('table', {}, [
      el('thead', {}, el('tr', {}, ['Código', 'Materia prima', 'Existencias', 'Mínimo', 'Costo promedio', 'Costo estándar', 'Valor', 'Estado', '']
        .map((t) => el('th', {}, t)))),
      el('tbody', {}, datos.materiales.map((m) => {
        const [clase, texto] = ESTADOS[m.estado] || ESTADOS.sin_datos;
        return el('tr', {}, [
          el('td', {}, m.codigo), el('td', {}, m.descripcion),
          el('td', { class: 'num' }, cantidad(m.existencias)), el('td', { class: 'num' }, cantidad(m.stock_minimo)),
          el('td', { class: 'num' }, m.con_movimientos ? moneda(m.costo_promedio) : '—'),
          el('td', { class: 'num' }, moneda(m.costo_estandar)),
          el('td', { class: 'num' }, moneda(m.valor)),
          el('td', {}, el('span', { class: 'badge ' + clase }, texto)),
          el('td', {}, el('div', { class: 'acciones-fila' }, [
            el('button', { onclick: () => verKardex(m.id) }, 'Kardex'),
            puede ? el('button', { onclick: () => nuevoMovimiento(m.id) }, 'Movimiento') : null,
          ])),
        ]);
      })),
    ]));
    cont.appendChild(tabla);

    function kpi(valor, etiqueta, clase) {
      return el('div', { class: 'kpi' }, [el('div', { class: 'valor' + (clase ? ' ' + clase : '') }, valor), el('div', { class: 'etiqueta' }, etiqueta)]);
    }

    function nuevoMovimiento(mpId) {
      const selMp = el('select', {}, datos.materiales.map((m) => el('option', { value: m.id, selected: m.id === mpId ? 'selected' : null }, `${m.codigo} — ${m.descripcion}`)));
      const selTipo = el('select', {}, [el('option', { value: 'entrada' }, 'Entrada (compra o ingreso)'), el('option', { value: 'salida' }, 'Salida (uso, merma o ajuste)')]);
      const iCant = el('input', { type: 'number', step: 'any', min: '0' });
      const iCosto = el('input', { type: 'number', step: 'any', min: '0' });
      const iFecha = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
      const iNota = el('input', { type: 'text', maxlength: '200', placeholder: 'Ej. Factura 1234, proveedor…' });
      const campoCosto = campo('costo_unitario', 'Costo unitario de compra', iCosto);
      const nodo = el('div', {}, [
        campo('materia_prima_id', 'Materia prima', selMp), campo('tipo', 'Tipo de movimiento', selTipo),
        el('div', { class: 'grid-2' }, [campo('cantidad', 'Cantidad', iCant), campo('fecha', 'Fecha', iFecha)]),
        campoCosto, campo('nota', 'Nota (opcional)', iNota),
        el('p', { class: 'logo-nota', id: 'nota-salida' }, 'Las salidas se valoran automáticamente al costo promedio vigente.'),
      ]);
      const notaSalida = nodo.querySelector('#nota-salida');
      function ajustar() {
        const esEntrada = selTipo.value === 'entrada';
        campoCosto.classList.toggle('oculto', !esEntrada);
        notaSalida.classList.toggle('oculto', esEntrada);
      }
      selTipo.addEventListener('change', ajustar);
      const wrap = el('div', {}, [el('h3', {}, 'Registrar movimiento de inventario'), nodo,
        el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
          el('button', { class: 'primario', id: 'btn-mov' }, 'Guardar')])]);
      abrirModal(wrap);
      ajustar();
      wrap.querySelector('#btn-mov').addEventListener('click', async () => {
        try {
          await Api.post('inventario/movimientos', {
            materia_prima_id: Number(selMp.value), tipo: selTipo.value, cantidad: iCant.value,
            costo_unitario: iCosto.value, fecha: iFecha.value, nota: iNota.value, empresa_id: empresaId,
          });
          cerrarModal(); mensaje('Movimiento registrado.'); window.App.recargar();
        } catch (e) { marcarErrores(nodo, e.campos); mensaje(e.mensaje, 'error'); }
      });
    }

    async function verKardex(mpId) {
      cont.innerHTML = '';
      let k;
      try { k = await Api.get(`inventario/kardex/${mpId}?empresa_id=${empresaId}`); }
      catch (e) { cont.appendChild(el('div', { class: 'vacio' }, e.mensaje)); return; }
      cont.appendChild(el('div', { class: 'mod-cabeza' }, [
        el('div', {}, [el('h2', {}, `Kardex — ${k.materia.descripcion}`),
          el('p', { class: 'mod-desc' }, `${k.materia.codigo} · Existencias: ${cantidad(k.existencias)} · Costo promedio: $ ${moneda(k.costo_promedio)}`)]),
        el('button', { class: 'secundario', onclick: () => window.App.recargar() }, '← Volver al inventario'),
      ]));
      const tabla = el('div', { class: 'tabla-envoltorio' });
      if (k.movimientos.length === 0) {
        tabla.appendChild(el('div', { class: 'vacio' }, 'Esta materia prima aún no tiene movimientos.'));
      } else {
        tabla.appendChild(el('table', {}, [
          el('thead', {}, el('tr', {}, ['Fecha', 'Tipo', 'Cantidad', 'Costo unitario', 'Saldo', 'Costo promedio', 'Nota', ''].map((t) => el('th', {}, t)))),
          el('tbody', {}, k.movimientos.map((m) => el('tr', {}, [
            el('td', {}, m.fecha),
            el('td', {}, el('span', { class: 'badge ' + (m.tipo === 'entrada' ? 'favorable' : 'neutra') }, m.tipo === 'entrada' ? 'Entrada' : 'Salida')),
            el('td', { class: 'num' }, cantidad(m.cantidad)), el('td', { class: 'num' }, moneda(m.costo_unitario)),
            el('td', { class: 'num' }, cantidad(m.saldo)), el('td', { class: 'num' }, moneda(m.costo_promedio)),
            el('td', { style: 'white-space:normal' }, m.nota || ''),
            el('td', {}, (puede && !m.orden_id) ? el('button', { class: 'boton-texto', onclick: () => eliminar(m) }, 'Eliminar') : null),
          ]))),
        ]));
      }
      cont.appendChild(tabla);

      function eliminar(m) {
        confirmar(`¿Eliminar este movimiento de ${m.tipo} por ${m.cantidad}? Se recalcularán existencias y costo promedio.`, async () => {
          try {
            await Api.del(`inventario/movimientos/${m.id}?empresa_id=${empresaId}`);
            mensaje('Movimiento eliminado.'); verKardex(mpId);
          } catch (e) { mensaje(e.mensaje, 'error'); }
        });
      }
    }

    function campo(nombre, etiqueta, input) {
      return el('div', { class: 'campo', 'data-campo': nombre }, [el('label', {}, etiqueta), input, el('p', { class: 'msg-error oculto' })]);
    }
  }

  return { render };
})();
