/* Respaldo y restauración de la base de datos (administrador) y cambio de contraseña propia (todos). */
const ModuloSistema = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar, marcarErrores } = UI;

  async function renderRespaldo(cont) {
    cont.innerHTML = '';
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Respaldo de la información'),
        el('p', { class: 'mod-desc' }, 'Toda la información del sistema vive en un solo archivo. Descarga una copia con frecuencia y guárdala fuera de este computador (una memoria USB o tu nube).')]),
    ]));

    const btnDescargar = el('button', { class: 'primario' }, 'Descargar respaldo ahora');
    btnDescargar.addEventListener('click', async () => {
      btnDescargar.disabled = true;
      try { await Api.descargar('respaldo'); mensaje('Respaldo descargado.'); }
      catch (e) { mensaje(e.mensaje, 'error'); }
      finally { btnDescargar.disabled = false; }
    });
    cont.appendChild(el('div', { class: 'panel' }, [
      el('h3', {}, 'Crear un respaldo'),
      el('p', { class: 'mod-desc', style: 'margin-bottom:1em' }, 'Se descarga un archivo .db con la fecha de hoy. Incluye empresas, costos, producción, inventario, usuarios y el registro de actividad.'),
      btnDescargar,
    ]));

    const inputArchivo = el('input', { type: 'file', accept: '.db', class: 'oculto' });
    const btnRestaurar = el('button', { class: 'secundario peligro' }, 'Restaurar desde un archivo…');
    btnRestaurar.addEventListener('click', () => inputArchivo.click());
    inputArchivo.addEventListener('change', () => {
      const archivo = inputArchivo.files[0];
      inputArchivo.value = '';
      if (!archivo) return;
      confirmar(`¿Restaurar desde «${archivo.name}»? Toda la información actual se reemplazará por la del respaldo. `
        + 'El sistema guarda una copia de seguridad de los datos actuales antes de restaurar.', async () => {
        try {
          const res = await fetch('/api/restaurar', {
            method: 'POST', body: await archivo.arrayBuffer(),
            headers: { Authorization: 'Bearer ' + sessionStorage.getItem('token'), 'Content-Type': 'application/octet-stream' },
          });
          const data = await res.json().catch(() => ({}));
          if (!res.ok) throw { mensaje: data.error || 'No se pudo restaurar el respaldo.' };
          mensaje('Respaldo restaurado. Recargando…');
          setTimeout(() => location.reload(), 1200);
        } catch (e) { mensaje(e.mensaje || 'No se pudo restaurar el respaldo.', 'error'); }
      }, 'Restaurar');
    });
    cont.appendChild(el('div', { class: 'panel' }, [
      el('h3', {}, 'Restaurar un respaldo'),
      el('p', { class: 'mod-desc', style: 'margin-bottom:1em' }, 'Útil si cambias de computador o necesitas volver a un punto anterior. Los datos actuales se reemplazan por completo.'),
      btnRestaurar, inputArchivo,
    ]));
  }

  function abrirCambioClave(obligatorio) {
    const iActual = el('input', { type: 'password', autocomplete: 'current-password' });
    const iNueva = el('input', { type: 'password', autocomplete: 'new-password' });
    const iRepetir = el('input', { type: 'password', autocomplete: 'new-password' });
    const nodo = el('div', {}, [
      campo('actual', 'Contraseña actual', iActual),
      campo('nueva', 'Contraseña nueva (mínimo 6 caracteres)', iNueva),
      campo('repetir', 'Repite la contraseña nueva', iRepetir),
    ]);
    const wrap = el('div', {}, [
      el('h3', {}, 'Cambiar contraseña'),
      obligatorio ? el('div', { class: 'aviso aviso-alerta' }, 'Estás usando la contraseña que trae el sistema de fábrica, que es pública. Cámbiala para proteger tu información.') : null,
      nodo,
      el('div', { class: 'modal-acciones' }, [el('button', { class: 'secundario', onclick: cerrarModal }, obligatorio ? 'Más tarde' : 'Cancelar'),
        el('button', { class: 'primario', id: 'btn-clave' }, 'Guardar contraseña')]),
    ]);
    abrirModal(wrap);
    iActual.focus();
    wrap.querySelector('#btn-clave').addEventListener('click', async () => {
      marcarErrores(nodo, {});
      if (iNueva.value !== iRepetir.value) { marcarErrores(nodo, { repetir: 'Las contraseñas no coinciden.' }); return; }
      if (iNueva.value === iActual.value) { marcarErrores(nodo, { nueva: 'La contraseña nueva debe ser distinta a la actual.' }); return; }
      try {
        await Api.post('cambiar-clave', { actual: iActual.value, nueva: iNueva.value });
        cerrarModal(); mensaje('Contraseña actualizada.');
        document.getElementById('aviso-clave')?.remove();
        if (window.App) window.App.claveCambiada();
      } catch (e) { marcarErrores(nodo, e.campos); mensaje(e.mensaje, 'error'); }
    });
  }

  function campo(nombre, etiqueta, input) {
    return el('div', { class: 'campo', 'data-campo': nombre }, [el('label', {}, etiqueta), input, el('p', { class: 'msg-error oculto' })]);
  }

  return { renderRespaldo, abrirCambioClave };
})();
