/* Hoja de costo estándar: receta de materiales por producto y cálculo de MP + MOD + CIF. */
const ModuloCosteo = (() => {
  const { el, mensaje, abrirModal, cerrarModal, confirmar } = UI;

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    if (!empresaId) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Selecciona una empresa arriba a la derecha para ver la hoja de costo.'));
      return;
    }
    const esAdmin = UI.puedeEscribir(meta, 'productos');
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Hoja de costo estándar'),
        el('p', { class: 'mod-desc' }, 'Costo de materiales, mano de obra y CIF por unidad de producto.')]),
      el('div', { class: 'botones-cabeza' }, ModuloEntidad.botonesExcel('recetas', 'Recetas (hoja de costo estándar)', empresaId, esAdmin)),
    ]));

    const productos = await Api.get(`productos?empresa_id=${empresaId}`);
    if (productos.length === 0) {
      cont.appendChild(el('div', { class: 'vacio' }, 'Primero registra al menos un producto en «Productos».'));
      return;
    }
    const filtros = el('div', { class: 'filtros' });
    const selProd = el('select', {}, productos.map((p) => el('option', { value: p.id }, `${p.codigo} — ${p.descripcion}`)));
    filtros.appendChild(el('label', {}, ['Producto', selProd]));
    const periodos = await Api.get(`periodos?empresa_id=${empresaId}`);
    const selPer = el('select', {}, periodos.length
      ? periodos.map((p) => el('option', { value: p.id, selected: p.estado === 'abierto' && p === periodos.find((x) => x.estado === 'abierto') ? 'selected' : null }, p.nombre))
      : [el('option', { value: '' }, 'Sin periodos')]);
    filtros.appendChild(el('label', {}, ['Periodo (base del CIF)', selPer]));
    selPer.addEventListener('change', () => dibujarHoja(Number(selProd.value)));
    cont.appendChild(filtros);

    const zonaReceta = el('div', { class: 'panel' });
    const zonaBases = el('div', { class: 'panel' });
    const zonaHoja = el('div');
    cont.appendChild(zonaReceta);
    cont.appendChild(zonaBases);
    cont.appendChild(zonaHoja);

    selProd.addEventListener('change', cargar);
    await cargar();

    async function cargar() {
      const productoId = Number(selProd.value);
      await dibujarReceta(productoId);
      await dibujarBasesPersonalizadas(productoId);
      await dibujarHoja(productoId);
    }

    async function dibujarReceta(productoId) {
      zonaReceta.innerHTML = '';
      zonaReceta.appendChild(el('h3', {}, 'Materiales de la receta'));
      let receta, materiasPrimas;
      try {
        [receta, materiasPrimas] = await Promise.all([
          Api.get(`receta/${productoId}?empresa_id=${empresaId}`),
          Api.get(`materias_primas?empresa_id=${empresaId}`),
        ]);
      } catch (e) {
        zonaReceta.appendChild(el('p', {}, e.mensaje));
        return;
      }
      if (receta.length === 0) {
        zonaReceta.appendChild(el('p', { class: 'mod-desc' }, 'Este producto no tiene materiales asignados todavía.'));
      } else {
        const filas = receta.map((r) => el('tr', {}, [
          el('td', {}, r.codigo), el('td', {}, r.descripcion),
          el('td', { class: 'num' }, UI.cantidad(r.cantidad_estandar)),
          el('td', { class: 'num' }, UI.moneda(r.costo_estandar)),
          esAdmin ? el('td', {}, el('button', {
            class: 'boton-texto', onclick: () => {
              confirmar(`¿Quitar «${r.descripcion}» de la receta de este producto?`, async () => {
                try {
                  await Api.del(`receta/${productoId}/${r.id}?empresa_id=${empresaId}`);
                  await cargar();
                  mensaje('Material quitado de la receta.');
                } catch (e) { mensaje(e.mensaje, 'error'); }
              }, 'Quitar');
            },
          }, 'Quitar')) : null,
        ]));
        zonaReceta.appendChild(el('table', {}, [
          el('tr', {}, [el('th', {}, 'Código'), el('th', {}, 'Materia prima'), el('th', {}, 'Cant. estándar'), el('th', {}, 'Costo unitario'), esAdmin ? el('th', {}, '') : null]),
          ...filas,
        ]));
      }
      if (esAdmin) {
        if (materiasPrimas.length === 0) {
          zonaReceta.appendChild(el('p', { class: 'mod-desc' }, 'Registra materias primas en el módulo «Materias primas» para poder agregarlas aquí.'));
        } else {
          const selMp = el('select', {}, materiasPrimas.map((m) => el('option', { value: m.id }, `${m.codigo} — ${m.descripcion}`)));
          const cant = el('input', { type: 'number', step: 'any', min: '0', placeholder: 'Cantidad estándar' });
          const btn = el('button', { class: 'secundario' }, 'Agregar a la receta');
          btn.addEventListener('click', async () => {
            try {
              await Api.post(`receta/${productoId}`, { materia_prima_id: Number(selMp.value), cantidad_estandar: cant.value, empresa_id: empresaId });
              mensaje('Material agregado a la receta.');
              await cargar();
            } catch (e) {
              mensaje(e.mensaje, 'error');
            }
          });
          zonaReceta.appendChild(el('div', { class: 'filtros', style: 'margin-top:1em' }, [
            el('label', {}, ['Materia prima', selMp]),
            el('label', {}, ['Cantidad', cant]),
            btn,
          ]));
        }
      }
    }

    async function dibujarBasesPersonalizadas(productoId) {
      zonaBases.innerHTML = '';
      const todasLasBases = await Api.get(`bases_aplicacion?empresa_id=${empresaId}`);
      const personalizadas = todasLasBases.filter((b) => !b.protegida);
      if (personalizadas.length === 0) {
        zonaBases.classList.add('oculto');
        return;
      }
      zonaBases.classList.remove('oculto');
      zonaBases.appendChild(el('h3', {}, 'Bases de aplicación personalizadas'));
      zonaBases.appendChild(el('p', { class: 'mod-desc' },
        'Cuánto consume una unidad de este producto de cada base que hayas creado en «Bases de aplicación de CIF» (además de las horas de MOD y máquina, que se cargan en «Productos»).'));
      let asignadas;
      try { asignadas = await Api.get(`producto-base/${productoId}?empresa_id=${empresaId}`); }
      catch (e) { zonaBases.appendChild(el('p', {}, e.mensaje)); return; }

      const tabla = el('div', { class: 'tabla-envoltorio', style: 'margin:.8em 0 1em' });
      dibujarTabla();
      function dibujarTabla() {
        tabla.innerHTML = '';
        if (asignadas.length === 0) {
          tabla.appendChild(el('div', { class: 'vacio' }, 'Sin bases personalizadas cargadas para este producto (se asumen 0).'));
          return;
        }
        tabla.appendChild(el('table', {}, [
          el('tr', {}, ['Base', 'Consumo estándar por unidad', esAdmin ? '' : null].filter(Boolean).map((t) => el('th', {}, t))),
          el('tbody', {}, asignadas.map((a) => el('tr', {}, [
            el('td', {}, a.nombre), el('td', { class: 'num' }, UI.cantidad(a.cantidad_estandar)),
            esAdmin ? el('td', {}, el('button', { class: 'boton-texto', onclick: async () => {
              await Api.del(`producto-base/${productoId}/${a.id}?empresa_id=${empresaId}`);
              asignadas = asignadas.filter((x) => x.id !== a.id); dibujarTabla(); mensaje('Base quitada del producto.');
            } }, 'Quitar')) : null,
          ]))),
        ]));
      }
      zonaBases.appendChild(tabla);

      if (esAdmin) {
        const disponibles = personalizadas.filter((b) => !asignadas.some((a) => a.base_id === b.id));
        if (disponibles.length > 0) {
          const selBase = el('select', {}, disponibles.map((b) => el('option', { value: b.id }, b.nombre)));
          const cant = el('input', { type: 'number', step: 'any', min: '0', placeholder: 'Cantidad estándar' });
          const btn = el('button', { class: 'secundario' }, 'Agregar');
          btn.addEventListener('click', async () => {
            try {
              const r = await Api.post(`producto-base/${productoId}`, { base_id: Number(selBase.value), cantidad_estandar: cant.value, empresa_id: empresaId });
              const b = disponibles.find((x) => x.id === Number(selBase.value));
              asignadas.push({ id: r.id, base_id: b.id, cantidad_estandar: Number(cant.value), nombre: b.nombre, codigo: b.codigo });
              await dibujarBasesPersonalizadas(productoId);
              mensaje('Base agregada al producto.');
            } catch (e) { mensaje(e.mensaje, 'error'); }
          });
          zonaBases.appendChild(el('div', { class: 'filtros' }, [el('label', {}, ['Base', selBase]), el('label', {}, ['Cantidad estándar', cant]), btn]));
        }
      }
    }

    async function dibujarHoja(productoId) {
      zonaHoja.innerHTML = '';
      let h;
      try {
        h = await Api.get(`hoja-costo?producto_id=${productoId}&empresa_id=${empresaId}${selPer.value ? '&periodo_id=' + selPer.value : ''}`);
      } catch (e) {
        zonaHoja.appendChild(el('div', { class: 'vacio' }, e.mensaje));
        return;
      }
      (h.advertencias_cif || []).forEach((t) => zonaHoja.appendChild(el('div', { class: 'aviso aviso-alerta' }, t)));
      zonaHoja.appendChild(el('div', { class: 'tarjetas-kpi' }, [
        kpi('Costo materiales', h.costo_mp),
        kpi('Costo mano de obra', h.costo_mod),
        kpi('Costo CIF', h.costo_cif),
        kpi('Costo estándar unitario', h.total, true),
        h.margen !== null ? kpi('Margen frente al precio de venta', h.margen, false, h.margen < 0 ? 'desfavorable' : '') : null,
      ]));
      zonaHoja.appendChild(el('p', { class: 'mod-desc' },
        `Mano de obra: ${UI.cantidad(h.horas_mod_std)} horas estándar × tarifa promedio ${UI.moneda(h.tarifa_mod_promedio)} por hora. `
        + 'El CIF se aplica prorrateando el CIF presupuestado de cada concepto según su base de aplicación entre todos los productos de la empresa.'));
      zonaHoja.appendChild(panelPrecios(h));
    }

    function panelPrecios(h) {
      const iMargen = el('input', { type: 'number', step: 'any', min: '0', max: '95', value: '30', style: 'width:7em' });
      const resultado = el('div');
      function calcular() {
        const m = Math.min(Math.max(Number(iMargen.value) || 0, 0), 95) / 100;
        const sugerido = h.total / (1 - m);
        const filas = [
          ['Precio sugerido', '$ ' + UI.moneda(sugerido), `Para ganar ${(m * 100).toFixed(1)} % sobre el precio de venta, cubriendo el costo estándar total.`],
          ['Costo variable por unidad', '$ ' + UI.moneda(h.costo_variable_unitario), 'Materiales + mano de obra + CIF variable.'],
          ['Costos fijos del periodo', '$ ' + UI.moneda(h.costos_fijos_periodo), 'Suma del CIF fijo presupuestado de la empresa.'],
        ];
        if (h.producto.precio_venta) {
          filas.push(['Margen de contribución', '$ ' + UI.moneda(h.margen_contribucion_unitario), 'Precio de venta actual menos costo variable.']);
          filas.push(['Punto de equilibrio', h.punto_equilibrio_unidades !== null ? `${Math.ceil(h.punto_equilibrio_unidades).toLocaleString('es-CO')} unidades` : 'No alcanzable',
            h.punto_equilibrio_unidades !== null
              ? 'Unidades a vender en el periodo (con el precio actual) para cubrir los costos fijos, suponiendo que solo se vende este producto.'
              : 'El precio de venta actual no cubre el costo variable: cada unidad vendida aumenta la pérdida.']);
        } else {
          filas.push(['Punto de equilibrio', '—', 'Registra un precio de venta en «Productos» para calcularlo.']);
        }
        resultado.innerHTML = '';
        resultado.appendChild(el('table', { class: 'tabla-compacta' }, el('tbody', {}, filas.map(([a, b, c]) =>
          el('tr', {}, [el('td', { style: 'font-weight:600' }, a), el('td', { class: 'num', style: 'font-weight:600' }, b),
            el('td', { style: 'white-space:normal; color:var(--tinta-suave)' }, c)])))));
      }
      iMargen.addEventListener('input', calcular);
      calcular();
      return el('div', { class: 'panel', style: 'margin-top:1.4em' }, [
        el('h3', {}, 'Precio y punto de equilibrio'),
        el('div', { class: 'filtros', style: 'margin:.6em 0 .4em' }, [el('label', {}, ['Margen deseado sobre el precio (%)', iMargen])]),
        resultado,
      ]);
    }

    function kpi(etiqueta, valor, grande, clase) {
      return el('div', { class: 'kpi' + (grande ? ' kpi-destacado' : '') }, [
        el('div', { class: 'valor' + (clase ? ' ' + clase : '') }, '$ ' + UI.moneda(valor)),
        el('div', { class: 'etiqueta' }, etiqueta),
      ]);
    }
  }

  return { render };
})();
