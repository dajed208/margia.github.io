/* Dashboard: KPIs de costo estándar vs real, variaciones y una gráfica simple (sin librerías externas). */
const ModuloDashboard = (() => {
  const { el, moneda } = UI;

  const ETIQUETAS_VAR = {
    precio_materiales: 'Precio materiales', cantidad_materiales: 'Cantidad materiales',
    tarifa_mod: 'Tarifa MOD', eficiencia_mod: 'Eficiencia MOD',
    presupuesto_cif: 'Presupuesto CIF', volumen_cif: 'Volumen CIF',
  };

  // Pasos recomendados, en el orden en que el sistema necesita los datos
  const PASOS = [
    { id: 'empresa', ir: 'empresas', titulo: 'Crea tu empresa', ayuda: 'Razón social, NIT y datos tributarios. Después puedes ponerle logo y colores.' },
    { id: 'periodo', ir: 'periodos', titulo: 'Crea un periodo contable', ayuda: 'Con sus unidades de producción presupuestadas: con ellas se reparte el CIF.' },
    { id: 'materias', ir: 'materias_primas', titulo: 'Registra tus materias primas', ayuda: 'Con su unidad, costo estándar y eficiencia (100 = sin desperdicio).' },
    { id: 'mano_obra', ir: 'trabajadores', titulo: 'Registra la mano de obra', ayuda: 'Solo quienes producen, con las horas trabajadas del mes (unas 192), no las de la semana.' },
    { id: 'cif', ir: 'cif_conceptos', titulo: 'Define los costos indirectos (CIF)', ayuda: 'Arriendo, gas, luz, empaques… con su valor presupuestado del periodo.' },
    { id: 'productos', ir: 'productos', titulo: 'Crea tus productos', ayuda: 'Precio de venta y horas de mano de obra por unidad: el tiempo de una unidad, no de toda la tanda.' },
    { id: 'recetas', ir: 'hoja_costo', titulo: 'Arma la receta de cada producto', ayuda: 'Qué materias primas lleva y cuánto. Ahí mismo ves su costo estándar y su margen.' },
    { id: 'orden', ir: 'ordenes', titulo: 'Registra una orden de producción', ayuda: 'Qué producto vas a fabricar, en qué periodo y cuántas unidades.' },
    { id: 'cierre', ir: 'ordenes', icono: 'cierre', titulo: 'Captura los costos reales y cierra la orden', ayuda: 'Materiales, horas y CIF reales. Al cerrarla verás aquí indicadores, variaciones y gráficos.' },
  ];

  function guia(estado, empresaId) {
    const hechos = PASOS.filter((p) => estado[p.id] && estado[p.id].hecho).length;
    const siguiente = PASOS.find((p) => !(estado[p.id] && estado[p.id].hecho));
    const sinEmpresa = !empresaId;
    const ir = (p) => window.App.irA(p.ir);
    const caja = el('section', { class: 'panel guia', 'aria-label': 'Guía para empezar' });
    caja.appendChild(el('div', { class: 'guia-cabeza' }, [
      el('div', { class: 'guia-titulos' }, [
        el('h3', {}, 'Tu ruta para empezar'),
        el('p', { class: 'mod-desc' }, 'Sigue los pasos en orden: cada uno usa los datos del anterior. Se marcan solos a medida que cargas tu información.'),
      ]),
      siguiente ? el('button', { class: 'primario', onclick: () => ir(siguiente) }, `Continuar: ${siguiente.titulo.charAt(0).toLowerCase()}${siguiente.titulo.slice(1)} →`) : null,
    ]));
    caja.appendChild(el('div', { class: 'guia-progreso' }, [
      el('div', { class: 'guia-barra', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(PASOS.length), 'aria-valuenow': String(hechos) },
        el('span', { style: `width:${(100 * hechos) / PASOS.length}%` })),
      el('span', { class: 'guia-cuenta' }, `${hechos} de ${PASOS.length} pasos`),
    ]));
    const lista = el('ol', { class: 'guia-pasos' });
    PASOS.forEach((p, i) => {
      const e = estado[p.id] || {};
      const bloqueado = sinEmpresa && p.id !== 'empresa';
      const actual = siguiente && siguiente.id === p.id;
      const fila = el('li', { class: 'guia-paso' + (e.hecho ? ' hecho' : '') + (actual ? ' actual' : '') + (bloqueado ? ' bloqueado' : ''), 'data-paso': p.id }, [
        el('span', { class: 'guia-marca', 'aria-label': e.hecho ? 'Hecho' : `Paso ${i + 1}` }, e.hecho ? '✓' : String(i + 1)),
        window.App.tile(p.icono || p.ir),
        el('div', { class: 'guia-texto' }, [
          el('div', { class: 'guia-nombre' }, [p.titulo, actual ? el('span', { class: 'badge rol-estudiante' }, 'Siguiente') : null]),
          el('div', { class: 'guia-ayuda' }, bloqueado ? p.ayuda : (e.hecho ? e.detalle : (e.detalle && !e.detalle.startsWith('Aún no') ? `${e.detalle} ` : '') + p.ayuda)),
        ]),
        bloqueado ? el('span', { class: 'guia-ir deshabilitado' }, 'ir →')
          : el('button', { class: 'guia-ir', onclick: () => ir(p), 'aria-label': `Ir a: ${p.titulo}` }, e.hecho ? 'ver →' : 'ir →'),
      ]);
      if (!bloqueado) fila.addEventListener('click', (ev) => { if (!ev.target.closest('button')) ir(p); });
      lista.appendChild(fila);
    });
    caja.appendChild(lista);
    caja.appendChild(el('div', { class: 'aviso aviso-info guia-excel' }, [
      el('span', { class: 'guia-excel-icono' }, window.App.icono('excel')),
      el('span', {}, ['¿Ya tienes tus datos en Excel? En cada pantalla usa ', el('b', {}, '«Importar desde Excel»'),
        ' (ahí mismo descargas la plantilla) y sáltate los pasos 3 a 7. Impórtalos en este mismo orden.']),
    ]));
    return { caja, completa: hechos === PASOS.length, hechos };
  }

  async function render(cont, meta, empresaId) {
    cont.innerHTML = '';
    cont.appendChild(el('div', { class: 'mod-cabeza' }, [
      el('div', {}, [el('h2', {}, 'Dashboard'), el('p', { class: 'mod-desc' }, 'Costo estándar frente a costo real de las órdenes terminadas.')]),
    ]));
    if (!empresaId) {
      cont.appendChild(guia({ empresa: { hecho: false } }, null).caja);
      return;
    }
    const estado = await Api.get(`primeros-pasos?empresa_id=${empresaId}`);
    const g = guia(estado, empresaId);
    const claveOculta = `guia_oculta_${empresaId}`;
    if (!estado.cierre.hecho) {  // sin órdenes cerradas no hay indicadores: solo la guía
      cont.appendChild(g.caja);
      return;
    }
    if (!g.completa) {  // ya hay indicadores pero faltan pasos: guía plegable
      const oculta = localStorage.getItem(claveOculta) === '1';
      const alternar = el('button', { class: 'boton-texto guia-alternar' },
        oculta ? `Ver guía de inicio (${g.hechos} de ${PASOS.length})` : 'Ocultar guía de inicio');
      alternar.addEventListener('click', () => {
        localStorage.setItem(claveOculta, oculta ? '0' : '1');
        window.App.recargar();
      });
      cont.appendChild(alternar);
      if (!oculta) cont.appendChild(g.caja);
    }

    const [productos, periodos] = await Promise.all([
      Api.get(`productos?empresa_id=${empresaId}`), Api.get(`periodos?empresa_id=${empresaId}`),
    ]);
    const selProd = el('select', {}, [el('option', { value: '' }, 'Todos los productos'), ...productos.map((p) => el('option', { value: p.id }, `${p.codigo} — ${p.descripcion}`))]);
    const selPer = el('select', {}, [el('option', { value: '' }, 'Todos los periodos'), ...periodos.map((p) => el('option', { value: p.id }, p.nombre))]);
    const filtros = el('div', { class: 'filtros' }, [el('label', {}, ['Producto', selProd]), el('label', {}, ['Periodo', selPer])]);
    cont.appendChild(filtros);
    const zona = el('div');
    cont.appendChild(zona);

    selProd.addEventListener('change', cargar);
    selPer.addEventListener('change', cargar);
    await cargar();

    async function cargar() {
      zona.innerHTML = '';
      const q = [`empresa_id=${empresaId}`];
      if (selProd.value) q.push(`producto_id=${selProd.value}`);
      if (selPer.value) q.push(`periodo_id=${selPer.value}`);
      const d = await Api.get(`dashboard?${q.join('&')}`);
      if (d.sin_datos) {
        zona.appendChild(el('div', { class: 'vacio' }, 'Todavía no hay órdenes de producción terminadas para estos filtros. Cierra una orden en «Órdenes de producción» para ver el dashboard.'));
        return;
      }
      const diffClase = d.diferencia_pct > 0 ? 'desfavorable' : (d.diferencia_pct < 0 ? 'favorable' : '');
      zona.appendChild(el('div', { class: 'tarjetas-kpi' }, [
        kpi('Costo estándar unitario', d.costo_estandar_unitario),
        kpi('Costo real unitario', d.costo_real_unitario),
        kpi('Diferencia real vs. estándar', (d.diferencia_pct > 0 ? '+' : '') + d.diferencia_pct.toLocaleString('es-CO', { maximumFractionDigits: 1 }) + ' %', diffClase, true),
        kpi('Costo total de producción', d.costo_total_produccion),
        kpi('Unidades producidas', d.unidades_producidas, '', true),
        kpi('Órdenes terminadas', d.ordenes, '', true),
      ]));

      const panelVar = el('div', { class: 'panel' }, [el('h3', {}, 'Variaciones acumuladas')]);
      const filas = Object.entries(d.variaciones);
      if (filas.length === 0) {
        panelVar.appendChild(el('p', { class: 'mod-desc' }, 'Sin variaciones registradas.'));
      } else {
        panelVar.appendChild(el('table', {}, [
          el('tr', {}, ['Variación', 'Monto', 'Efecto'].map((t) => el('th', {}, t))),
          el('tbody', {}, filas.map(([tipo, monto]) => el('tr', {}, [
            el('td', {}, ETIQUETAS_VAR[tipo] || tipo), el('td', { class: 'num' }, '$ ' + moneda(monto)),
            el('td', {}, el('span', { class: 'badge ' + (monto > 0 ? 'desfavorable' : monto < 0 ? 'favorable' : 'neutra') }, monto > 0 ? 'Desfavorable' : monto < 0 ? 'Favorable' : 'Neutra')),
          ]))),
        ]));
      }
      zona.appendChild(panelVar);

      if (d.serie.length > 0) {
        const panelChart = el('div', { class: 'panel' }, [el('h3', {}, 'Costo unitario por orden: estándar vs. real')]);
        panelChart.appendChild(dibujarGrafico(d.serie));
        zona.appendChild(panelChart);
      }
    }

    function kpi(etiqueta, valor, clase, esTexto) {
      return el('div', { class: 'kpi' }, [
        el('div', { class: 'valor' + (clase ? ' ' + clase : '') }, esTexto ? String(valor) : '$ ' + moneda(valor)),
        el('div', { class: 'etiqueta' }, etiqueta),
      ]);
    }
  }

  function dibujarGrafico(serie) {
    const datos = serie.slice(-12); // últimas 12 órdenes para que siga legible
    const ancho = 760, alto = 300, m = { i: 70, d: 16, s: 18, in: 44 };
    const w = ancho - m.i - m.d, h = alto - m.s - m.in;
    const maxDato = Math.max(1, ...datos.flatMap((d) => [d.estandar_unitario, d.real_unitario]));
    const paso = Math.pow(10, Math.floor(Math.log10(maxDato)));
    const max = Math.ceil((maxDato * 1.12) / paso) * paso;
    const y = (v) => m.s + h - (v / max) * h;
    const grupo = w / datos.length;
    const barra = Math.min(38, grupo * 0.32);
    const colorStd = 'var(--linea-fuerte)', colorReal = 'var(--acento)';
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', `0 0 ${ancho} ${alto}`);
    svg.setAttribute('width', '100%');
    svg.style.maxWidth = ancho + 'px';
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Costo unitario estándar y real por orden de producción');
    const nodo = (tag, attrs, texto) => {
      const n = document.createElementNS(ns, tag);
      for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
      if (texto !== undefined) n.textContent = texto;
      svg.appendChild(n);
      return n;
    };
    for (let k = 0; k <= 4; k++) {
      const val = (max / 4) * k, yy = y(val);
      nodo('line', { x1: m.i, x2: ancho - m.d, y1: yy, y2: yy, stroke: 'var(--linea)', 'stroke-width': 1 });
      nodo('text', { x: m.i - 10, y: yy + 4, 'text-anchor': 'end', 'font-size': 11, fill: 'var(--tinta-suave)' }, '$ ' + Math.round(val).toLocaleString('es-CO'));
    }
    datos.forEach((d, idx) => {
      const cx = m.i + grupo * idx + grupo / 2;
      [[d.estandar_unitario, colorStd, -1, 'Estándar'], [d.real_unitario, colorReal, 1, 'Real']].forEach(([v, color, lado, nombre]) => {
        const x = lado < 0 ? cx - barra - 2 : cx + 2;
        const r = nodo('rect', { x, y: y(v), width: barra, height: Math.max(0, m.s + h - y(v)), fill: color, rx: 3 });
        const t = document.createElementNS(ns, 'title');
        t.textContent = `${d.orden} · ${nombre}: $ ${moneda(v)}`;
        r.appendChild(t);
      });
      nodo('text', { x: cx, y: alto - 22, 'text-anchor': 'middle', 'font-size': 11, fill: 'var(--tinta)', 'font-weight': 600 }, d.orden);
      const dif = d.estandar_unitario ? ((d.real_unitario - d.estandar_unitario) / d.estandar_unitario) * 100 : 0;
      nodo('text', { x: cx, y: alto - 7, 'text-anchor': 'middle', 'font-size': 10,
        fill: dif > 0.05 ? 'var(--alerta)' : dif < -0.05 ? 'var(--bien)' : 'var(--tinta-suave)' },
        (dif > 0 ? '+' : '') + dif.toLocaleString('es-CO', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' %');
    });
    return el('div', {}, [svg, el('div', { class: 'grafico-leyenda' }, [
      el('span', {}, [el('i', { style: 'background:var(--linea-fuerte)' }), 'Costo estándar unitario']),
      el('span', {}, [el('i', { style: 'background:var(--acento)' }), 'Costo real unitario']),
      serie.length > 12 ? el('span', {}, `Últimas 12 de ${serie.length} órdenes`) : null,
    ])]);
  }

  return { render };
})();
