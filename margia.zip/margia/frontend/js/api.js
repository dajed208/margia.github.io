/* Cliente de la API. Guarda el token en memoria (no en localStorage) por sesión de pestaña. */
const Api = (() => {
  let token = sessionStorage.getItem('token') || null;
  let usuario = JSON.parse(sessionStorage.getItem('usuario') || 'null');

  async function llamar(metodo, ruta, cuerpo) {
    const opciones = { method: metodo, headers: {} };
    if (token) opciones.headers['Authorization'] = 'Bearer ' + token;
    opciones.headers['X-Lang'] = (window.I18N ? window.I18N.idioma() : 'es');
    if (cuerpo !== undefined) {
      opciones.headers['Content-Type'] = 'application/json';
      opciones.body = JSON.stringify(cuerpo);
    }
    let res;
    try {
      res = await fetch('/api/' + ruta, opciones);
    } catch (e) {
      throw { status: 0, mensaje: 'No se pudo conectar con el servidor local. Verifica que el programa siga en ejecución.', campos: {} };
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* respuesta vacía */ }
    if (!res.ok) {
      if (res.status === 401) Api.cerrarSesionLocal();
      throw { status: res.status, mensaje: data.error || 'Ocurrió un error inesperado.', campos: data.campos || {} };
    }
    return data;
  }

  return {
    get: (ruta) => llamar('GET', ruta),
    post: (ruta, cuerpo) => llamar('POST', ruta, cuerpo || {}),
    put: (ruta, cuerpo) => llamar('PUT', ruta, cuerpo || {}),
    del: (ruta) => llamar('DELETE', ruta),
    estaConectado: () => !!token,
    usuarioActual: () => usuario,
    async descargar(ruta) {
      const res = await fetch('/api/' + ruta, { headers: token ? { Authorization: 'Bearer ' + token, 'X-Lang': (window.I18N ? window.I18N.idioma() : 'es') } : { 'X-Lang': (window.I18N ? window.I18N.idioma() : 'es') } });
      if (!res.ok) {
        let msg = 'No se pudo generar el reporte.';
        try { msg = (await res.json()).error || msg; } catch (e) { /* ignorar */ }
        throw { status: res.status, mensaje: msg, campos: {} };
      }
      const disposicion = res.headers.get('Content-Disposition') || '';
      const m = disposicion.match(/filename="?([^"]+)"?/);
      const nombre = m ? m[1] : 'reporte.csv';
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = nombre;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    },
    async iniciarSesion(username, password) {
      const r = await llamar('POST', 'login', { username, password });
      token = r.token; usuario = r.usuario;
      sessionStorage.setItem('token', token);
      sessionStorage.setItem('usuario', JSON.stringify(usuario));
      return usuario;
    },
    async cerrarSesion() {
      try { await llamar('POST', 'logout'); } catch (e) { /* ignorar */ }
      Api.cerrarSesionLocal();
    },
    cerrarSesionLocal() {
      token = null; usuario = null;
      sessionStorage.removeItem('token'); sessionStorage.removeItem('usuario');
    },
  };
})();
