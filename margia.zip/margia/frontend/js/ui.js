/* Utilidades de interfaz: mensajes, modal, formularios y tabla genérica a partir de la definición de una entidad. */
const UI = (() => {
  function el(tag, attrs = {}, hijos = []) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else if (v !== null && v !== undefined) n.setAttribute(k, v);
    }
    for (const h of [].concat(hijos)) if (h) n.appendChild(typeof h === 'string' ? document.createTextNode(h) : h);
    return n;
  }

  function moneda(v) {
    const n = Number(v || 0);
    return n.toLocaleString('es-CO', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function cantidad(v) {
    const n = Number(v || 0);
    return n.toLocaleString('es-CO', { maximumFractionDigits: 4 });
  }

  // Alinea a la derecha el encabezado de toda columna cuyas celdas son numéricas.
  function alinearEncabezados(raiz) {
    raiz.querySelectorAll('table').forEach((t) => {
      const todas = [...t.querySelectorAll('tr')];
      const cabecera = todas.find((f) => f.querySelector('th'));
      const filas = todas.filter((f) => !f.querySelector('th'));
      if (!cabecera || !filas.length) return;
      const ths = cabecera.querySelectorAll('th');
      ths.forEach((th, i) => {
        const celdas = [...filas].map((f) => f.children[i]).filter(Boolean);
        if (celdas.length && celdas.every((c) => c.classList.contains('num'))) th.classList.add('num');
      });
    });
  }

  function mensaje(texto, tipo = 'ok') {
    if (tipo === 'error' && (!texto || typeof texto !== 'string')) {
      texto = 'No se pudo completar la acción por un error inesperado. Recarga la página e inténtalo de nuevo; si sigue igual, avísale a soporte.';
    }
    const cont = document.getElementById('mensajes');
    const n = el('div', { class: 'mensaje ' + tipo }, texto);
    cont.appendChild(n);
    setTimeout(() => n.remove(), 4200);
  }

  function cerrarModal() {
    document.getElementById('modal-fondo').classList.add('oculto');
    document.getElementById('modal').innerHTML = '';
    document.getElementById('modal').classList.remove('modal-ancho');
  }

  function abrirModal(contenidoNode) {
    const modal = document.getElementById('modal');
    modal.innerHTML = '';
    modal.appendChild(contenidoNode);
    document.getElementById('modal-fondo').classList.remove('oculto');
  }

  document.getElementById('modal-fondo').addEventListener('click', (e) => {
    if (e.target.id === 'modal-fondo') cerrarModal();
  });

  function confirmar(texto, onSi, etiquetaSi = 'Eliminar') {
    const cuerpo = el('div', { class: 'confirmar' }, [
      el('h3', {}, 'Confirmar'),
      el('p', {}, texto),
      el('div', { class: 'modal-acciones' }, [
        el('button', { class: 'secundario', onclick: cerrarModal }, 'Cancelar'),
        el('button', { class: 'primario', onclick: () => { cerrarModal(); onSi(); } }, etiquetaSi),
      ]),
    ]);
    abrirModal(cuerpo);
  }

  // --- Formulario genérico a partir de la lista de campos de una entidad ---
  function construirFormulario(campos, referencias, valores = {}) {
    const contenedor = el('div');
    const inputs = {};
    for (const c of campos) {
      if (c.calculado) continue;
      const campoDiv = el('div', { class: 'campo', 'data-campo': c.name });
      const label = el('label', {}, c.label + (c.req ? ' *' : ''));
      let input;
      if (c.tipo === 'select' || c.tipo === 'ref') {
        input = el('select', { name: c.name });
        input.appendChild(el('option', { value: '' }, '— Seleccione —'));
        const opciones = c.tipo === 'select' ? c.opciones : (referencias[c.ref] || []);
        for (const o of opciones) {
          const valor = c.tipo === 'select' ? o.valor : o.id;
          const texto = c.tipo === 'select' ? o.texto : (o[c.ref_texto] ? `${o.codigo} — ${o[c.ref_texto]}` : o.codigo);
          input.appendChild(el('option', { value: valor }, texto));
        }
      } else if (c.tipo === 'date') {
        input = el('input', { type: 'date', name: c.name });
      } else if (c.tipo === 'number' || c.tipo === 'percent' || c.tipo === 'int') {
        input = el('input', { type: 'number', step: c.tipo === 'int' ? '1' : 'any', name: c.name });
      } else if (c.tipo === 'email') {
        input = el('input', { type: 'email', name: c.name });
      } else {
        input = el('input', { type: 'text', name: c.name });
      }
      const v = valores[c.name];
      if (v !== undefined && v !== null) input.value = v;
      else if (c.defecto !== undefined) input.value = c.defecto;
      campoDiv.appendChild(label);
      campoDiv.appendChild(input);
      campoDiv.appendChild(el('p', { class: 'msg-error oculto' }));
      contenedor.appendChild(campoDiv);
      inputs[c.name] = input;
    }
    return { nodo: contenedor, inputs };
  }

  function leerFormulario(inputs) {
    const datos = {};
    for (const [nombre, input] of Object.entries(inputs)) datos[nombre] = input.value;
    return datos;
  }

  function marcarErrores(contenedor, campos) {
    contenedor.querySelectorAll('.campo').forEach((d) => {
      d.classList.remove('con-error');
      d.querySelector('.msg-error').classList.add('oculto');
    });
    for (const [nombre, msg] of Object.entries(campos || {})) {
      const d = contenedor.querySelector(`.campo[data-campo="${nombre}"]`);
      if (d) {
        d.classList.add('con-error');
        const p = d.querySelector('.msg-error');
        p.textContent = msg;
        p.classList.remove('oculto');
      }
    }
  }

  function hexARgb(hex) {
    let h = String(hex).replace('#', '');
    if (h.length === 3) h = h.split('').map((c) => c + c).join('');
    const n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbAHex(r, g, b) {
    const c = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
    return '#' + c(r) + c(g) + c(b);
  }
  function mezclarColor(hex, conHex, pct) {
    const [r1, g1, b1] = hexARgb(hex);
    const [r2, g2, b2] = hexARgb(conHex);
    return rgbAHex(r1 + (r2 - r1) * pct, g1 + (g2 - g1) * pct, b1 + (b2 - b1) * pct);
  }
  function oscurecer(hex, pct) { return mezclarColor(hex, '#000000', pct); }
  function aclarar(hex, pct) { return mezclarColor(hex, '#ffffff', pct); }

  function puedeEscribir(meta, modulo) {
    if (!meta || !meta.usuario) return false;
    if (meta.usuario.rol === 'administrador') return true;
    return !!(meta.usuario.permisos && meta.usuario.permisos[modulo]);
  }

  return { el, moneda, cantidad, alinearEncabezados, mensaje, abrirModal, cerrarModal, confirmar, construirFormulario, leerFormulario, marcarErrores, puedeEscribir, oscurecer, aclarar };
})();
