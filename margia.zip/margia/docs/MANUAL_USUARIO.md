# Manual de usuario — Margia

## Ingreso al sistema

Al abrir el programa se abre automáticamente el navegador en la pantalla de inicio de sesión.

- **Administrador:** usuario `admin`, contraseña `admin123`
- **Estudiante (solo consulta):** usuario `estudiante`, contraseña `estudiante123`

La primera vez que entres con una de estas contraseñas, el sistema te pedirá cambiarla y mostrará un aviso en todas las pantallas hasta que lo hagas: son públicas y cualquiera las conoce. Puedes cambiar tu contraseña cuando quieras con **Cambiar contraseña**, en la parte inferior del menú lateral.

## Roles

- **Administrador:** puede crear, editar y eliminar en todos los módulos, y administrar usuarios.
- **Estudiante:** puede ver toda la información pero no puede crear, editar ni eliminar nada. Sirve para practicar o consultar sin riesgo de dañar los datos.

## Guía para empezar (en el Dashboard)

Al entrar, Margia abre el **Dashboard**. Mientras no tengas tu primera orden de producción cerrada, ahí verás **«Tu ruta para empezar»**: los 9 pasos para cargar tu información, en el orden en que el sistema la necesita (cada paso usa datos del anterior):

1. Crea tu empresa · 2. Crea un periodo contable (con sus unidades presupuestadas) · 3. Registra tus materias primas · 4. Registra la mano de obra · 5. Define los costos indirectos (CIF) · 6. Crea tus productos · 7. Arma la receta de cada producto · 8. Registra una orden de producción · 9. Captura los costos reales y cierra la orden.

- **Los pasos se marcan solos**, revisando tus datos reales; no hay que marcar nada a mano. Un paso solo cuenta como hecho si está completo: un periodo sin unidades presupuestadas, un CIF sin valor o un producto sin receta siguen pendientes y la guía te dice qué falta (por ejemplo, «2 de 3 productos tienen receta»).
- **«ir →»** (o un clic en cualquier parte del paso) te lleva a la pantalla de ese paso, y el botón **«Continuar»** te lleva directo al siguiente paso pendiente.
- Si ya tienes tus datos en Excel, impórtalos desde cada pantalla con **«Importar desde Excel»** en este mismo orden.
- Cuando completes los 9 pasos, la guía desaparece y el Dashboard muestra los indicadores. Si después falta algo (por ejemplo, creas un producto nuevo sin receta), la guía vuelve a aparecer sobre los indicadores; puedes plegarla con **«Ocultar guía de inicio»**.

## Primeros pasos

1. Entre a **Empresas** y cree la empresa con la que va a trabajar (código, razón social, NIT y datos tributarios).
2. Arriba a la derecha, en el selector de empresa, elija la empresa recién creada. Los siguientes módulos usan esa empresa.
3. Cree un **periodo contable** (por ejemplo, "2026" del 1 de enero al 31 de diciembre).
4. Revise las **unidades de medida** (ya vienen precargadas: kilogramo, gramo, litro, unidad, hora, etc.) y agregue las que hagan falta.
5. Cree sus **centros de costo**.
6. Registre sus **productos**, indicando las horas de mano de obra y de máquina que normalmente toma fabricar una unidad.
7. Registre sus **materias primas**, con su costo estándar y su eficiencia (100 si no hay desperdicio esperado).
8. Registre su **mano de obra directa** (trabajadores): con el salario, las prestaciones y las cargas laborales, el sistema calcula solo la tarifa estándar por hora.
9. Registre sus **conceptos de CIF** (costos indirectos como arriendo, energía, depreciación), indicando si son fijos o variables y cómo se reparten (por mano de obra, por horas máquina o por unidades producidas).

## Hoja de costo estándar

En el menú **Hoja de costo**, elija un producto:

- Arme su receta agregando las materias primas y la cantidad estándar que necesita una unidad.
- El sistema muestra automáticamente:
  - **Costo de materiales:** suma de cada material (ajustado por su eficiencia) por su costo estándar.
  - **Costo de mano de obra:** horas estándar del producto por la tarifa promedio de sus trabajadores.
  - **Costo CIF:** cada concepto de CIF presupuestado se reparte entre los productos según la base que usted eligió (mano de obra, horas máquina o unidades).
  - **Costo estándar unitario total** y el **margen** frente al precio de venta del producto.

## Personalizar con el logo y los colores de la empresa

En **Empresas**, cada empresa tiene dos acciones adicionales junto a Editar y Eliminar:

- **Logo:** sube una imagen (PNG, JPG, WEBP o SVG, hasta 250 KB). Aparece en el menú lateral junto al nombre de la empresa activa.
- **Colores:** elige el color principal (el que usan los botones, enlaces y el elemento activo del menú), el fondo del menú lateral y el fondo general de la página. Los tonos más oscuros y más claros que necesita la interfaz (por ejemplo, para el efecto al pasar el mouse) se calculan automáticamente a partir del color principal que elijas, así que no hace falta ajustarlos uno por uno.

Los colores se aplican en el momento, mientras esa empresa esté activa en el menú lateral, y quedan guardados para la próxima vez que la selecciones. El botón «Restablecer predeterminados» regresa a la paleta original del sistema.

## Bases de aplicación del CIF

El sistema trae 3 bases incorporadas (mano de obra directa, horas máquina y unidades producidas), pero puedes agregar las tuyas propias desde **Bases de aplicación de CIF** — por ejemplo, kilos procesados, número de lotes, metros cuadrados, o cualquier criterio que tenga sentido para prorratear un costo indirecto en tu negocio.

- Las 3 bases incorporadas no se pueden eliminar ni cambiarles el código (para no romper los cálculos existentes), pero sí puedes renombrarlas si prefieres otro texto.
- Al crear una base propia, dos lugares más se activan automáticamente:
  - En **Hoja de costo**, debajo de la receta, aparece un panel para indicar cuánto consume una unidad de cada producto de esa base (por ejemplo, "0.2 kilos por unidad").
  - Al registrar producción, en la orden aparece una sección para anotar cuánto se consumió realmente de esa base en esa orden.
- En **CIF**, al crear o editar un concepto, eliges la base de aplicación de una lista que incluye las incorporadas y las que hayas creado.

**Avisos de CIF que no se aplica.** Si un concepto de CIF usa una base y **ningún producto tiene consumo estándar de esa base** (por ejemplo, el CIF usa la base «Horas de mano de obra» pero todos tus productos tienen 0 horas), ese costo no se puede repartir. Margia no inventa una cifra: **no lo aplica** y te lo dice con un aviso amarillo en la Hoja de costo y dentro de la orden de producción, indicando dónde cargar el dato que falta. Mientras ese aviso aparezca, los costos de tus productos están **incompletos** (les falta ese CIF).

## Registrar la producción real

1. Vaya a **Órdenes de producción** y cree una orden indicando el producto, el periodo y la cantidad planeada.
2. Mientras la orden esté abierta, registre ahí mismo:
   - El **consumo real de materiales** (cantidad y precio pagado).
   - Las **horas reales de mano de obra** (por trabajador, con su tarifa real).
   - El **CIF real** de cada concepto que aplique a esa orden.
3. Cuando termine la producción, indique la **cantidad producida** (y, si aplica, unidades en proceso y horas máquina reales) y pulse **Cerrar orden**. El sistema calcula automáticamente:
   - El costo real total y unitario (materiales, mano de obra y CIF).
   - Las seis variaciones: precio y cantidad de materiales, tarifa y eficiencia de mano de obra, y presupuesto y volumen de CIF, cada una marcada como favorable o desfavorable.
4. Una orden cerrada no se puede editar; queda como historial consultable.

**Nota sobre el CIF:** para que la tasa de aplicación del CIF sea correcta, cargue el campo **«Unidades de producción presupuestadas»** al crear el periodo contable (en **Periodos**). Si lo deja en 0, el sistema usa una aproximación menos precisa.


### Corregir o eliminar una orden (con el código del administrador)

Si una orden tiene un error, se puede **editar, reabrir o eliminar**, pero **solo con un código de autorización que conoce el administrador**. Llenar una orden abierta (consumos, horas, CIF) y cerrarla sigue siendo libre, sin código.

**Crear el código (solo el administrador).** En **Órdenes de producción**, botón **«Código de autorización»** (o el aviso azul «Crear el código ahora»). Pide tu contraseña de administrador y el código nuevo (mínimo 4 caracteres, repetido para evitar errores). El código **no se puede ver después**: se guarda cifrado. Si lo olvidas o quieres cambiarlo, créalo de nuevo con el mismo botón; el anterior deja de servir. Compártelo solo con quien deba corregir órdenes.

**Qué se puede hacer con el código**
- **Editar** una orden abierta: cambiar su número, producto, periodo, fecha o cantidad planeada.
- **Reabrir** una orden cerrada para corregirla. Al reabrirla se descartan su costo real y sus variaciones, y lo que había descontado del inventario **vuelve a la bodega**. Conserva todos sus consumos, horas y CIF registrados: corriges lo que haga falta y la **vuelves a cerrar**; el costo real, las variaciones y el descuento de inventario se recalculan con los datos corregidos. El formulario de cierre ya trae la cantidad producida anterior.
- **Eliminar** una orden, abierta o cerrada, con todo lo que tiene. Si estaba cerrada, el inventario que descontó vuelve a la bodega. **No se puede deshacer.**
- **Actualizar órdenes existentes desde un Excel** (casilla «actualizar» al importar) también pide el código, porque equivale a editarlas. Crear órdenes nuevas desde un archivo no lo pide.

**Cómo se usa.** En la lista, cada orden tiene **Editar** (abiertas) o **Reabrir** (cerradas), y **Eliminar**; los mismos botones están dentro de la orden. Se abre un cuadro donde escribes el código y, si quieres, el **motivo** (por ejemplo, «se digitó mal la cantidad»).

**Seguridad.**
- Cada vez que se edita, reabre o elimina una orden queda en **Actividad** (menú Administración): quién lo hizo, cuándo, qué orden, **qué cambió (antes → después)** y el motivo. Los intentos con un código incorrecto también quedan registrados.
- Tras **5 intentos fallidos** seguidos, esa persona queda bloqueada un minuto.
- Se necesita además tener permiso de modificar «Producción»: conocer el código no basta si a un usuario no se le dio ese permiso.
- Hasta que el administrador cree el código, nadie puede editar, reabrir ni eliminar órdenes, y el sistema lo explica.
- El administrador también necesita escribir el código para estas acciones.

## Precio sugerido y punto de equilibrio

Debajo de la hoja de costo de cada producto hay un panel con:
- **Precio sugerido:** escribe el margen que quieres ganar sobre el precio de venta (por ejemplo 30 %) y el sistema calcula a qué precio vender para lograrlo, cubriendo el costo estándar completo.
- **Costo variable por unidad:** materiales, mano de obra y CIF variable.
- **Margen de contribución:** cuánto deja cada unidad vendida al precio actual, después de pagar sus costos variables.
- **Punto de equilibrio:** cuántas unidades hay que vender en el periodo para cubrir los costos fijos (CIF fijo presupuestado), suponiendo que se vende solo ese producto. Se redondea hacia arriba, porque no se venden fracciones.

Elige el **periodo** arriba de la hoja: la tasa del CIF usa las unidades presupuestadas de ese periodo.

## Inventario de materias primas

En **Producción → Inventario** llevas el control de lo que tienes en bodega:
- **Registrar movimiento:** una *entrada* es una compra o ingreso (con su costo unitario); una *salida* es un uso, merma o ajuste. Las salidas se valoran solas al costo promedio vigente.
- **Costo promedio ponderado:** cada compra recalcula el costo promedio del material. Puedes compararlo con el costo estándar en la misma tabla.
- **Descuento automático:** al cerrar una orden de producción, lo consumido se descuenta del inventario, siempre que ese material ya tenga movimientos registrados (si nunca le has cargado una compra, se entiende que no llevas inventario de él).
- **Alerta de reposición:** si en **Materias primas** defines una *existencia mínima*, el material se marca como «Reponer» al llegar a ese nivel.
- **Kardex:** el historial de entradas y salidas de cada material, con su saldo y costo promedio después de cada movimiento. Los movimientos creados por una orden de producción no se borran desde aquí.
- El sistema no permite sacar más de lo que hay en existencia.

## Buscar en las tablas

Todas las listas de datos generales (empresas, productos, materias primas, trabajadores…) tienen un buscador arriba. Filtra al escribir, por cualquier columna visible, y muestra cuántos registros coinciden.

## Respaldo de la información (solo administrador)

Toda la información vive en un solo archivo. Margia hace **copias automáticas** al abrirse (una por día, las últimas 14, en la carpeta `data\respaldos`) y otra **antes de cada actualización**. Pero esas copias están **en el mismo computador**: sirven para corregir errores, no si se daña o se pierde el equipo. Por eso, además, descarga respaldos con regularidad. En **Administración → Respaldo**:
- **Descargar respaldo ahora** guarda una copia completa (con la fecha en el nombre). Guárdala **fuera** del computador: una memoria USB o tu nube.
- **Restaurar desde un archivo** reemplaza toda la información actual por la del respaldo. Antes de restaurar, el sistema guarda una copia de los datos actuales (`data/costos.db.antes_de_restaurar`) por si te equivocas de archivo.

Para usar Margia desde varios computadores, actualizarlo a una versión nueva o resolver problemas de instalación, lee **DESPLIEGUE.md**.

## Dashboard

Muestra, para las órdenes ya cerradas (con los filtros de producto y periodo que elija):
- Costo estándar y real por unidad, y su diferencia porcentual.
- El costo total de producción y las unidades producidas.
- Las variaciones acumuladas, marcadas como favorables o desfavorables.
- Un gráfico de barras que compara el costo unitario estándar y el real de cada orden (las 12 más recientes), con la diferencia porcentual debajo de cada una.

## Reportes

En **Reportes** encuentra la hoja de costos, y los reportes de materiales, mano de obra, CIF, producción, variaciones y estado de costos de producción. Cada uno se puede:
- **Exportar a Excel:** descarga un archivo `.xlsx` con encabezados resaltados, columnas ajustadas y la primera fila fija. Incluye también el **reporte de inventario**.
- **Ver e imprimir / PDF:** muestra el reporte en pantalla con un botón para imprimirlo; desde el cuadro de impresión del navegador puede elegir «Guardar como PDF» en vez de una impresora física.

## Validaciones y mensajes

El sistema no deja guardar información incompleta o inválida: avisa junto al campo qué falta corregir (por ejemplo, un campo vacío, un número negativo, una fecha mal escrita o un código repetido). Antes de eliminar cualquier registro, pide confirmación. Si un registro está siendo usado por otro (por ejemplo, una unidad de medida usada en un producto), el sistema no lo deja eliminar y explica por qué.

## Usuarios y actividad (solo administrador)

- **Usuarios:** crear, editar, desactivar o eliminar cuentas, y asignar el rol de administrador o estudiante.
- **Permisos por módulo:** al crear o editar un usuario con rol «Estudiante», aparece una lista de casillas (una por cada módulo: empresas, periodos, unidades, centros de costo, productos, materias primas, mano de obra, CIF y producción). Marca solo los módulos donde ese estudiante podrá crear, editar y eliminar; todo lo que dejes sin marcar queda disponible únicamente para consultar. Los cambios aplican de inmediato, sin que el estudiante tenga que volver a iniciar sesión.
- La gestión de usuarios y el registro de actividad son siempre exclusivos del administrador: no se pueden delegar a un estudiante, para que nadie pueda ampliarse permisos a sí mismo.
- **Actividad:** historial de qué se creó, editó o eliminó, quién lo hizo y cuándo.

## Cierre de sesión

Use el botón **Cerrar sesión** arriba a la derecha al terminar de usar el sistema, especialmente en equipos compartidos.

## Importar y exportar en Excel

Estas pantallas tienen los botones **Exportar a Excel** e **Importar desde Excel**: Empresas, Periodos contables, Unidades de medida, Centros de costo, Productos, Materias primas, Mano de obra directa, Bases de aplicación de CIF, Conceptos de CIF, **Hoja de costo** (las recetas) y **Órdenes de producción**.

- **Exportar** descarga todos los registros de esa pantalla en un Excel con **el mismo formato que la importación**. Así puedes exportar, corregir o completar en Excel (por ejemplo, subir los costos de todas las materias primas) y volver a importar el archivo marcando **«actualizar»**. Cualquier usuario puede exportar; importar requiere permiso para modificar ese módulo.
- **Importar:** en el cuadro de importación descargas la **plantilla** (títulos correctos, un ejemplo, instrucciones y hojas de consulta con listas desplegables de los códigos válidos), eliges el archivo y el sistema revisa cada fila **antes de guardar nada**: qué se crea, qué se actualiza y qué filas tienen errores, con la explicación de cada uno. Las filas pasan por las mismas validaciones que el formulario de la pantalla.
- Donde un dato apunta a otro (la unidad de un producto, el centro de costo o la base de un CIF, el periodo de una orden…) puedes escribir su **código o su nombre**.
- **Orden recomendado** para cargar una empresa nueva desde cero: empresa → unidades de medida → periodos → centros de costo → productos → materias primas → mano de obra → bases de aplicación → conceptos de CIF → recetas → órdenes.

**Recetas (Hoja de costo):** una fila por cada materia prima de cada producto, con la cantidad estándar que lleva una unidad. El producto y la materia prima deben existir antes. Las horas de mano de obra y de máquina del producto se cargan en Productos.

**Órdenes de producción:** el archivo tiene cuatro hojas: **Órdenes** (una fila por orden), **Consumo de materiales**, **Mano de obra** y **CIF real**, que se enlazan con la orden por su número y pueden ir vacías.
- Sin «actualizar» solo se crean órdenes nuevas. Con «actualizar», una orden **abierta** que ya existe se actualiza y sus consumos, horas o CIF real se **reemplazan** por los del archivo (solo en las hojas donde el archivo trae filas de esa orden), así que importar dos veces el mismo archivo no duplica nada.
- Las órdenes **cerradas** se exportan, pero al importar aparecen como «Se omite»: sus costos reales y variaciones ya quedaron calculados y no se tocan. El cierre de una orden siempre se hace en la pantalla.

En la carpeta **plantillas** del programa hay una plantilla de cada módulo. La que descargas desde el sistema es mejor, porque sus listas desplegables traen tus propios productos, materiales, unidades y códigos.

## Histórico del costo estándar

En **Costeo directo → Histórico de costos** guardas el costo estándar de todos tus productos al cerrar cada periodo:
- Elige el periodo y pulsa **Guardar costo estándar**. El costo queda **congelado**: aunque después cambien recetas, precios de materiales o CIF, lo guardado no cambia.
- La tabla compara los periodos lado a lado. Debajo de cada valor, una flecha indica cuánto subió (rojo) o bajó (verde) frente al periodo anterior, y la última columna da la variación entre el primer y el último periodo.
- Con **Comparar** puedes ver solo los materiales, solo la mano de obra o solo el CIF, para saber qué movió el costo.
- Si guardas otra vez un periodo que ya tenía costo, el sistema te pregunta antes de reemplazarlo.

## Reportes en PDF

En **Reportes**, cada reporte tiene tres botones:
- **Excel:** archivo .xlsx con formato.
- **PDF:** documento listo para enviar o imprimir, con el **logo**, la razón social, el NIT, la dirección y el teléfono de la empresa, el título y la tabla en el **color principal** que elegiste para esa empresa, y al pie la fecha, quién lo generó y el número de página. Los reportes con muchas columnas salen en horizontal.
- **Vista previa:** para revisarlo en pantalla o imprimirlo desde el navegador.

La hoja de costos indica en su título el periodo usado para repartir el CIF (el periodo abierto más reciente). Si ese periodo no tiene unidades presupuestadas, la hoja de costo de la pantalla muestra un aviso, porque el CIF saldría aproximado.

Si el logo es un archivo SVG, no aparece en el PDF (sí en la pantalla). Para el PDF usa PNG o JPG.
