# Margia — guía de marca

> **Conoce tu costo. Cuida tu margen.**

## El nombre

**Margia** viene de *margen*: lo que de verdad le importa a quien costea es cuánto le queda de cada venta. Es corto (tres sílabas), se pronuncia igual en español e inglés y suena a producto, no a contabilidad.

> Antes de registrar el nombre o comercializar el programa, consulta la base de marcas de la **Superintendencia de Industria y Comercio (SIC)** de Colombia. Una búsqueda en internet no encontró ningún producto llamado Margia en software o costos, pero **eso no es una búsqueda de marcas registradas**. Existen nombres parecidos en el mismo rubro (por ejemplo MarginEdge y MarginMate), con los que comparte la raíz «Marg-».

## La frase

**«Conoce tu costo. Cuida tu margen.»** — dos órdenes cortas y paralelas: la primera es lo que hace el programa (te dice cuánto cuesta cada cosa); la segunda, para qué sirve (que la ganancia no se escape). En la pantalla de inicio la segunda parte va en ámbar, el mismo color del punto del logo.

Descriptor corto, para acompañar al nombre cuando haga falta explicar qué es: **Costeo estándar**.

## El logo

Una **M que sube hacia la derecha**: el trazo es como una barra de crecimiento, y el punto ámbar del remate es la moneda (o el margen) que se cuida. Va sobre un cuadrado de esquinas redondeadas con degradado verde azulado.

| Elemento | Valor |
|---|---|
| Fondo del ícono (degradado) | `#1bbfab` → `#0c665f` |
| Punto / acento | `#fbbf24` (ámbar) |
| Trazo de la M | blanco |
| Texto del nombre sobre fondo claro | `#0b2f2c` |
| Tipografía del nombre | Poppins Bold (convertida a trazos: no hace falta tenerla instalada) |
| Frase (en el logo horizontal) | Poppins Medium |

### Archivos (carpeta `marca/`)

| Archivo | Para qué sirve |
|---|---|
| `margia-icono.svg` | Ícono solo, vectorial. Para pantalla, documentos y web. |
| `margia-icono-512.png` | Ícono solo en PNG (redes sociales, presentaciones). |
| `margia-icono-blanco.svg` | Ícono sobre fondos de color o de foto (M blanca sobre cuadro translúcido). |
| `margia-logo-horizontal.svg` / `.png` | Ícono + nombre + frase, para fondos **claros**. |
| `margia-logo-horizontal-blanco.svg` / `.png` | Lo mismo, para fondos **oscuros**. |
| `margia.ico` | Ícono de Windows con 7 tamaños (16 a 256 px), dibujado desde el vector para que sea nítido incluso pequeño. |

### Uso

- Deja alrededor del logo un espacio libre equivalente a la **mitad del alto del ícono**.
- **Tamaño mínimo:** el ícono, 16 px; el logo horizontal con frase, 160 px de ancho (más pequeño, usa el logo sin frase o solo el ícono).
- No estires, no gires, no cambies los colores del ícono ni lo pongas sobre fondos que le quiten contraste. Sobre oscuro, usa las versiones blancas.
- En la aplicación, el ícono del menú no cambia con los colores de cada empresa (la marca es siempre la misma); el nombre sí toma el color del texto del menú para leerse bien sobre fondos claros u oscuros.

## Dónde está la marca en el proyecto (si algún día hay que cambiarla)

1. `backend/marca.py` — nombre, frase y descriptor (lo que usa el servidor).
2. `frontend/index.html` — título, favicon, pantalla de inicio, menú lateral (el nombre va dibujado como imagen vectorial: hay que regenerarlo si cambia el nombre).
3. `frontend/img/` — `margia-icono.svg`, `margia-icono-blanco.svg`, `favicon.ico`.
4. `installer/` — `icono.ico`, `Margia.iss` (`AppName`, `AppPublisher`, `AppComments`), `build_exe.bat` (`--name`), `LEAME.txt`, `INSTALAR.txt`.
5. `marca/` — los archivos de logo de arriba.
6. `docs/` y `README.md` — textos.

**Compatibilidad con el nombre anterior (Cifra), que se conserva a propósito:** las variables de entorno `CIFRA_*` siguen funcionando igual que `MARGIA_*`; si existe la carpeta `%LOCALAPPDATA%\Cifra` con datos, se sigue usando; y si hay una carpeta `cifra` con datos junto a la nueva instalación, el programa ofrece copiarlos al primer arranque.
