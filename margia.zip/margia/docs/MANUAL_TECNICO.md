# Manual técnico — Margia

## 1. Arquitectura

- **Frontend:** HTML, CSS y JavaScript puro (sin frameworks ni dependencias de internet).
- **Backend:** Python 3, servidor HTTP con la librería estándar (`http.server`), sin frameworks externos.
- **Base de datos:** SQLite (archivo local `data/costos.db`), incluida en Python.
- **Comunicación:** API REST en JSON bajo la ruta `/api/...`. El frontend nunca toca la base de datos directamente.
- **Empaquetado:** PyInstaller genera un único `.exe` que incluye el intérprete de Python, el backend y el frontend. No requiere instalar nada más en el equipo destino.

```
Navegador (frontend/) ⇄ HTTP/JSON ⇄ backend/server.py ⇄ backend/api.py ⇄ SQLite (data/costos.db)
```

## 2. Estructura de carpetas

```
margia/
├── config/config.ini        Parámetros del sistema (ver sección 5)
├── backend/
│   ├── server.py            Servidor HTTP: enruta /api/* y sirve el frontend
│   ├── api.py                Lógica de negocio: sesión, CRUD, hoja de costo
│   ├── entities.py           Definición declarativa de cada entidad (campos, validaciones, listas)
│   ├── validators.py         Validación de campos por tipo (texto, número, fecha, etc.)
│   ├── security.py           Hash de contraseñas (PBKDF2), sesiones, bloqueo por intentos
│   ├── settings.py           Lectura de config.ini y resolución de rutas (funciona empaquetado o no)
│   └── db/
│       ├── database.py       Conexión SQLite, creación del esquema y usuarios iniciales
│       └── schema.sql        Definición de todas las tablas
├── frontend/
│   ├── index.html
│   ├── css/estilos.css
│   └── js/
│       ├── api.js            Cliente HTTP hacia /api
│       ├── ui.js              Utilidades de interfaz (tablas, formularios, modales, mensajes)
│       ├── app.js             Arranque, login, menú y enrutamiento
│       └── modulos/
│           ├── generales.js   Pantalla CRUD genérica (se alimenta de /api/meta)
│           ├── costeo.js       Receta de producto y hoja de costo estándar
│           └── usuarios.js     Administración de usuarios y bitácora
├── docs/                     Este manual y el manual de usuario
├── installer/                Script de empaquetado (.bat) e instrucciones
├── data/costos.db            Base de datos (se crea sola al primer arranque)
└── iniciar.py                Punto de entrada: python iniciar.py
```

## 3. Cómo ejecutar el proyecto

```bash
# Requiere Python 3.10+
python iniciar.py
```

El programa crea `data/costos.db` si no existe (con las tablas y los usuarios iniciales `admin` / `estudiante`), abre un servidor en `http://127.0.0.1:8765/` y, según `config.ini`, abre el navegador automáticamente.

Para generar el `.exe`: ver `installer/INSTALAR.txt` (opción B).

## 4. Modelo de datos (tablas principales)

| Tabla | Contenido |
|---|---|
| `usuarios` | Login, contraseña (hash), rol (administrador / estudiante) |
| `bitacora` | Registro de actividades importantes (crear, editar, eliminar, login) |
| `empresas` | Datos generales y tributarios de cada empresa, y su logo (imagen en base64) |
| `periodos` | Periodos contables por empresa, con las unidades de producción presupuestadas (base del CIF) |
| `unidades_medida` | Catálogo global de unidades |
| `centros_costo` | Centros de costo por empresa |
| `productos` | Productos, con horas estándar de MOD y máquina |
| `materias_primas` | Materiales, costo estándar, eficiencia |
| `receta_producto` | Materiales y cantidad estándar que componen cada producto |
| `trabajadores` | Mano de obra directa: salario, prestaciones, cargas, tarifa estándar por hora (calculada) |
| `cif_conceptos` | Costos indirectos, tipo (fijo/variable), referencia a `bases_aplicacion`, presupuestado y real (a nivel de empresa) |
| `bases_aplicacion` | Catálogo de bases de aplicación de CIF por empresa: 3 incorporadas y protegidas, más las que el administrador cree |
| `producto_base_estandar` | Consumo estándar por unidad de producto de una base de aplicación personalizada |
| `orden_base_real` | Consumo real registrado por orden de una base de aplicación personalizada |
| `ordenes_produccion` | Órdenes: producto, cantidad planeada/producida/en proceso, horas máquina reales, estado |
| `consumo_mp`, `horas_mod`, `cif_real_orden` | Consumo real de materiales, horas de MOD y CIF real, registrados por orden |
| `cif_aplicado` | CIF aplicado a cada orden según la tasa predeterminada, calculado al cerrarla |
| `costos_estandar` | Histórico: costo estándar congelado por producto y periodo (MP, MOD, CIF, total, precio de venta, cuándo y quién lo guardó) |
| `costos_reales` | Costo real (MP, MOD, CIF, total y unitarios) de cada orden cerrada |
| `movimientos_inventario` | Entradas y salidas de materias primas (fecha, cantidad, costo unitario, orden que la generó si aplica, nota) |
| `variaciones` | Las 6 variaciones de cada orden cerrada (precio y cantidad de MP, tarifa y eficiencia de MOD, presupuesto y volumen de CIF) más el total |

El esquema completo está en `backend/db/schema.sql`.

## 4.1 Cómo se calcula el costo

**Bases de aplicación del CIF:** desde `backend/entities.py` y la tabla `bases_aplicacion`, dejaron de ser un enum fijo. Toda empresa nace con 3 bases incorporadas y protegidas (`mano_obra_directa`, `hora_maquina`, `unidades_producidas`, sembradas por `database.sembrar_bases_incorporadas()` al crear la empresa y por la migración para empresas ya existentes). El administrador puede crear bases adicionales (tabla `bases_aplicacion`, `protegida=0`) desde el módulo «Bases de aplicación de CIF» — un CRUD genérico más. `cif_conceptos.base_aplicacion_id` referencia esa tabla, y el desplegable en el formulario se llena solo (es un campo `ref` más, como `unidad_id`).

Para una base incorporada, el consumo estándar por unidad de producto sigue viniendo de columnas fijas de `productos` (`horas_mod_std`, `horas_maquina_std`) o es implícitamente 1 (unidades producidas). Para una base personalizada, ese consumo estándar se carga por producto en la tabla `producto_base_estandar` (UI: panel en «Hoja de costo»), y el consumo real por orden se carga en `orden_base_real` (UI: panel en la orden de producción, antes de cerrarla). La función `bases_totales_cif()` en `backend/api.py` centraliza esta lógica: dado un `base_row` (id + código), devuelve `(base_total_del_periodo, consumo_estándar_del_producto)` sea la base incorporada o personalizada — así `hoja_costo()` y `produccion.cerrar()` comparten exactamente el mismo cálculo.

**Costo estándar** (`GET /api/hoja-costo`, en `backend/api.py`):
- **MP:** para cada material de la receta, `cantidad estándar ÷ eficiencia × costo estándar`.
- **MOD:** `horas estándar del producto × tarifa promedio de los trabajadores de la empresa`.
- **CIF:** cada concepto se prorratea con una tasa predeterminada = `presupuestado ÷ base total esperada del periodo`. La base total esperada se calcula en `bases_totales_cif()`: para "unidades producidas" es directamente las `unidades_presupuestadas` del periodo; para "mano de obra directa" y "horas máquina" es la suma de horas estándar por unidad de todos los productos, multiplicada por esas mismas unidades presupuestadas (aproximación razonable para una empresa con pocas líneas de producto — ver limitación más abajo).

**Costo real y variaciones** (`POST /api/ordenes/<id>/cerrar`, en `backend/produccion.py`), con la cantidad realmente producida:
- **Precio de materiales:** `(precio real − costo estándar) × cantidad real`.
- **Cantidad de materiales:** `(cantidad real − cantidad estándar permitida) × costo estándar`, donde la cantidad estándar permitida es `cantidad estándar de la receta × unidades producidas`.
- **Tarifa de MOD:** `(tarifa real − tarifa estándar del trabajador) × horas reales`.
- **Eficiencia de MOD:** `(horas reales − horas estándar permitidas) × tarifa estándar promedio`.
- **CIF:** se compara el CIF real registrado por orden contra un presupuesto ajustado (flexible): para CIF variable, el presupuesto ajustado es igual al aplicado (tasa × base real), así que toda la diferencia es variación de presupuesto; para CIF fijo, el presupuesto ajustado usa la base estándar de la orden (no cambia con el volumen real), lo que separa la variación de presupuesto (real vs. presupuesto ajustado) de la de volumen (presupuesto ajustado vs. aplicado).
- Cada variación se clasifica como favorable (el real costó menos) o desfavorable (costó más).

**Limitación conocida:** al no pedir un presupuesto de horas por producto, el sistema asume que cada producto alcanzaría el mismo volumen presupuestado del periodo para calcular la base total de MOD y horas máquina. Para una empresa con una sola línea de producto (o líneas de volumen similar) esto es exacto; con líneas muy distintas en volumen, la tasa de CIF es una aproximación. Se puede refinar añadiendo un presupuesto de unidades por producto si se necesita mayor precisión.

## 5. Archivo de configuración (`config/config.ini`)

| Sección | Clave | Uso |
|---|---|---|
| `servidor` | `host`, `puerto`, `abrir_navegador` | Dirección y puerto del servidor local |
| `base_datos` | `ruta` | Ubicación del archivo SQLite |
| `aplicacion` | `nombre`, `moneda_por_defecto`, `sesion_minutos`, `intentos_login_max`, `bloqueo_segundos` | Parámetros generales y de seguridad |

## 6. Seguridad implementada

- Contraseñas con **PBKDF2-HMAC-SHA256** (200 000 iteraciones) y sal aleatoria por usuario; nunca se guarda la contraseña en texto plano.
- Sesiones con **token aleatorio** (no cookies persistentes), expiración deslizante configurable, e invalidación de todas las sesiones de un usuario al cambiarle la contraseña o desactivarlo.
- **Roles:** administrador (control total) y estudiante; el backend valida cada operación de escritura, no solo el frontend.
- **Permisos por módulo (solo para estudiantes):** cada usuario con rol «estudiante» tiene un campo `usuarios.permisos` (JSON, ej. `{"productos": true, "ordenes": true}`) que el administrador edita desde «Usuarios». `backend/api.py::_puede()` decide, en cada escritura, si el usuario tiene permiso para ese módulo — el administrador siempre lo tiene todo; el estudiante solo lo que se le haya marcado. La lista de módulos configurables sale de `MODULOS_PERMISOS` en `backend/api.py` (todas las entidades genéricas más «ordenes»); «usuarios» y «bitacora» quedan fuera de esa lista a propósito, siempre exclusivos del administrador, para que un estudiante nunca pueda ampliarse permisos a sí mismo. El permiso se relee de la base de datos en cada solicitud (no se guarda en el token de sesión), así que un cambio de permisos aplica de inmediato sin pedir un nuevo login.
- **Bloqueo temporal** tras varios intentos fallidos de inicio de sesión.
- **Bitácora** de creación, edición, eliminación, inicio y cierre de sesión, con usuario y fecha.
- **Logo de empresa:** se sube como imagen (PNG, JPG, WEBP o SVG, máx. 250 KB) y se guarda en base64 en la propia base de datos (columna `empresas.logo`); no se escriben archivos sueltos en disco. El backend valida tipo y tamaño antes de guardarlo (`backend/api.py::subir_logo`).
- **Colores personalizados por empresa:** `empresas.tema` guarda un JSON con hasta 3 colores (`acento`, `lateral`, `fondo`), validados como color hexadecimal de 6 dígitos en `backend/api.py::guardar_tema`. El frontend (`frontend/js/app.js::aplicarTema`) los aplica sobre las variables CSS del `:root` en tiempo real (`document.documentElement.style.setProperty`) cada vez que se dibuja la marca del menú lateral, y deriva automáticamente los tonos oscuro/claro del color principal con una simple mezcla RGB (`UI.oscurecer`/`UI.aclarar` en `ui.js`), para no pedirle al usuario que ajuste cada matiz por separado.

## 7. Módulos y endpoints de la API

| Módulo | Endpoints principales |
|---|---|
| Sesión | `POST /api/login`, `POST /api/logout`, `POST /api/cambiar-clave` |
| Metadatos | `GET /api/meta` (entidades disponibles y datos del usuario) |
| Entidades genéricas | `GET/POST/PUT/DELETE /api/<entidad>[/<id>]` para empresas, periodos, unidades, centros de costo, productos, materias primas, trabajadores y conceptos de CIF |
| Logo y colores de empresa | `POST/DELETE /api/empresas/<id>/logo`, `POST /api/empresas/<id>/tema` |
| Receta y costo estándar | `GET/POST/DELETE /api/receta/<producto_id>`, `GET/POST/DELETE /api/producto-base/<producto_id>` (bases personalizadas), `GET /api/hoja-costo` |
| Código de autorización de órdenes | `GET /api/ordenes/codigo` (¿configurado?, ¿puede configurarlo?), `POST /api/ordenes/codigo` (solo administrador, confirma con su contraseña) |
| Producción | `GET/POST /api/ordenes`, `GET/DELETE /api/ordenes/<id>`, `POST/DELETE /api/ordenes/<id>/consumo[/<id>]`, `.../mod[/<id>]`, `.../cif[/<id>]`, `.../base[/<id>]` (bases personalizadas), `POST /api/ordenes/<id>/cerrar`, **con código:** `PUT /api/ordenes/<id>` (editar, solo abiertas), `POST .../reabrir`, `POST .../eliminar` (`DELETE /api/ordenes/<id>` ya no existe: responde 400) |
| Importar y exportar en Excel | `GET /api/plantilla/<módulo>`, `GET /api/exportar/<módulo>`, `POST /api/importar/<módulo>/revisar` (vista previa, no guarda), `POST /api/importar/<módulo>/confirmar`. Módulos: empresas, periodos, unidades_medida, centros_costo, productos, materias_primas, trabajadores, bases_aplicacion, cif_conceptos, recetas, ordenes |
| Histórico de costos | `GET /api/historico-costos`, `POST /api/historico-costos` (`periodo_id`), `DELETE /api/historico-costos/<periodo_id>` |
| Inventario | `GET /api/inventario/existencias`, `GET /api/inventario/kardex/<mp_id>`, `POST /api/inventario/movimientos`, `DELETE /api/inventario/movimientos/<id>` |
| Respaldo | `GET /api/respaldo` (descarga el .db), `POST /api/restaurar` (cuerpo binario del .db; solo administrador) |
| Guía para empezar | `GET /api/primeros-pasos` (estado real de los 9 pasos, calculado desde los datos de la empresa) |
| Dashboard y reportes | `GET /api/dashboard`, `GET /api/reportes/<tipo>` (descarga .xlsx con openpyxl, o .csv si no está instalado) `GET /api/reportes/<tipo>/pdf` (PDF con reportlab) y `GET /api/reportes/<tipo>/vista` (texto para la vista imprimible). Tipos: hoja_costos, materiales, mod, cif, produccion, variaciones, estado_costos_produccion, inventario, historico_costos |
| Usuarios y bitácora | `GET/POST/PUT/DELETE /api/usuarios[/<id>]`, `GET /api/bitacora` (incluye leer/editar `permisos` por usuario) |

## 8. Interfaz: estructura del frontend

- `js/app.js`: login, menú lateral (agrupado por sección), selector de empresa y enrutamiento.
- `js/modulos/generales.js`: pantalla CRUD genérica para toda entidad declarada en `backend/entities.py`, más el cargador de logo (solo para «Empresas»).
- `js/modulos/costeo.js`: receta de producto y hoja de costo estándar.
- `js/modulos/produccion.js`: órdenes de producción, registro de consumos/MOD/CIF real y cierre con cálculo de variaciones.
- `js/modulos/dashboard.js`: KPIs y gráfico de costo estándar vs. real (SVG dibujado a mano, sin librerías externas).
- `js/modulos/reportes.js`: descarga de reportes en CSV (se abren en Excel) y vista imprimible (el botón usa `window.print()`, con lo que el navegador permite guardar como PDF).
- `js/modulos/usuarios.js`: administración de usuarios y bitácora.
- `css/estilos.css`: hoja de estilos única con variables CSS (`:root`), para ajustar la paleta o el radio de bordes en un solo lugar.

## 9. Extender el sistema

- **Agregar una entidad nueva de datos generales:** añadir su definición en `backend/entities.py` (campos, tipos y validaciones) y su tabla en `schema.sql`; la pantalla CRUD aparece automáticamente en el menú y usa el mismo código genérico (`generales.js`), sin escribir HTML nuevo.
- **Refinar la base del CIF:** si se necesita una tasa exacta por producto (no aproximada por volumen presupuestado total), agregar un campo de unidades presupuestadas por producto y ajustar `bases_totales_cif()` en `backend/api.py`.
- **Reportes en PDF nativo (sin pasar por el navegador):** agregar una librería de generación de PDF en Python y un endpoint `/api/reportes/<tipo>/pdf` que reutilice las mismas consultas de `backend/reportes.py`.

## 9.1 Inventario, precios y respaldo (detalle de implementación)

- **Costo promedio ponderado móvil** (`backend/inventario.py::_kardex`): se recorren los movimientos en orden de fecha e id; cada entrada recalcula `(existencias × promedio + cantidad × costo) ÷ nueva existencia`; las salidas descuentan al promedio vigente sin cambiarlo. Las existencias y el promedio no se guardan: se recalculan siempre desde los movimientos, así que borrar o corregir un movimiento no deja saldos inconsistentes. Borrar una entrada que dejaría el saldo en negativo se rechaza.
- **Descuento por orden** (`registrar_salida_por_orden`, llamado desde `produccion.cerrar`): solo afecta materias primas que ya tienen movimientos, para no generar saldos negativos en empresas que no llevan inventario.
- **Punto de equilibrio** (`api.hoja_costo`): `costos fijos del periodo (CIF fijo presupuestado) ÷ (precio de venta − costo variable unitario)`. El costo variable incluye MP, MOD y CIF variable aplicado. El frontend redondea hacia arriba. El precio sugerido se calcula en el navegador: `costo estándar ÷ (1 − margen)`.
- **Aviso de contraseña de fábrica**: `meta` devuelve `usuario.clave_inicial` comparando el hash guardado contra las claves iniciales conocidas; nunca se envía ni se guarda la contraseña en claro.
- **Respaldo/restauración** (`server.py`): el respaldo envía el archivo `.db` tal cual. La restauración valida la firma de SQLite, abre el archivo y consulta la tabla de usuarios antes de aceptarlo, guarda `costos.db.antes_de_restaurar`, reemplaza la base de forma atómica (`os.replace`) y aplica la migración, por si el respaldo viene de una versión anterior.
- **Migraciones** (`database._migrar`): cada arranque agrega columnas y tablas nuevas a bases antiguas sin perder datos, incluida la conversión del campo de texto `base_aplicacion` al catálogo `bases_aplicacion`.

## 9.2 Importación, histórico y PDF

- **Importación y exportación** (`backend/importar.py`): la exportación usa el mismo formato que la importación (mismas columnas, referencias por código, opciones por su texto, fechas como fecha de Excel), lo que permite la ida y vuelta. Los catálogos se describen desde `entities.py`: los campos de referencia se resuelven por código, nombre, descripción o abreviatura; las opciones por valor o texto. Cada fila se valida con `api._limpiar`, la misma función del formulario. Las recetas y las órdenes tienen procesadores propios; las órdenes leen cuatro hojas enlazadas por número, nunca modifican órdenes cerradas (acción «omitir») y, con «actualizar», reemplazan el detalle de las órdenes abiertas existentes solo en las hojas que traen filas de esa orden. La vista previa no escribe en la base; la confirmación vuelve a procesar el archivo y guarda todo en una sola transacción. Límite: 5.000 filas por archivo. Crear una empresa por importación siembra sus bases de aplicación incorporadas.
- **Códigos de las bases incorporadas:** el cálculo del CIF las reconoce por su código (`mano_obra_directa`, `hora_maquina`, `unidades_producidas`) y las comparaciones no distinguen mayúsculas. El código de una base incorporada nunca cambia (ni desde la pantalla ni por importación). Antes, editar su nombre la pasaba a mayúsculas y el CIF dejaba de aplicarse sin aviso; la migración repara esos códigos al iniciar.
- **Base del CIF por defecto** (`api.periodo_base`): si una solicitud no indica periodo, se usa el periodo abierto más reciente (o el más reciente). Antes se repartía el CIF entre el número de productos, lo que inflaba el costo en los reportes. La hoja de costo devuelve `periodo` y, si ese periodo no tiene unidades presupuestadas, `advertencias_cif` (lista; incluye también los conceptos de CIF cuya base no tiene consumo cargado y por eso no se aplican).
- **Histórico** (`backend/historico.py`): guarda con `INSERT … ON CONFLICT DO UPDATE` sobre `UNIQUE(producto_id, periodo_id)`, calculando cada producto con `hoja_costo` y el periodo elegido. La variación se calcula frente al periodo anterior ordenado por fecha de inicio.
- **PDF** (`reportes.generar_pdf`): usa los mismos datos que el Excel (`_datos_reporte`), con encabezado de empresa, logo convertido a PNG con Pillow (SVG no se incrusta), color `tema.acento` de la empresa, encabezados que se repiten en cada página, filas alternadas, cifras con formato colombiano alineadas a la derecha, pie con fecha, usuario y página, y orientación horizontal si hay más de 5 columnas.

## 9.3 Empaquetado y despliegue en Windows

> La guía completa para quien instala o administra Margia es `docs/DESPLIEGUE.md`. Aquí, lo técnico.

- `installer/build_exe.bat` (5 pasos, se detiene en cualquier error) genera una **carpeta** con PyInstaller `--onedir` (arranca más rápido y los antivirus lo marcan menos que `--onefile`, que se descomprime en una carpeta temporal en cada apertura): `--console --icon installer\icono.ico --add-data frontend --add-data backend\db\schema.sql --collect-data reportlab`. La consola se deja visible a propósito: muestra dónde están los datos, y mantenerla abierta mantiene vivo el servidor. `installer/Margia.iss` (Inno Setup, **sin probar**) crea un instalador sin permisos de administrador en `%LOCALAPPDATA%\Programs\Margia` que conserva `data\` y `config\config.ini` al actualizar y desinstalar.
- **Rutas** (`backend/settings.py`): `RES_DIR` = recursos empaquetados (`sys._MEIPASS`); `APP_DIR` = carpeta del `.exe` (ahí se lee `config/`); `DATA_BASE` = dónde se guarda `data/`: la carpeta del `.exe` si se puede escribir, o `%LOCALAPPDATA%\Margia` si no.
- **Configuración tolerante** (`settings._leer_config`): lee con o sin BOM, UTF-8 o ANSI (cp1252); un archivo ilegible o con errores de sintaxis no impide abrir (se usan valores por defecto y se avisa); el puerto se valida (1024–65535). Antes, un `config.ini` guardado con BOM o con un error tumbaba el arranque sin explicación.
- **Consola** (`iniciar._consola_robusta`): salida con búfer de línea y `errors="replace"`, para que los mensajes de arranque no se pierdan si la salida no es una pantalla y para que un carácter que la consola de Windows (cp1252) no pueda mostrar —por ejemplo, un nombre de usuario con otro alfabeto en la ruta— no tumbe el programa. Los fallos inesperados al iniciar se muestran, se guardan en `data/margia_errores.log` y esperan Enter (sin fallar si no hay teclado).
- **Doble arranque** (`server._ya_esta_abierto`): si el puerto lo ocupa este mismo sistema (encabezado `Server: Margia/1.0`) se abre el navegador y se sale sin error; si lo ocupa otro programa se explica cómo cambiar el puerto.
- **Modo de red** (`host != 127.0.0.1`): la consola muestra las direcciones reales (`server._ips_de_red`) y el navegador se abre en `127.0.0.1` (no en `0.0.0.0`). **Se niega a iniciar si `admin` conserva la contraseña de fábrica** (`server._claves_de_fabrica`) y avisa de `estudiante`. No hay HTTPS: ver `docs/DESPLIEGUE.md`.
- **Respaldos** (`backend/respaldos.py`): `copia_consistente` usa la API de respaldo de SQLite (copia íntegra aunque otras personas estén guardando; copiar el archivo a pelo no lo garantiza) y la usan el botón de descarga y la restauración. Al iniciar, `automatico` guarda una copia diaria (14) y, si `backend/version.py` cambió respecto de `data/.version`, una `antes_de_actualizar_*` (5), **antes** de abrir la base y migrarla. Restaurar maneja el caso de Windows en que el archivo está en uso (mensaje claro en vez de error).
- **Autoverificación** (`backend/verificar.py`, `Margia.exe --verificar`): comprueba interfaz, esquema, configuración, permiso de escritura, base de prueba, copia de respaldo, Excel, PDF y Pillow; devuelve 0 o 1. El script de construcción la ejecuta al final. `Margia.exe --version` muestra la versión (también al pie del menú y en `/api/meta`).
- **SQLite y concurrencia:** una conexión por solicitud con espera de hasta 20 s (`database.connect`); modo de diario por defecto (no WAL, para que el archivo `.db` siempre sea el respaldo completo). Probado con 12 personas escribiendo a la vez.

## 9.3.0 Corregir órdenes con código de autorización

- **Almacenamiento:** tabla `ajustes (clave, valor)`; la clave `codigo_ordenes` guarda `{"hash","salt"}` (PBKDF2, el mismo `security.hash_password` de las contraseñas). El código nunca se guarda ni se devuelve en claro. La tabla se crea con `schema.sql` y también en `database._migrar` (necesario al restaurar respaldos anteriores a esta función).
- **Verificación** (`produccion.verificar_codigo`): exige el código en `body.codigo`, reutiliza el bloqueo por intentos de `security` con la clave `codigo-ordenes:<id de usuario>` (5 intentos, 60 s), registra `codigo_incorrecto` en la bitácora y devuelve 429 mientras dura el bloqueo. Va **antes** de validar los datos, para no dar pistas a quien no tiene el código. Además de conocerlo hace falta el permiso de escritura del módulo «ordenes».
- **Editar** solo órdenes abiertas; la bitácora guarda cada cambio como `campo: antes → después` y el motivo opcional.
- **Reabrir** (`_deshacer_cierre`): borra `costos_reales`, `variaciones`, `cif_aplicado` y los `movimientos_inventario` de esa orden (el inventario se calcula desde los movimientos, por lo que las existencias se restauran solas), y deja `estado='abierta'`. Los consumos, horas, CIF real y bases registrados se conservan; `cantidad_producida`, `unidades_en_proceso` y `horas_maquina_reales` también, para precargar el formulario de cierre. Al cerrar de nuevo, `cerrar()` vuelve a escribir todo.
- **Eliminar:** `_deshacer_cierre` + borrado de `consumo_mp`, `horas_mod`, `cif_real_orden` y `orden_base_real`, y de la orden. Corrige un defecto anterior: el borrado no incluía `orden_base_real` y fallaba por integridad referencial si la orden tenía bases personalizadas.
- **Avisos de openpyxl al leer Excel:** al importar una plantilla que Excel volvió a guardar, openpyxl emite `UserWarning: Data Validation extension is not supported and will be removed` (Excel guarda las listas desplegables que apuntan a otra hoja en un formato extendido, `x14`). Solo se leen valores, así que no se pierde nada; `importar._leer_libro` silencia los `UserWarning` de openpyxl en esa lectura y trata cualquier archivo ilegible o dañado como un 400 con mensaje claro. Cubierto en `tests/prueba_import_export.py`.
- **Importación de órdenes** (`importar.confirmar`): si alguna fila resulta en «actualizar», exige el mismo código; crear órdenes nuevas y la vista previa no lo exigen.
- **Pruebas:** `tests/prueba_ordenes_codigo.py` (60, HTTP real: código, bloqueo, editar, reabrir y recalcular, eliminar con restitución de inventario, permisos, importación y respaldos antiguos) y el recorrido de `tests/prueba_acciones_ui.py`.

## 9.3.1 Fallos silenciosos y red de seguridad en la interfaz

- **`window.addEventListener('unhandledrejection' / 'error')`** (`frontend/js/app.js`): cualquier error que el código de una pantalla no haya manejado se muestra en pantalla; los de sesión vencida (401) llevan al inicio de sesión. Además `UI.mensaje(…, 'error')` nunca muestra un aviso vacío: si no recibe texto, explica que hubo un error inesperado. Antes, un fallo interno quedaba sin explicación.
- **Causa de un defecto real corregido:** las secciones de consumo, mano de obra, CIF y bases personalizadas de la orden de producción usaban `o.id` sin tener `o` definida (la variable solo existía en `verOrden`), así que «Agregar» fallaba sin avisar. Se corrigió y se agregó `tests/revisar_javascript.py` (nombres no definidos) y `tests/prueba_acciones_ui.py` (recorre con clics todas las acciones de escritura).
- **CIF sin base cargada** (`api.bases_totales_cif`): se eliminó la «protección» `max(x, 1e-9)` que, cuando ninguna línea tenía consumo de una base, producía tasas astronómicas (variaciones de billones). Ahora la tasa es 0, ese CIF no se aplica y `advertencias_bases_cif` lo informa en la hoja de costo (`advertencias_cif`) y en la orden (`advertencias`).

## 9.3.2 Marca y cambio de nombre (Cifra → Margia)

- **Identidad** en `backend/marca.py` (`NOMBRE`, `LEMA`, `DESCRIPTOR`); `GET /api/meta` devuelve `app` y `lema`. El nombre ya no se lee de `config.ini` (un archivo viejo habría seguido diciendo «Cifra»). Guía completa: `docs/MARCA.md`.
- **Identificadores técnicos:** el global de JavaScript es `window.App` (neutro, para que una futura marca no lo toque); el encabezado HTTP es `Server: Margia/1.0` (la detección de «ya está abierto» también acepta `Cifra/` por si la versión anterior sigue corriendo); registro `margia.log` y `margia_errores.log`; descarga de respaldo `respaldo_margia_<fecha>.db`.
- **Compatibilidad con el nombre anterior:** `settings._variable_de_entorno` lee `MARGIA_<SECCION>_<CLAVE>` y, si no existe, `CIFRA_<SECCION>_<CLAVE>` (igual para `MARGIA_ADMIN_PASSWORD`/`CIFRA_ADMIN_PASSWORD`); la carpeta de datos alternativa es `%LOCALAPPDATA%\\Margia`, salvo que ya exista `%LOCALAPPDATA%\\Cifra` y no la nueva (así no se pierden datos). Al primer arranque, si no hay base y existe `../cifra/data/costos.db` sana, `server._ofrecer_datos_anteriores` ofrece copiarla (con la API de respaldo de SQLite; el original no se toca).
- **Logo:** `frontend/img/*.svg` y `favicon.ico`; el nombre «Margia» se incrusta en `index.html` como trazos vectoriales con `fill="currentColor"` (se adapta al tema claro/oscuro de cada empresa y no depende de ninguna tipografía instalada). La CSP existente (`img-src 'self' data:`) alcanza para todo. Pruebas: `tests/prueba_marca.py`.

## 9.4 Pruebas automáticas

`tests/prueba_interfaz.py` (24 comprobaciones), `tests/prueba_mejoras.py` (11: importación, histórico y PDF), `tests/prueba_despliegue.py` (35: ejecuta el programa como proceso aparte en los escenarios de una instalación real; ver `docs/DESPLIEGUE.md` sección 12), `tests/revisar_javascript.py` (nombres no definidos, con autocomprobación del detector; requiere TypeScript y se omite si no está), `tests/prueba_acciones_ui.py` (48: todas las acciones de escritura con clics), `tests/prueba_cif_bases.py` (12: CIF con bases sin consumo), `tests/prueba_guia.py` (25: guía del dashboard desde un sistema vacío hasta la primera orden cerrada, navegación de cada paso y casos incompletos), `tests/prueba_excel_ui.py` (13: exportar e importar desde las 10 pantallas) y `tests/prueba_import_export.py` (49, sin navegador: ida y vuelta de los 10 módulos entre dos empresas, reimportación sin duplicados y reparación de bases) abren el sistema en Chromium con Playwright y cargan datos de ejemplo en una base temporal (no tocan `data/`). Ver `tests/README.md`.

## 10. Validaciones

Centralizadas en `backend/validators.py` y aplicadas también en el frontend (mensajes junto a cada campo): campos obligatorios, números no negativos, porcentajes ≤100, fechas válidas, códigos no duplicados por empresa, y confirmación explícita antes de eliminar cualquier registro. El borrado de un registro referenciado por otros (por ejemplo, una unidad de medida en uso) se rechaza con un mensaje claro en vez de romper la base de datos.
