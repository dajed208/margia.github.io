# Margia — Guía de despliegue

Esta guía explica cómo poner Margia a funcionar en un computador o en una red local, cómo mantenerlo y qué hacer si algo falla.

## 1. Cómo funciona (lo mínimo que hay que saber)

Margia no es una página en internet. Es un **programa que corre en tu computador** y se usa desde el navegador:

```
Navegador  ⇄  Margia.exe (servidor local, puerto 8765)  ⇄  data\costos.db (tus datos)
```

- **Mientras la ventana negra de Margia esté abierta, el sistema funciona.** Si la cierras, se detiene.
- **No necesita internet** para funcionar.
- **Toda tu información está en un solo archivo:** `data\costos.db`, junto al programa.

## 2. Tres formas de usarlo

| Forma | Para qué | Estado |
|---|---|---|
| **A. Un solo computador** | Una persona (o un computador compartido) | Es la configuración por defecto. Lo más simple y seguro. |
| **B. Varias personas en la misma red** (oficina, salón) | Un computador hace de servidor; los demás entran desde su navegador | Funciona. Ver sección 6. |
| **C. En internet** | Acceder desde fuera de la oficina | **No recomendado hoy.** Ver sección 9. |

## 3. Generar el programa (Windows)

> Margia se genera **en un computador con Windows**: el `.exe` no se puede crear desde Linux o Mac.

**Requisitos:** Windows 10 o superior · Python 3.10 o superior (https://www.python.org/downloads/, marcando **"Add python.exe to PATH"**) · conexión a internet *solo para este paso*.

1. Descomprime `margia.zip`.
2. Haz doble clic en **`installer\build_exe.bat`**. Hace 5 pasos y se detiene con un mensaje claro si alguno falla:
   comprueba Python → instala PyInstaller y las librerías de Excel/PDF → genera el programa → arma la carpeta de entrega → **se verifica a sí mismo** (`Margia.exe --verificar`).
3. Si termina en **"LISTO"**, la carpeta **`dist_final\Margia`** es lo que se entrega.

**Entregar a otro computador (sin instalador):** copia la carpeta `Margia` completa y ejecuta `Margia.exe`. No necesita Python ni internet.

**Con instalador (opcional):** instala [Inno Setup](https://jrsoftware.org/isinfo.php) y abre `installer\Margia.iss`; pulsa *Compilar*. Genera `salida\Margia-Setup-1.0.0.exe`, que instala sin permisos de administrador, crea accesos directos y **conserva los datos al actualizar y al desinstalar**.

> ⚠ El script del instalador (`Margia.iss`) y la generación del `.exe` **no se pudieron probar en el entorno donde se desarrolló** (no es Windows). Todo lo demás sí, y la verificación final del script de construcción comprueba el resultado. Ver sección 11.

### Si Windows muestra "Windows protegió su PC"
Es normal en programas que no están firmados digitalmente. Pulsa **Más información → Ejecutar de todas formas**. Algunos antivirus desconfían de los programas hechos con PyInstaller; si lo bloquean, agrega una excepción para la carpeta de Margia. (Firmar el programa con un certificado de código elimina el aviso, pero tiene costo.)

## 4. Primer uso

1. Ejecuta `Margia.exe`. Se abre una ventana negra (déjala abierta) y el navegador muestra el inicio de sesión.
2. Entra con `admin` / `admin123`. **El sistema te pedirá cambiar la contraseña**; hazlo.
3. Sigue la guía **"Tu ruta para empezar"** del Dashboard.

La ventana negra muestra la versión, dónde se guardan los datos y la dirección de acceso. Si abres Margia dos veces, la segunda simplemente vuelve a abrir el navegador.

## 5. Configuración (`config\config.ini`)

Se puede editar con el Bloc de notas; **cierra y vuelve a abrir Margia** para aplicar los cambios. Un error en el archivo nunca impide que Margia abra: se avisa en la ventana y se usan los valores por defecto.

| Parámetro | Valor por defecto | Para qué |
|---|---|---|
| `host` | `127.0.0.1` | Quién puede entrar. `127.0.0.1` = solo este computador. `0.0.0.0` = toda la red (sección 6). |
| `puerto` | `8765` | Si otro programa lo usa, cámbialo (1024–65535, por ejemplo `8766`). |
| `abrir_navegador` | `si` | Abrir el navegador automáticamente. Ponlo en `no` en un servidor sin pantalla. |
| `ruta` (base de datos) | `data/costos.db` | Dónde se guardan los datos. |
| `sesion_minutos` | `120` | Minutos de inactividad antes de pedir iniciar sesión otra vez. |
| `intentos_login_max` / `bloqueo_segundos` | `5` / `60` | Tras 5 contraseñas incorrectas, se bloquea ese usuario 60 segundos. |

## 6. Usarlo en red (varias personas)

Un computador hace de **servidor** y los demás entran con el navegador. Pensado para una oficina o un salón de clase pequeños.

**En el computador servidor:**
1. Abre Margia normalmente y **cambia la contraseña de `admin`** (obligatorio, ver abajo).
2. Cierra Margia. En `config\config.ini` pon `host = 0.0.0.0` (y `abrir_navegador = no` si quieres).
3. Vuelve a abrir Margia. La ventana mostrará las direcciones de acceso:
   ```
   En este computador:   http://127.0.0.1:8765/
   Desde otros equipos:  http://192.168.1.20:8765/
   ```
4. **Windows pedirá permiso en el firewall** la primera vez: permite el acceso en **redes privadas**.
5. En los demás computadores, abre esa dirección (`http://192.168.1.20:8765/`) en el navegador. Cada persona entra con su propio usuario (créalos en **Usuarios**, con los permisos que corresponda).

**Seguridad en este modo:**
- 🔒 **Margia se niega a abrirse a la red si `admin` todavía tiene la contraseña de fábrica**, y explica los pasos a seguir. Si `estudiante` aún la tiene, lo avisa en la ventana.
- La conexión **no está cifrada** (`http`, no `https`): las contraseñas viajan en texto claro por la red local. Úsalo **solo en una red de confianza** (oficina o salón), nunca en un WiFi público.
- El servidor debe estar **encendido y con Margia abierto** para que los demás puedan entrar. Si lo apagas, los demás pierden el acceso.
- Se probó con 12 personas guardando a la vez sin pérdida ni duplicados. Es suficiente para un equipo pequeño; no está pensado para cientos de usuarios simultáneos.

## 7. Datos y respaldos

**Dónde están:** `data\costos.db` junto al programa. (Si Margia está en una carpeta donde Windows no deja escribir, como *Archivos de programa*, usa `%LOCALAPPDATA%\Margia\data`; la ventana lo indica al iniciar.)

**Respaldos automáticos** (sin que hagas nada), en `data\respaldos\`:
- Una copia **diaria** al abrir Margia (conserva las últimas 14).
- Una copia **`antes_de_actualizar_…`** cuando detecta que instalaste una versión nueva (conserva las últimas 5), para poder volver atrás.

> Estos respaldos están **en el mismo computador**: protegen de errores y de actualizaciones fallidas, **no de que se dañe o se pierda el equipo**. Para eso, descarga respaldos con regularidad y guárdalos fuera: **Administración → Respaldo → Descargar respaldo ahora** (memoria USB, nube).

**Restaurar:** *Administración → Respaldo → Restaurar desde un archivo*, o copiar un archivo de `data\respaldos\` sobre `data\costos.db` con Margia cerrado. Antes de restaurar, Margia guarda `data\costos.db.antes_de_restaurar`.

**Pasar los datos a otro computador:** descarga un respaldo en el equipo viejo y restáuralo en el nuevo (o copia `data\costos.db`).

## 8. Actualizar a una versión nueva

1. **Descarga un respaldo** (por si acaso; Margia también hace uno automático).
2. Cierra Margia.
3. Reemplaza los archivos del programa por los de la versión nueva, **conservando la carpeta `data` y el archivo `config\config.ini`**. (Con el instalador esto es automático.)
4. Abre Margia. Detecta la versión nueva, guarda el respaldo `antes_de_actualizar_…` y **actualiza la base de datos por sí mismo** sin perder datos. La versión se ve al pie del menú y con `Margia.exe --version`.

## 9. ¿Y en internet?

**No lo recomiendo en este momento.** Margia está diseñado para uso local o en red de confianza. Publicarlo en internet requeriría, como mínimo: conexión cifrada (HTTPS con un certificado), un proxy inverso, protección contra ataques de fuerza bruta más fuerte, y mantener un servidor.

**Alternativa segura si necesitas acceso desde fuera:** deja Margia en red local (sección 6) y conéctate a esa red mediante una **VPN** (por ejemplo WireGuard o Tailscale). Así nunca expones el puerto a internet.

## 10. Solución de problemas

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| La ventana se cierra al abrir | Error al iniciar | Ejecuta desde una ventana de "Símbolo del sistema" para ver el mensaje, o abre `data\margia_errores.log` y envíalo a quien te entregó el programa. |
| "No se pudo abrir el puerto…" | Otro programa usa el 8765 | Cambia `puerto` en `config.ini` (ej. `8766`). |
| El navegador no abre solo | Sin navegador predeterminado | Escribe `http://127.0.0.1:8765/` en el navegador. |
| "AVISO: … config.ini tiene un error" | El archivo se editó mal | Corrígelo o bórralo (se usan valores por defecto). |
| "POR SEGURIDAD, MARGIA NO SE INICIÓ" | Modo red con la contraseña de fábrica | Sigue los 3 pasos que muestra la ventana. |
| Otros equipos no pueden entrar | Firewall, o `host` en `127.0.0.1` | Permite Margia en redes privadas; verifica `host = 0.0.0.0`; usa la dirección "Desde otros equipos". |
| "Tu sesión terminó" | Pasaron 120 min sin actividad, o se reinició Margia | Inicia sesión de nuevo. |
| Los datos parecen estar vacíos | Se abrió otra copia de Margia con otra carpeta `data` | Mira la línea "Datos guardados en:" de la ventana; restaura un respaldo si hace falta. |
| El antivirus lo bloquea | Falso positivo habitual en programas de PyInstaller | Agrega una excepción para la carpeta de Margia. |
| `Margia.exe --verificar` muestra `[FALLA]` | Falta un componente del programa | Vuelve a generar el programa con `build_exe.bat` y envía el resultado. |

## 11. Lista de verificación antes de entregar

- [ ] `build_exe.bat` terminó en **"LISTO"** (incluye `Margia.exe --verificar`).
- [ ] Abriste `dist_final\Margia\Margia.exe` en **otro computador sin Python** y llegaste a la pantalla de inicio de sesión.
- [ ] Creaste una empresa, un producto y una orden de prueba, y descargaste un PDF y un Excel.
- [ ] Descargaste un respaldo y lo **restauraste** (comprueba que funciona antes de necesitarlo).
- [ ] La carpeta entregada **no trae datos de prueba** (`data\` vacía) ni contraseñas cambiadas por ti.
- [ ] Quien lo recibe sabe: dejar abierta la ventana negra, cambiar la contraseña, y dónde descargar respaldos.
- [ ] Si es en red: `host = 0.0.0.0`, contraseña de `admin` cambiada, firewall permitido y probado desde otro equipo.

## 12. Qué se comprobó y qué no

**Comprobado con pruebas automáticas** (`tests\prueba_despliegue.py`, 35 comprobaciones): configuración editada con el Bloc de notas (con BOM, en ANSI, con errores, con puerto inválido, borrada); consola de Windows (cp1252) y rutas con tildes, espacios y alfabetos que esa consola no puede mostrar; entorno empaquetado simulado (recursos dentro del programa, datos fuera); carpeta sin permiso de escritura; abrir dos veces y puerto ocupado; modo de red (se niega con la contraseña de fábrica, muestra las direcciones reales y acepta conexiones por la IP de la red); respaldos automáticos, poda y actualización de versión sin perder datos; fallos al iniciar con registro; 12 personas escribiendo a la vez con respaldos descargándose al mismo tiempo, todos íntegros.

**NO se pudo comprobar aquí (requiere Windows):**
- Generar el `.exe` con PyInstaller (se simuló su estructura, pero no es lo mismo). El paso final de `build_exe.bat` lo verifica en tu equipo.
- El instalador de Inno Setup (`Margia.iss`).
- El comportamiento del antivirus y del firewall de Windows.
- Acceso desde **otro computador físico** de la red (se probó por la dirección IP de la red de la misma máquina).
- Una instalación en un Windows "limpio" sin Python: es la última comprobación de la lista de la sección 11.
