"""Identidad de la marca: nombre, frase y descriptor. Es el punto de partida para cambiar la marca (ver docs/MARCA.md)."""
NOMBRE = "Margia"
LEMA = "Conoce tu costo. Cuida tu margen."
DESCRIPTOR = "Costeo estándar"
