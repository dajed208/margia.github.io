"""Respaldos de la base de datos.

- `copia_consistente`: copia una base SQLite en uso con la API de respaldo de SQLite, que garantiza una copia
  completa y sin corrupción aunque otra persona esté guardando en ese instante (copiar el archivo a pelo no lo garantiza).
- `automatico`: al iniciar el programa guarda una copia diaria en data/respaldos (conserva las últimas 14) y, si la
  versión del programa cambió desde la última vez, una copia «antes_de_actualizar» (conserva las últimas 5), para poder
  volver atrás si una actualización sale mal.
"""
import datetime
import glob
import os
import pathlib
import shutil
import sqlite3

from . import settings
from .db import database
from .version import __version__

DIARIOS_A_CONSERVAR = 14
ACTUALIZACIONES_A_CONSERVAR = 5


def copia_consistente(origen, destino):
    a = sqlite3.connect(origen, timeout=20)
    b = sqlite3.connect(destino)
    try:
        a.backup(b)
    finally:
        b.close()
        a.close()


def base_anterior_cercana():
    """Busca los datos de la versión anterior del programa (carpeta «cifra» junto a esta). Devuelve su ruta o None."""
    padre = os.path.dirname(os.path.abspath(settings.APP_DIR))
    actual = os.path.abspath(database.db_path())
    for nombre in ("cifra", "Cifra"):
        candidata = os.path.abspath(os.path.join(padre, nombre, "data", "costos.db"))
        if candidata != actual and os.path.isfile(candidata) and os.path.getsize(candidata) > 0:
            return candidata
    return None


def carpeta():
    return os.path.join(os.path.dirname(database.db_path()), "respaldos")


def verificar(ruta):
    """Comprueba que un archivo sea una base de Margia sana y que esta versión pueda abrirla.

    Devuelve (ok, mensaje). Abre el archivo en solo lectura: nunca lo modifica.
    """
    try:
        con = sqlite3.connect(pathlib.Path(ruta).resolve().as_uri() + "?mode=ro", uri=True, timeout=10)
    except sqlite3.Error as e:
        return False, f"No se pudo abrir el archivo ({e})."
    try:
        resultado = con.execute("PRAGMA integrity_check").fetchone()[0]
        if resultado != "ok":
            return False, "El archivo está dañado (falló la revisión de integridad de SQLite)."
        con.execute("SELECT COUNT(*) FROM usuarios")
        version = con.execute("PRAGMA user_version").fetchone()[0]
        if version > database.SCHEMA_VERSION:
            return False, ("Fue creado por una versión más nueva de Margia y esta no puede abrirlo sin riesgo de dañarlo. "
                           "Actualice el programa a la versión más reciente.")
        return True, "ok"
    except sqlite3.Error:
        return False, "El archivo no es una base de datos de Margia."
    finally:
        con.close()


def listar():
    """Respaldos automáticos disponibles, del más reciente al más antiguo."""
    salida = []
    for patron, tipo in (("costos_*.db", "diario"), ("antes_de_actualizar_*.db", "antes_de_actualizar")):
        for ruta in glob.glob(os.path.join(carpeta(), patron)):
            try:
                st = os.stat(ruta)
            except OSError:
                continue
            salida.append({"nombre": os.path.basename(ruta), "tipo": tipo, "tamano": st.st_size, "_mtime": st.st_mtime,
                           "fecha": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")})
    salida.sort(key=lambda r: r["_mtime"], reverse=True)
    return salida


def mejor_respaldo():
    """El respaldo más reciente que está sano, o None."""
    for r in listar():
        if verificar(os.path.join(carpeta(), r["nombre"]))[0]:
            return r
    return None


def reemplazar_base(origen, destino):
    """Pone `origen` como la base `destino`, dejando la anterior a un lado (no se borra) y limpiando archivos
    auxiliares de SQLite que pertenecían a la base anterior (si quedaran, podrían dañar la nueva)."""
    if os.path.isfile(destino):
        marca = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.move(destino, f"{destino}.reemplazada_{marca}")
    for sufijo in ("-journal", "-wal", "-shm"):
        try:
            os.remove(destino + sufijo)
        except OSError:
            pass
    shutil.copyfile(origen, destino)


def _podar(patron, conservar):
    archivos = sorted(glob.glob(os.path.join(carpeta(), patron)), reverse=True)
    for viejo in archivos[conservar:]:
        try:
            os.remove(viejo)
        except OSError:
            pass


def automatico():
    """Devuelve la lista de copias creadas (puede estar vacía). Nunca debe impedir que el programa abra."""
    ruta = database.db_path()
    marca = os.path.join(os.path.dirname(ruta), ".version")
    creadas = []
    try:
        if os.path.isfile(ruta) and os.path.getsize(ruta) > 0:
            sana, motivo = verificar(ruta)
            if not sana:  # no se guardan copias de una base dañada: taparían a las buenas
                print(f"AVISO: no se hizo el respaldo automático porque la base de datos no está sana. {motivo}")
                return creadas
            os.makedirs(carpeta(), exist_ok=True)
            hoy = datetime.date.today().isoformat()
            anterior = open(marca, encoding="utf-8").read().strip() if os.path.isfile(marca) else None
            if anterior and anterior != __version__:
                destino = os.path.join(carpeta(), f"antes_de_actualizar_{anterior}_a_{__version__}_{hoy}.db")
                if not os.path.isfile(destino):
                    copia_consistente(ruta, destino)
                    creadas.append(destino)
            diario = os.path.join(carpeta(), f"costos_{hoy}.db")
            if not os.path.isfile(diario):
                copia_consistente(ruta, diario)
                creadas.append(diario)
            _podar("costos_*.db", DIARIOS_A_CONSERVAR)
            _podar("antes_de_actualizar_*.db", ACTUALIZACIONES_A_CONSERVAR)
        os.makedirs(os.path.dirname(marca), exist_ok=True)
        with open(marca, "w", encoding="utf-8") as f:
            f.write(__version__)
    except Exception as e:  # noqa: BLE001 — un respaldo fallido avisa, pero no bloquea el trabajo
        print(f"AVISO: no se pudo hacer el respaldo automático ({e}).")
    return creadas
