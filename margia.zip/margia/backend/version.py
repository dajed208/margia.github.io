"""Versión de Margia. Súbala al publicar una actualización: al detectar un cambio, el programa hace un respaldo previo."""
__version__ = "1.0.0"
