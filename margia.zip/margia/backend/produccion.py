"""Órdenes de producción: registro de consumos, cierre con costo real y variaciones."""
import json
import sqlite3

from . import security

from .api import ApiError, auditar, _fila, _empresa_id, _requiere_permiso as _requiere_permiso_api
from .validators import validar_campo


def _orden(con, oid, eid):
    o = con.execute("SELECT * FROM ordenes_produccion WHERE id=? AND empresa_id=?", (oid, eid)).fetchone()
    if not o:
        raise ApiError(404, "La orden de producción no existe en esta empresa.")
    return o


def _requiere_admin(ctx, con):
    _requiere_permiso_api(ctx, con, "ordenes")


def _requiere_abierta(o):
    if o["estado"] == "terminada":
        raise ApiError(400, "Esta orden ya está terminada y no se puede modificar. Puede consultarla en el reporte de producción.")


CAMPOS_ORDEN = [
    {"name": "numero", "label": "Número de orden", "tipo": "text", "req": True, "max": 20},
    {"name": "producto_id", "label": "Producto", "tipo": "ref", "req": True},
    {"name": "periodo_id", "label": "Periodo contable", "tipo": "ref", "req": True},
    {"name": "fecha", "label": "Fecha", "tipo": "date", "req": True},
    {"name": "cantidad_planeada", "label": "Cantidad planeada", "tipo": "number", "req": True, "positivo": True},
]


def listar(ctx, con):
    eid = _empresa_id(ctx, con)
    sql = ("SELECT o.*, p.codigo AS producto_codigo, p.descripcion AS producto_descripcion "
           "FROM ordenes_produccion o JOIN productos p ON p.id = o.producto_id WHERE o.empresa_id=?")
    params = [eid]
    if ctx.query.get("periodo_id"):
        sql += " AND o.periodo_id=?"
        params.append(ctx.query["periodo_id"])
    if ctx.query.get("producto_id"):
        sql += " AND o.producto_id=?"
        params.append(ctx.query["producto_id"])
    sql += " ORDER BY o.fecha DESC, o.id DESC"
    return [_fila(r) for r in con.execute(sql, params)]


def _datos_orden(ctx, con, eid, id_actual=None):
    """Valida los datos de una orden (los mismos al crearla y al editarla). Devuelve los valores limpios."""
    datos, errores = {}, {}
    for c in CAMPOS_ORDEN:
        v, err = validar_campo(c, ctx.body.get(c["name"]), ctx.lang)
        if err:
            errores[c["name"]] = err
        else:
            datos[c["name"]] = v
    if errores:
        raise ApiError(400, "Revisa los campos marcados.", errores)
    if not con.execute("SELECT 1 FROM productos WHERE id=? AND empresa_id=?", (datos["producto_id"], eid)).fetchone():
        raise ApiError(400, "Selecciona un producto válido.", {"producto_id": "El producto no existe en esta empresa."})
    if not con.execute("SELECT 1 FROM periodos WHERE id=? AND empresa_id=?", (datos["periodo_id"], eid)).fetchone():
        raise ApiError(400, "Selecciona un periodo válido.", {"periodo_id": "El periodo no existe en esta empresa."})
    repetida = con.execute("SELECT id FROM ordenes_produccion WHERE empresa_id=? AND numero=?", (eid, datos["numero"])).fetchone()
    if repetida and repetida["id"] != id_actual:
        raise ApiError(400, "Ya existe una orden con ese número.", {"numero": "Ya existe una orden con este número."})
    return datos


def crear(ctx, con):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    datos = _datos_orden(ctx, con, eid)
    cur = con.execute(
        "INSERT INTO ordenes_produccion (empresa_id, periodo_id, numero, producto_id, fecha, cantidad_planeada) "
        "VALUES (?,?,?,?,?,?)",
        (eid, datos["periodo_id"], datos["numero"], datos["producto_id"], datos["fecha"], datos["cantidad_planeada"]))
    auditar(con, ctx.user["username"], "crear", "ordenes_produccion", f"Orden {datos['numero']}")
    con.commit()
    return {"id": cur.lastrowid}


# ---- Corregir órdenes: editar, reabrir y eliminar, solo con el código de autorización del administrador -------------
CLAVE_CODIGO = "codigo_ordenes"
CODIGO_MIN, CODIGO_MAX = 4, 40


def _ajuste(con, clave):
    fila = con.execute("SELECT valor FROM ajustes WHERE clave=?", (clave,)).fetchone()
    return fila["valor"] if fila else None


def estado_codigo(ctx, con):
    """Indica si el administrador ya creó el código (nunca se devuelve el código, ni siquiera cifrado)."""
    return {"configurado": _ajuste(con, CLAVE_CODIGO) is not None, "puede_configurar": ctx.user["rol"] == "administrador"}


def configurar_codigo(ctx, con):
    """Crea o cambia el código. Solo el administrador, y confirmando con su propia contraseña."""
    if ctx.user["rol"] != "administrador":
        raise ApiError(403, "Solo el administrador puede crear o cambiar el código de autorización.")
    u = con.execute("SELECT password_hash, salt FROM usuarios WHERE id=?", (ctx.user["id"],)).fetchone()
    if not u or not security.verify_password(str(ctx.body.get("password", "")), u["password_hash"], u["salt"]):
        raise ApiError(400, "Tu contraseña no es correcta.", {"password": "Escribe tu contraseña de administrador."})
    codigo = str(ctx.body.get("codigo", "")).strip()
    if len(codigo) < CODIGO_MIN:
        raise ApiError(400, f"El código debe tener al menos {CODIGO_MIN} caracteres.", {"codigo": f"Mínimo {CODIGO_MIN} caracteres."})
    if len(codigo) > CODIGO_MAX:
        raise ApiError(400, f"El código admite máximo {CODIGO_MAX} caracteres.", {"codigo": f"Máximo {CODIGO_MAX} caracteres."})
    h, sal = security.hash_password(codigo)
    nuevo = _ajuste(con, CLAVE_CODIGO) is None
    con.execute("INSERT INTO ajustes (clave, valor) VALUES (?, ?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                (CLAVE_CODIGO, json.dumps({"hash": h, "salt": sal})))
    auditar(con, ctx.user["username"], "cambiar_codigo_ordenes", "ordenes_produccion",
            "Creó el código de autorización de órdenes" if nuevo else "Cambió el código de autorización de órdenes")
    con.commit()
    return {"ok": True, "configurado": True}


def verificar_codigo(ctx, con, accion):
    """Exige el código de autorización (ctx.body['codigo']). Bloquea unos minutos tras varios intentos fallidos y deja
    constancia de cada intento incorrecto. `accion` es solo para el registro (ej. «eliminar la orden OP-001»)."""
    clave = f"codigo-ordenes:{ctx.user['id']}"
    espera = security.login_bloqueado(clave)
    if espera:
        raise ApiError(429, f"Demasiados intentos con un código incorrecto. Espera {espera} segundos para volver a intentarlo.",
                       {"codigo": "Bloqueado temporalmente."})
    guardado = _ajuste(con, CLAVE_CODIGO)
    if guardado is None:
        raise ApiError(409, "El administrador todavía no ha creado el código de autorización. Pídele que lo cree en "
                            "«Órdenes de producción → Código de autorización».")
    escrito = str(ctx.body.get("codigo", "")).strip()
    if not escrito:
        raise ApiError(400, "Escribe el código de autorización.", {"codigo": "Escribe el código de autorización."})
    d = json.loads(guardado)
    if not security.verify_password(escrito, d["hash"], d["salt"]):
        security.registrar_fallo(clave)
        auditar(con, ctx.user["username"], "codigo_incorrecto", "ordenes_produccion", f"Código de autorización incorrecto al intentar {accion}")
        con.commit()
        raise ApiError(403, "El código de autorización no es correcto.", {"codigo": "Código incorrecto."})
    security.limpiar_fallos(clave)


def _motivo(ctx):
    texto = str(ctx.body.get("motivo", "") or "").strip()[:200]
    return f" Motivo: {texto}" if texto else ""


def editar(ctx, con, oid):
    """Cambia los datos de una orden ABIERTA (número, producto, periodo, fecha y cantidad planeada)."""
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    verificar_codigo(ctx, con, f"editar la orden {o['numero']}")
    if o["estado"] == "terminada":
        raise ApiError(400, "Esta orden está cerrada. Para corregirla, primero reábrela con «Reabrir orden».")
    datos = _datos_orden(ctx, con, eid, id_actual=oid)
    cambios = [f"{c['label']}: {o[c['name']]} → {datos[c['name']]}" for c in CAMPOS_ORDEN if str(o[c["name"]]) != str(datos[c["name"]])]
    if not cambios:
        raise ApiError(400, "No cambiaste ningún dato.")
    con.execute("UPDATE ordenes_produccion SET numero=?, producto_id=?, periodo_id=?, fecha=?, cantidad_planeada=? WHERE id=?",
                (datos["numero"], datos["producto_id"], datos["periodo_id"], datos["fecha"], datos["cantidad_planeada"], oid))
    auditar(con, ctx.user["username"], "editar_orden", "ordenes_produccion",
            f"Orden {o['numero']} editada con código de autorización. {'; '.join(cambios)}.{_motivo(ctx)}")
    con.commit()
    return {"ok": True}


def _deshacer_cierre(con, oid):
    """Quita todo lo que escribió el cierre de la orden: costos reales, variaciones, CIF aplicado y salidas de inventario."""
    for tabla in ("costos_reales", "variaciones", "cif_aplicado", "movimientos_inventario"):
        con.execute(f"DELETE FROM {tabla} WHERE orden_id=?", (oid,))


def reabrir(ctx, con, oid):
    """Vuelve a abrir una orden cerrada para corregirla. Sus costos y variaciones se descartan y las salidas de inventario
    que generó vuelven a la bodega; al cerrarla otra vez todo se recalcula."""
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    verificar_codigo(ctx, con, f"reabrir la orden {o['numero']}")
    if o["estado"] != "terminada":
        raise ApiError(400, "Esta orden ya está abierta.")
    _deshacer_cierre(con, oid)
    con.execute("UPDATE ordenes_produccion SET estado='abierta' WHERE id=?", (oid,))
    auditar(con, ctx.user["username"], "reabrir_orden", "ordenes_produccion",
            f"Orden {o['numero']} reabierta con código de autorización (se descartaron sus costos reales y variaciones, "
            f"y se devolvieron al inventario sus salidas).{_motivo(ctx)}")
    con.commit()
    return detalle(ctx, con, oid)


def eliminar(ctx, con, oid):
    """Elimina una orden (abierta o cerrada) con todo lo que le pertenece, incluidas sus salidas de inventario."""
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    verificar_codigo(ctx, con, f"eliminar la orden {o['numero']}")
    _deshacer_cierre(con, oid)
    for tabla in ("consumo_mp", "horas_mod", "cif_real_orden", "orden_base_real"):
        con.execute(f"DELETE FROM {tabla} WHERE orden_id=?", (oid,))
    con.execute("DELETE FROM ordenes_produccion WHERE id=?", (oid,))
    estado = "cerrada" if o["estado"] == "terminada" else "abierta"
    auditar(con, ctx.user["username"], "eliminar_orden", "ordenes_produccion",
            f"Orden {o['numero']} ({estado}) eliminada con código de autorización.{_motivo(ctx)}")
    con.commit()
    return {"ok": True}


def detalle(ctx, con, oid):
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    prod = con.execute("SELECT * FROM productos WHERE id=?", (o["producto_id"],)).fetchone()
    consumo = con.execute(
        "SELECT c.id, c.materia_prima_id, c.cantidad_real, c.precio_real, m.codigo, m.descripcion "
        "FROM consumo_mp c JOIN materias_primas m ON m.id=c.materia_prima_id WHERE c.orden_id=?", (oid,)).fetchall()
    mod = con.execute(
        "SELECT h.id, h.trabajador_id, h.horas_reales, h.tarifa_real, t.codigo, t.nombre "
        "FROM horas_mod h JOIN trabajadores t ON t.id=h.trabajador_id WHERE h.orden_id=?", (oid,)).fetchall()
    cif = con.execute(
        "SELECT r.id, r.concepto_id, r.monto_real, c.codigo, c.descripcion "
        "FROM cif_real_orden r JOIN cif_conceptos c ON c.id=r.concepto_id WHERE r.orden_id=?", (oid,)).fetchall()
    bases_reales = con.execute(
        "SELECT r.id, r.base_id, r.cantidad_real, b.codigo, b.nombre FROM orden_base_real r "
        "JOIN bases_aplicacion b ON b.id=r.base_id WHERE r.orden_id=?", (oid,)).fetchall()
    resultado = {
        "orden": _fila(o), "producto": {"codigo": prod["codigo"], "descripcion": prod["descripcion"]},
        "consumo_mp": [_fila(r) for r in consumo], "horas_mod": [_fila(r) for r in mod], "cif_real": [_fila(r) for r in cif],
        "bases_reales": [_fila(r) for r in bases_reales],
    }
    from .api import advertencias_bases_cif
    per = con.execute("SELECT unidades_presupuestadas FROM periodos WHERE id=?", (o["periodo_id"],)).fetchone()
    unidades = per["unidades_presupuestadas"] if per and per["unidades_presupuestadas"] else \
        (con.execute("SELECT COUNT(*) n FROM productos WHERE empresa_id=?", (eid,)).fetchone()["n"] or 1)
    resultado["advertencias"] = advertencias_bases_cif(con, eid, unidades)
    if o["estado"] == "terminada":
        cr = con.execute("SELECT * FROM costos_reales WHERE orden_id=?", (oid,)).fetchone()
        var = con.execute("SELECT * FROM variaciones WHERE orden_id=?", (oid,)).fetchall()
        cif_ap = con.execute(
            "SELECT a.*, c.codigo, c.descripcion FROM cif_aplicado a JOIN cif_conceptos c ON c.id=a.concepto_id WHERE a.orden_id=?", (oid,)).fetchall()
        resultado["costo_real"] = _fila(cr) if cr else None
        resultado["variaciones"] = [_fila(r) for r in var]
        resultado["cif_aplicado"] = [_fila(r) for r in cif_ap]
    return resultado


# ---- Consumos, horas y CIF real -----------------------------------------
def agregar_consumo(ctx, con, oid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    mp_id = ctx.body.get("materia_prima_id")
    cant, e1 = validar_campo({"label": "Cantidad real", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("cantidad_real"), ctx.lang)
    precio, e2 = validar_campo({"label": "Precio real", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("precio_real"), ctx.lang)
    if e1 or e2:
        raise ApiError(400, "Revisa los campos marcados.", {k: v for k, v in (("cantidad_real", e1), ("precio_real", e2)) if v})
    if not con.execute("SELECT 1 FROM materias_primas WHERE id=? AND empresa_id=?", (mp_id, eid)).fetchone():
        raise ApiError(400, "Selecciona una materia prima válida.", {"materia_prima_id": "No existe en esta empresa."})
    cur = con.execute("INSERT INTO consumo_mp (orden_id, materia_prima_id, cantidad_real, precio_real) VALUES (?,?,?,?)",
                      (oid, mp_id, cant, precio))
    auditar(con, ctx.user["username"], "crear", "consumo_mp", f"Orden {o['numero']}: consumo de material registrado")
    con.commit()
    return {"id": cur.lastrowid}


def quitar_consumo(ctx, con, oid, cid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    con.execute("DELETE FROM consumo_mp WHERE id=? AND orden_id=?", (cid, oid))
    auditar(con, ctx.user["username"], "eliminar", "consumo_mp", f"Orden {o['numero']}")
    con.commit()
    return {"ok": True}


def agregar_mod(ctx, con, oid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    trab_id = ctx.body.get("trabajador_id")
    horas, e1 = validar_campo({"label": "Horas reales", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("horas_reales"), ctx.lang)
    tarifa, e2 = validar_campo({"label": "Tarifa real", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("tarifa_real"), ctx.lang)
    if e1 or e2:
        raise ApiError(400, "Revisa los campos marcados.", {k: v for k, v in (("horas_reales", e1), ("tarifa_real", e2)) if v})
    if not con.execute("SELECT 1 FROM trabajadores WHERE id=? AND empresa_id=?", (trab_id, eid)).fetchone():
        raise ApiError(400, "Selecciona un trabajador válido.", {"trabajador_id": "No existe en esta empresa."})
    cur = con.execute("INSERT INTO horas_mod (orden_id, trabajador_id, horas_reales, tarifa_real) VALUES (?,?,?,?)",
                      (oid, trab_id, horas, tarifa))
    auditar(con, ctx.user["username"], "crear", "horas_mod", f"Orden {o['numero']}: horas de mano de obra registradas")
    con.commit()
    return {"id": cur.lastrowid}


def quitar_mod(ctx, con, oid, hid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    con.execute("DELETE FROM horas_mod WHERE id=? AND orden_id=?", (hid, oid))
    auditar(con, ctx.user["username"], "eliminar", "horas_mod", f"Orden {o['numero']}")
    con.commit()
    return {"ok": True}


def agregar_cif_real(ctx, con, oid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    concepto_id = ctx.body.get("concepto_id")
    monto, err = validar_campo({"label": "Monto real", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("monto_real"), ctx.lang)
    if err:
        raise ApiError(400, err, {"monto_real": err})
    if not con.execute("SELECT 1 FROM cif_conceptos WHERE id=? AND empresa_id=?", (concepto_id, eid)).fetchone():
        raise ApiError(400, "Selecciona un concepto de CIF válido.", {"concepto_id": "No existe en esta empresa."})
    if con.execute("SELECT 1 FROM cif_real_orden WHERE orden_id=? AND concepto_id=?", (oid, concepto_id)).fetchone():
        raise ApiError(400, "Ese concepto de CIF ya está registrado en esta orden.", {"concepto_id": "Ya está registrado; elimínalo primero si quieres cambiar el monto."})
    cur = con.execute("INSERT INTO cif_real_orden (orden_id, concepto_id, monto_real) VALUES (?,?,?)", (oid, concepto_id, monto))
    auditar(con, ctx.user["username"], "crear", "cif_real_orden", f"Orden {o['numero']}: CIF real registrado")
    con.commit()
    return {"id": cur.lastrowid}


def quitar_cif_real(ctx, con, oid, cid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    con.execute("DELETE FROM cif_real_orden WHERE id=? AND orden_id=?", (cid, oid))
    auditar(con, ctx.user["username"], "eliminar", "cif_real_orden", f"Orden {o['numero']}")
    con.commit()
    return {"ok": True}


def agregar_base_real(ctx, con, oid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    base_id = ctx.body.get("base_id")
    cant, err = validar_campo({"label": "Cantidad real", "tipo": "number", "req": True, "positivo": False}, ctx.body.get("cantidad_real"), ctx.lang)
    if err:
        raise ApiError(400, err, {"cantidad_real": err})
    base = con.execute("SELECT * FROM bases_aplicacion WHERE id=? AND empresa_id=?", (base_id, eid)).fetchone()
    if not base:
        raise ApiError(400, "Selecciona una base de aplicación válida.", {"base_id": "No existe en esta empresa."})
    if base["protegida"]:
        raise ApiError(400, "Esta base se registra en otra sección de la orden (materiales, mano de obra u horas máquina).")
    if con.execute("SELECT 1 FROM orden_base_real WHERE orden_id=? AND base_id=?", (oid, base_id)).fetchone():
        raise ApiError(400, "Esa base ya está registrada en esta orden.", {"base_id": "Ya está registrada; elimínala primero si quieres cambiar el valor."})
    cur = con.execute("INSERT INTO orden_base_real (orden_id, base_id, cantidad_real) VALUES (?,?,?)", (oid, base_id, cant))
    auditar(con, ctx.user["username"], "crear", "orden_base_real", f"Orden {o['numero']}: base «{base['nombre']}» registrada")
    con.commit()
    return {"id": cur.lastrowid}


def quitar_base_real(ctx, con, oid, bid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)
    con.execute("DELETE FROM orden_base_real WHERE id=? AND orden_id=?", (bid, oid))
    auditar(con, ctx.user["username"], "eliminar", "orden_base_real", f"Orden {o['numero']}")
    con.commit()
    return {"ok": True}


# ---- Cierre de orden: costo real y variaciones ---------------------------
def _clasificar(monto):
    if abs(monto) < 1e-9:
        return "neutra"
    return "desfavorable" if monto > 0 else "favorable"


def cerrar(ctx, con, oid):
    _requiere_admin(ctx, con)
    eid = _empresa_id(ctx, con)
    o = _orden(con, oid, eid)
    _requiere_abierta(o)

    cant_producida, err = validar_campo({"label": "Cantidad producida", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("cantidad_producida"), ctx.lang)
    if err:
        raise ApiError(400, err, {"cantidad_producida": err})
    en_proceso, _e = validar_campo({"label": "Unidades en proceso", "tipo": "number", "req": False, "defecto": 0}, ctx.body.get("unidades_en_proceso"), ctx.lang)
    en_proceso = en_proceso or 0
    horas_maquina_reales, _e2 = validar_campo({"label": "Horas máquina reales", "tipo": "number", "req": False, "defecto": 0}, ctx.body.get("horas_maquina_reales"), ctx.lang)
    horas_maquina_reales = horas_maquina_reales or 0

    prod = con.execute("SELECT * FROM productos WHERE id=?", (o["producto_id"],)).fetchone()

    variaciones = []  # (tipo, monto)

    # --- Materiales ---
    receta = con.execute("SELECT materia_prima_id, cantidad_estandar FROM receta_producto WHERE producto_id=?", (o["producto_id"],)).fetchall()
    std_por_mp = {r["materia_prima_id"]: r["cantidad_estandar"] for r in receta}
    consumos = con.execute("SELECT * FROM consumo_mp WHERE orden_id=?", (oid,)).fetchall()
    costo_mp_real = 0.0
    var_precio_mp = var_cant_mp = 0.0
    for c in consumos:
        mp = con.execute("SELECT * FROM materias_primas WHERE id=?", (c["materia_prima_id"],)).fetchone()
        costo_mp_real += c["cantidad_real"] * c["precio_real"]
        cant_std_permitida = std_por_mp.get(c["materia_prima_id"], 0) * cant_producida
        var_precio_mp += (c["precio_real"] - mp["costo_estandar"]) * c["cantidad_real"]
        var_cant_mp += (c["cantidad_real"] - cant_std_permitida) * mp["costo_estandar"]
    variaciones.append(("precio_materiales", round(var_precio_mp, 2)))
    variaciones.append(("cantidad_materiales", round(var_cant_mp, 2)))

    # --- Mano de obra ---
    horas = con.execute("SELECT * FROM horas_mod WHERE orden_id=?", (oid,)).fetchall()
    costo_mod_real = 0.0
    var_tarifa_mod = var_efic_mod = 0.0
    horas_reales_total = 0.0
    horas_std_permitidas_total = prod["horas_mod_std"] * cant_producida
    for h in horas:
        trab = con.execute("SELECT * FROM trabajadores WHERE id=?", (h["trabajador_id"],)).fetchone()
        costo_mod_real += h["horas_reales"] * h["tarifa_real"]
        horas_reales_total += h["horas_reales"]
        var_tarifa_mod += (h["tarifa_real"] - trab["tarifa_std_hora"]) * h["horas_reales"]
    # Eficiencia con la tarifa estándar promedio de los trabajadores de la orden (o de la empresa si no hay)
    trabs_emp = con.execute("SELECT tarifa_std_hora FROM trabajadores WHERE empresa_id=?", (eid,)).fetchall()
    tarifa_std_prom = (sum(t["tarifa_std_hora"] for t in trabs_emp) / len(trabs_emp)) if trabs_emp else 0.0
    var_efic_mod = (horas_reales_total - horas_std_permitidas_total) * tarifa_std_prom
    variaciones.append(("tarifa_mod", round(var_tarifa_mod, 2)))
    variaciones.append(("eficiencia_mod", round(var_efic_mod, 2)))

    # --- CIF ---
    from .api import bases_totales_cif
    conceptos = con.execute(
        "SELECT c.*, b.codigo AS base_codigo, b.nombre AS base_nombre FROM cif_conceptos c "
        "JOIN bases_aplicacion b ON b.id = c.base_aplicacion_id WHERE c.empresa_id=?", (eid,)).fetchall()
    periodo = con.execute("SELECT unidades_presupuestadas FROM periodos WHERE id=?", (o["periodo_id"],)).fetchone()
    n_productos = con.execute("SELECT COUNT(*) n FROM productos WHERE empresa_id=?", (eid,)).fetchone()["n"] or 1
    unidades_presupuestadas = periodo["unidades_presupuestadas"] if periodo and periodo["unidades_presupuestadas"] else n_productos
    cif_reales = {r["concepto_id"]: r["monto_real"] for r in con.execute("SELECT * FROM cif_real_orden WHERE orden_id=?", (oid,))}
    bases_reales_personalizadas = {r["base_id"]: r["cantidad_real"] for r in con.execute("SELECT * FROM orden_base_real WHERE orden_id=?", (oid,))}

    costo_cif_real = costo_cif_aplicado = 0.0
    var_presupuesto_cif = var_volumen_cif = 0.0
    filas_aplicado = []
    for c in conceptos:
        base_row = {"id": c["base_aplicacion_id"], "codigo": c["base_codigo"]}
        base_total_std, base_unidad_std = bases_totales_cif(con, eid, unidades_presupuestadas, o["producto_id"], base_row)
        base_std_orden = base_unidad_std * cant_producida
        codigo_base = str(c["base_codigo"]).lower()
        if codigo_base == "mano_obra_directa":
            base_real_orden = horas_reales_total
        elif codigo_base == "hora_maquina":
            base_real_orden = horas_maquina_reales
        elif codigo_base == "unidades_producidas":
            base_real_orden = cant_producida
        else:
            base_real_orden = bases_reales_personalizadas.get(c["base_aplicacion_id"], 0.0)
        tasa = c["presupuestado"] / base_total_std if base_total_std else 0.0
        aplicado = round(tasa * base_real_orden, 2)
        real = cif_reales.get(c["id"], 0.0)
        if c["tipo"] == "variable":
            presupuestado_ajustado = aplicado  # el presupuesto flexible de un costo variable es igual a tasa x base real
        else:
            presupuestado_ajustado = round(tasa * base_std_orden, 2)  # el fijo no varía con el volumen real
        costo_cif_real += real
        costo_cif_aplicado += aplicado
        var_presupuesto_cif += real - presupuestado_ajustado
        var_volumen_cif += presupuestado_ajustado - aplicado
        filas_aplicado.append((c["id"], base_real_orden, aplicado))

    variaciones.append(("presupuesto_cif", round(var_presupuesto_cif, 2)))
    variaciones.append(("volumen_cif", round(var_volumen_cif, 2)))

    costo_total_real = round(costo_mp_real + costo_mod_real + costo_cif_real, 2)
    var_total = round(sum(v for _, v in variaciones), 2)
    variaciones.append(("total", var_total))

    # Guardar
    con.execute("DELETE FROM cif_aplicado WHERE orden_id=?", (oid,))
    for concepto_id, base_real, aplicado in filas_aplicado:
        con.execute("INSERT INTO cif_aplicado (orden_id, concepto_id, base_real, monto) VALUES (?,?,?,?)",
                    (oid, concepto_id, base_real, aplicado))
    con.execute("DELETE FROM variaciones WHERE orden_id=?", (oid,))
    for tipo, monto in variaciones:
        con.execute("INSERT INTO variaciones (orden_id, tipo, monto, clasificacion) VALUES (?,?,?,?)",
                    (oid, tipo, monto, _clasificar(monto)))
    con.execute("DELETE FROM costos_reales WHERE orden_id=?", (oid,))
    con.execute(
        "INSERT INTO costos_reales (orden_id, costo_mp, costo_mod, costo_cif, total, "
        "costo_mp_unitario, costo_mod_unitario, costo_cif_unitario, total_unitario) VALUES (?,?,?,?,?,?,?,?,?)",
        (oid, round(costo_mp_real, 2), round(costo_mod_real, 2), round(costo_cif_real, 2), costo_total_real,
         round(costo_mp_real / cant_producida, 2), round(costo_mod_real / cant_producida, 2),
         round(costo_cif_real / cant_producida, 2), round(costo_total_real / cant_producida, 2)))
    pct = round(100 * cant_producida / o["cantidad_planeada"], 1) if o["cantidad_planeada"] else 0
    con.execute(
        "UPDATE ordenes_produccion SET cantidad_producida=?, unidades_en_proceso=?, horas_maquina_reales=?, "
        "pct_avance=?, estado='terminada' WHERE id=?",
        (cant_producida, en_proceso, horas_maquina_reales, pct, oid))
    from .inventario import registrar_salida_por_orden
    registrar_salida_por_orden(con, eid, dict(o) | {"id": oid, "cantidad_producida": cant_producida}, [dict(c) for c in consumos])
    auditar(con, ctx.user["username"], "cerrar_orden", "ordenes_produccion", f"Orden {o['numero']}: costo real {costo_total_real}")
    con.commit()
    return detalle(ctx, con, oid)
