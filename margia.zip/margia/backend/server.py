"""Servidor HTTP local: sirve el frontend y expone la API REST en /api."""
import datetime
import json
import mimetypes
import os
import shutil
import socket
import sqlite3
import sys
import tempfile
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

from . import api, marca, security, settings
from . import i18n
from . import produccion, reportes, inventario, importar, historico, respaldos, registro
from .registro import log
from .version import __version__
from .db import database

FRONTEND = settings.resource("frontend")
MAX_BODY = 6_000_000  # admite archivos de Excel de importación (en base64)
MAX_RESPALDO = 300_000_000  # 300 MB de margen para restaurar un respaldo

RUTAS_PUBLICAS = {("POST", "login"), ("GET", "salud")}

# Cabeceras que endurecen el navegador frente a ataques comunes. La política de contenido solo permite cargar
# recursos del propio servidor (Margia no usa nada externo), lo que bloquea scripts inyectados.
CABECERAS_SEGURIDAD = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy": ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; "
                                "connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"),
}


class Handler(BaseHTTPRequestHandler):
    server_version = "Margia/1.0"

    def log_message(self, fmt, *args):  # silencioso
        pass

    def end_headers(self):
        for nombre, valor in CABECERAS_SEGURIDAD.items():
            self.send_header(nombre, valor)
        super().end_headers()

    def _registrar_error(self, method, motivo):
        """Deja en el registro qué petición falló, quién la hizo y el error completo (sin contraseñas ni datos enviados)."""
        log.error("%s %s (usuario %s): %s", method, self.path.split("?")[0], getattr(self, "_usuario_log", "-"), motivo, exc_info=True)

    # --- utilidades ---
    def _json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _csv(self, nombre, texto):
        data = ("\ufeff" + texto).encode("utf-8")  # BOM para que Excel detecte UTF-8
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", f'attachment; filename="{nombre}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _archivo(self, nombre, data, mime):
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Disposition", f'attachment; filename="{nombre}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _leer_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise api.ApiError(413, "La solicitud es demasiado grande.")
        if n == 0:
            return {}
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise api.ApiError(400, "Los datos enviados no tienen un formato válido.")
        return body if isinstance(body, dict) else {}

    # --- API ---
    def _api(self, method):
        con = None
        lang = i18n.lang_de(self.headers)
        try:
            url = urlparse(self.path)
            partes = [p for p in url.path.split("/") if p][1:]  # sin "api"
            query = {k: v[0] for k, v in parse_qs(url.query).items()}
            body = self._leer_body() if method in ("POST", "PUT") else {}
            auth = self.headers.get("Authorization", "")
            token = auth[7:] if auth.startswith("Bearer ") else None
            user = security.get_session(token)
            self._usuario_log = user["username"] if user else "-"
            if not partes:
                raise api.ApiError(404, "Recurso no encontrado.")
            if (method, partes[0]) not in RUTAS_PUBLICAS and not user:
                raise api.ApiError(401, "Tu sesión terminó. Inicia sesión de nuevo.")
            ctx = api.Ctx(method, partes, query, body, token, user, lang)
            con = database.connect()
            r = partes[0]
            if r == "salud" and method == "GET":
                con.execute("SELECT 1 FROM usuarios LIMIT 1")  # comprueba que la base responda
                res = {"estado": "ok", "version": __version__}
            elif r == "respaldos" and method == "GET":
                api._requiere_admin(ctx)
                if len(partes) == 1:
                    res = [{k: v for k, v in x.items() if not k.startswith("_")} for x in respaldos.listar()]
                else:
                    permitido = {x["nombre"] for x in respaldos.listar()}  # solo archivos de la lista: nunca una ruta arbitraria
                    if partes[1] not in permitido:
                        raise api.ApiError(404, "Ese respaldo no existe.")
                    with open(os.path.join(respaldos.carpeta(), partes[1]), "rb") as f:
                        self._archivo(partes[1], f.read(), "application/octet-stream")
                    return
            elif r == "login" and method == "POST":
                res = api.login(ctx, con)
            elif r == "logout" and method == "POST":
                res = api.logout(ctx, con)
            elif r == "cambiar-clave" and method == "POST":
                res = api.cambiar_clave(ctx, con)
            elif r == "meta" and method == "GET":
                res = api.meta(ctx, con)
            elif r == "usuarios":
                res = api.usuarios(ctx, con)
            elif r == "bitacora" and method == "GET":
                res = api.bitacora(ctx, con)
            elif r == "receta":
                res = api.receta(ctx, con)
            elif r == "producto-base":
                res = api.producto_base(ctx, con)
            elif r == "hoja-costo" and method == "GET":
                res = api.hoja_costo(ctx, con)
            elif len(partes) >= 2 and partes[0] == "empresas" and partes[2:3] == ["logo"]:
                oid = int(partes[1])
                if method == "POST":
                    res = api.subir_logo(ctx, con, oid)
                elif method == "DELETE":
                    res = api.quitar_logo(ctx, con, oid)
                else:
                    raise api.ApiError(405, "Método no permitido.")
            elif len(partes) >= 2 and partes[0] == "empresas" and partes[2:3] == ["tema"] and method == "POST":
                res = api.guardar_tema(ctx, con, int(partes[1]))
            elif r == "ordenes":
                if len(partes) == 1:
                    if method == "GET":
                        res = produccion.listar(ctx, con)
                    elif method == "POST":
                        res = produccion.crear(ctx, con)
                    else:
                        raise api.ApiError(405, "Método no permitido.")
                elif len(partes) == 2 and partes[1] == "codigo":  # código de autorización para corregir órdenes
                    if method == "GET":
                        res = produccion.estado_codigo(ctx, con)
                    elif method == "POST":
                        res = produccion.configurar_codigo(ctx, con)
                    else:
                        raise api.ApiError(405, "Método no permitido.")
                else:
                    oid = int(partes[1])
                    sub = partes[2] if len(partes) > 2 else None
                    if sub is None:
                        if method == "GET":
                            res = produccion.detalle(ctx, con, oid)
                        elif method == "PUT":
                            res = produccion.editar(ctx, con, oid)
                        elif method == "DELETE":  # ya no se borra sin código: se usa POST .../eliminar
                            raise api.ApiError(400, "Para eliminar una orden se necesita el código de autorización del administrador.")
                        else:
                            raise api.ApiError(405, "Método no permitido.")
                    elif sub == "reabrir" and method == "POST":
                        res = produccion.reabrir(ctx, con, oid)
                    elif sub == "eliminar" and method == "POST":
                        res = produccion.eliminar(ctx, con, oid)
                    elif sub == "consumo":
                        if method == "POST":
                            res = produccion.agregar_consumo(ctx, con, oid)
                        elif method == "DELETE":
                            res = produccion.quitar_consumo(ctx, con, oid, int(partes[3]))
                        else:
                            raise api.ApiError(405, "Método no permitido.")
                    elif sub == "mod":
                        if method == "POST":
                            res = produccion.agregar_mod(ctx, con, oid)
                        elif method == "DELETE":
                            res = produccion.quitar_mod(ctx, con, oid, int(partes[3]))
                        else:
                            raise api.ApiError(405, "Método no permitido.")
                    elif sub == "cif":
                        if method == "POST":
                            res = produccion.agregar_cif_real(ctx, con, oid)
                        elif method == "DELETE":
                            res = produccion.quitar_cif_real(ctx, con, oid, int(partes[3]))
                        else:
                            raise api.ApiError(405, "Método no permitido.")
                    elif sub == "base":
                        if method == "POST":
                            res = produccion.agregar_base_real(ctx, con, oid)
                        elif method == "DELETE":
                            res = produccion.quitar_base_real(ctx, con, oid, int(partes[3]))
                        else:
                            raise api.ApiError(405, "Método no permitido.")
                    elif sub == "cerrar" and method == "POST":
                        res = produccion.cerrar(ctx, con, oid)
                    else:
                        raise api.ApiError(404, "Recurso no encontrado.")
            elif r == "dashboard" and method == "GET":
                res = reportes.dashboard(ctx, con)
            elif r == "primeros-pasos" and method == "GET":
                res = reportes.primeros_pasos(ctx, con)
            elif r == "inventario":
                sub = partes[1] if len(partes) > 1 else None
                if sub == "existencias" and method == "GET":
                    res = inventario.existencias(ctx, con)
                elif sub == "kardex" and method == "GET":
                    res = inventario.kardex(ctx, con, int(partes[2]))
                elif sub == "movimientos" and method == "POST":
                    res = inventario.registrar_movimiento(ctx, con)
                elif sub == "movimientos" and method == "DELETE":
                    res = inventario.eliminar_movimiento(ctx, con, int(partes[2]))
                else:
                    raise api.ApiError(404, "Recurso no encontrado.")
            elif r == "historico-costos":
                if method == "GET":
                    res = historico.consultar(ctx, con)
                elif method == "POST":
                    res = historico.guardar(ctx, con)
                elif method == "DELETE" and len(partes) > 1:
                    res = historico.eliminar_periodo(ctx, con, int(partes[1]))
                else:
                    raise api.ApiError(405, "Método no permitido.")
            elif r == "importar" and method == "POST" and len(partes) == 3 and partes[2] in ("revisar", "confirmar"):
                res = importar.revisar(ctx, con, partes[1]) if partes[2] == "revisar" else importar.confirmar(ctx, con, partes[1])
            elif r in ("plantilla", "exportar") and method == "GET" and len(partes) == 2:
                nombre, data = (importar.plantilla if r == "plantilla" else importar.exportar)(ctx, con, partes[1])
                self._archivo(nombre, data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                return
            elif r == "reportes" and method == "GET":
                if len(partes) > 2 and partes[2] == "vista":
                    nombre, texto = reportes.generar_csv(ctx, con, partes[1])
                    self._csv(nombre, texto)
                elif len(partes) > 2 and partes[2] == "pdf":
                    nombre, data = reportes.generar_pdf(ctx, con, partes[1])
                    self._archivo(nombre, data, "application/pdf")
                else:
                    nombre, data, mime = reportes.generar_reporte(ctx, con, partes[1] if len(partes) > 1 else "")
                    self._archivo(nombre, data, mime)
                return
            else:
                res = api.entidad(ctx, con)
            self._json(200, res)
        except api.ApiError as e:
            if e.status >= 500:
                self._registrar_error(method, f"error {e.status}: {e.mensaje}")
            campos_trad = {k: i18n.tr_mensaje(v, lang) for k, v in e.campos.items()}
            self._json(e.status, {"error": i18n.tr_mensaje(e.mensaje, lang), "campos": campos_trad})
        except (ValueError, IndexError):
            self._json(400, {"error": i18n.tr_mensaje("La solicitud no es válida.", lang), "campos": {}})
        except sqlite3.Error as e:
            self._registrar_error(method, f"error de base de datos: {e}")
            self._json(500, {"error": i18n.tr_mensaje("Error en la base de datos. Revisa que el archivo no esté bloqueado o dañado.", lang), "campos": {}})
        except Exception as e:
            self._registrar_error(method, f"error inesperado: {type(e).__name__}: {e}")
            self._json(500, {"error": i18n.tr_mensaje("Ocurrió un error inesperado en el sistema.", lang), "campos": {}})
        finally:
            if con:
                con.close()

    # --- archivos estáticos ---
    def _static(self):
        ruta = unquote(urlparse(self.path).path)
        if ruta in ("", "/"):
            ruta = "/index.html"
        full = os.path.realpath(os.path.join(FRONTEND, ruta.lstrip("/")))
        if not full.startswith(os.path.realpath(FRONTEND)) or not os.path.isfile(full):
            self.send_error(404)
            return
        tipo = mimetypes.guess_type(full)[0] or "application/octet-stream"
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", tipo + ("; charset=utf-8" if tipo.startswith("text/") or tipo.endswith("javascript") else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    # --- Respaldo y restauración de la base de datos (fuera del flujo JSON normal) ---
    def _usuario_admin_o_error(self):
        auth = self.headers.get("Authorization", "")
        token = auth[7:] if auth.startswith("Bearer ") else None
        user = security.get_session(token)
        if not user:
            self._json(401, {"error": "Tu sesión terminó. Inicia sesión de nuevo.", "campos": {}})
            return None
        if user["rol"] != "administrador":
            self._json(403, {"error": "Solo el administrador puede hacer o restaurar respaldos.", "campos": {}})
            return None
        return user

    def _respaldo_descargar(self):
        user = self._usuario_admin_o_error()
        if not user:
            return
        ruta = database.db_path()
        if not os.path.isfile(ruta):
            self._json(404, {"error": "No se encontró la base de datos para respaldar.", "campos": {}})
            return
        con = database.connect()
        try:
            api.auditar(con, user["username"], "respaldo", "sistema", "Se descargó un respaldo de la base de datos")
            con.commit()
        finally:
            con.close()
        tmp = tempfile.mkdtemp()
        try:
            destino = os.path.join(tmp, "respaldo.db")
            respaldos.copia_consistente(ruta, destino)  # copia completa aunque otras personas estén guardando
            with open(destino, "rb") as f:
                data = f.read()
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        nombre = f"respaldo_margia_{datetime.date.today().isoformat()}.db"
        self._archivo(nombre, data, "application/octet-stream")

    def _respaldo_restaurar(self):
        user = self._usuario_admin_o_error()
        if not user:
            return
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_RESPALDO:
            self._json(400, {"error": "El archivo de respaldo no es válido o es demasiado grande.", "campos": {}})
            return
        data = self.rfile.read(n)
        if not data.startswith(b"SQLite format 3\x00"):
            self._json(400, {"error": "El archivo no parece ser un respaldo válido de este sistema (debe ser el archivo .db original, sin modificar).", "campos": {}})
            return
        ruta = database.db_path()
        temporal = ruta + ".subiendo"
        try:
            with open(temporal, "wb") as f:
                f.write(data)
        except OSError:
            self._json(500, {"error": "No se pudo guardar el archivo para revisarlo. Revisa el espacio en disco.", "campos": {}})
            return
        sano, motivo = respaldos.verificar(temporal)  # integridad y versión, antes de tocar la base actual
        if not sano:
            try:
                os.remove(temporal)
            except OSError:
                pass
            log.warning("Restauración rechazada para %s: %s", user["username"], motivo)
            self._json(400, {"error": f"No se restauró nada: {motivo}", "campos": {}})
            return
        try:
            if os.path.isfile(ruta):
                respaldos.copia_consistente(ruta, ruta + ".antes_de_restaurar")
            for sufijo in ("-journal", "-wal", "-shm"):  # restos de la base anterior que dañarían la nueva
                try:
                    os.remove(ruta + sufijo)
                except OSError:
                    pass
            os.replace(temporal, ruta)
        except OSError:
            try:
                os.remove(temporal)
            except OSError:
                pass
            self._json(409, {"error": "No se pudo reemplazar la base de datos porque otro programa o ventana la está usando. "
                                      "Cierra las demás ventanas de Margia e inténtalo de nuevo.", "campos": {}})
            return
        con = database.connect()
        try:
            database._migrar(con)
            api.auditar(con, user["username"], "restaurar", "sistema", "Se restauró la base de datos desde un archivo de respaldo")
            con.commit()
        finally:
            con.close()
        log.warning("Base de datos restaurada desde un respaldo por %s", user["username"])
        self._json(200, {"ok": True})

    def do_GET(self):
        if self.path.split("?")[0] == "/api/respaldo":
            self._respaldo_descargar()
        elif self.path.startswith("/api/"):
            self._api("GET")
        else:
            self._static()

    def do_POST(self):
        if self.path.split("?")[0] == "/api/restaurar":
            self._respaldo_restaurar()
        else:
            self._api("POST")

    def do_PUT(self):
        self._api("PUT")

    def do_DELETE(self):
        self._api("DELETE")


def crear_servidor():
    host = settings.get("servidor", "host", "127.0.0.1").strip() or "127.0.0.1"
    puerto = settings.puerto()
    return ThreadingHTTPServer((host, puerto), Handler), host, puerto


def _ips_de_red():
    """Direcciones con las que otros computadores de la red pueden llegar a este."""
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127."))


def _claves_de_fabrica():
    """Usuarios iniciales que todavía tienen la contraseña que trae el sistema (es pública)."""
    con = database.connect()
    try:
        salida = []
        for nombre in api.CLAVES_INICIALES:
            u = con.execute("SELECT id, username FROM usuarios WHERE username=? COLLATE NOCASE AND activo=1", (nombre,)).fetchone()
            if u and api._usa_clave_inicial(con, {"id": u["id"], "username": u["username"]}):
                salida.append(u["username"])
        return salida
    finally:
        con.close()


def _pausa():
    """Deja leer el mensaje antes de cerrar la ventana (no falla si no hay teclado conectado)."""
    try:
        input("Presiona Enter para salir...")
    except (EOFError, RuntimeError):
        pass


def _ya_esta_abierto(url):
    """True si en esa dirección ya responde este mismo sistema (el usuario lo abrió dos veces)."""
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=2) as r:
            return r.headers.get("Server", "").startswith(("Margia/", "Cifra/"))  # Cifra/: versión anterior abierta
    except Exception:
        return False


def _ofrecer_datos_anteriores():
    """Instalación nueva con datos de la versión anterior (carpeta «cifra») al lado: ofrece copiarlos, sin tocar el original."""
    if os.path.isfile(database.db_path()):
        return
    origen = respaldos.base_anterior_cercana()
    if not origen:
        return
    sana, motivo = respaldos.verificar(origen)
    if not sana:
        print(f"AVISO: hay datos de la versión anterior en {origen}, pero no se pueden copiar: {motivo}\n")
        return
    print(f"SE ENCONTRARON DATOS DE LA VERSIÓN ANTERIOR (Cifra)\n  {origen}\n"
          f"Este es {marca.NOMBRE}, que cambió de nombre. Si no los copia, empezará con la base vacía.")
    try:
        respuesta = input("Escriba S y pulse Enter para copiarlos aquí (el original no se toca), o solo Enter para empezar vacío: ")
    except EOFError:
        respuesta = ""
    if respuesta.strip().lower() in ("s", "si", "sí"):
        os.makedirs(os.path.dirname(database.db_path()), exist_ok=True)
        respaldos.copia_consistente(origen, database.db_path())
        print("Listo: se copiaron sus datos.\n")


def main():
    host = settings.get("servidor", "host", "127.0.0.1").strip() or "127.0.0.1"
    puerto = settings.puerto()
    en_red = host not in ("127.0.0.1", "localhost", "::1")
    abrir = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    url = f"http://{abrir}:{puerto}/"
    try:
        srv, host, puerto = crear_servidor()
    except OSError:
        if _ya_esta_abierto(url):
            print("El sistema ya estaba abierto. Abriendo el navegador...")
            webbrowser.open(url)
            return
        print(f"No se pudo abrir el puerto {puerto}: otro programa lo está usando.\n"
              "Cambia «puerto» en config/config.ini (por ejemplo a 8766) y vuelve a abrir el sistema.")
        _pausa()
        sys.exit(1)
    _ofrecer_datos_anteriores()
    creadas = respaldos.automatico()  # antes de abrir la base: guarda el estado previo a cualquier migración
    try:
        database.init()
    except Exception as e:
        print("No se pudo abrir la base de datos en:\n  " + database.db_path() + "\n"
              f"Detalle: {e}\nRevisa que la carpeta no esté protegida y que el archivo no esté abierto en otro programa.")
        _pausa()
        sys.exit(1)
    if en_red:
        de_fabrica = _claves_de_fabrica()
        if "admin" in [u.lower() for u in de_fabrica]:
            srv.server_close()
            print("POR SEGURIDAD, MARGIA NO SE INICIÓ.\n\n"
                  f"Está configurado para abrirse a toda la red (host = {host}), pero el usuario «admin» todavía tiene\n"
                  "la contraseña de fábrica, que cualquiera conoce. Para corregirlo:\n"
                  "  1) En config/config.ini ponga  host = 127.0.0.1  y abra Margia.\n"
                  "  2) Entre como admin y cambie la contraseña (botón «Cambiar contraseña»).\n"
                  "  3) Cierre Margia, vuelva a poner  host = 0.0.0.0  y ábralo de nuevo.\n")
            _pausa()
            sys.exit(1)
    nombre = marca.NOMBRE
    print(f"{nombre} {__version__} funcionando.")
    for aviso in settings.AVISOS_CONFIG:
        print(f"AVISO: {aviso}")
    print(f"  Datos guardados en: {os.path.dirname(database.db_path())}")
    for c in creadas:
        print(f"  Respaldo automático: {os.path.basename(c)}")
    print(f"  En este computador:   http://127.0.0.1:{puerto}/")
    if en_red:
        for ip in _ips_de_red():
            print(f"  Desde otros equipos:  http://{ip}:{puerto}/")
        if de_fabrica:
            print(f"  AVISO: {', '.join(de_fabrica)} todavía tiene la contraseña de fábrica y es accesible desde la red.")
        print("  Esta conexión no está cifrada (http): úsela solo en una red de confianza.")
    print("Deja esta ventana abierta mientras uses el sistema. Cierra con Ctrl+C.")
    if settings.get("servidor", "abrir_navegador", "si").lower() in ("si", "sí", "yes", "true", "1"):
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
