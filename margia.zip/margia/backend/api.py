"""Lógica de la API: sesión, usuarios, bitácora y CRUD genérico de entidades."""
import json
import re
import sqlite3

from . import marca, security, settings
from .version import __version__
from . import i18n
from .db import database
from .entities import ENTIDADES
from .validators import validar_campo


class ApiError(Exception):
    def __init__(self, status, mensaje, campos=None):
        super().__init__(mensaje)
        self.status = status
        self.mensaje = mensaje
        self.campos = campos or {}


class Ctx:
    def __init__(self, method, partes, query, body, token, user, lang="es"):
        self.method, self.partes, self.query, self.body, self.token, self.user, self.lang = method, partes, query, body, token, user, lang


def auditar(con, usuario, accion, entidad=None, detalle=None):
    con.execute("INSERT INTO bitacora (usuario, accion, entidad, detalle) VALUES (?,?,?,?)",
                (usuario, accion, entidad, detalle))


def _requiere_admin(ctx):
    if ctx.user["rol"] != "administrador":
        raise ApiError(403, "Tu rol (estudiante) solo permite consultar. Pide al administrador que haga este cambio.")


# ---- Permisos por módulo para el rol estudiante -------------------------
# Módulos configurables uno por uno desde «Usuarios». «usuarios» y «bitacora»
# quedan siempre exclusivos del administrador (no son configurables) para
# evitar que un estudiante pueda darse a sí mismo más permisos.
MODULOS_PERMISOS = [(nombre, spec["titulo"]) for nombre, spec in ENTIDADES.items()] + [("ordenes", "Producción"), ("inventario", "Inventario")]


def _permisos_usuario(con, user_id):
    fila = con.execute("SELECT permisos FROM usuarios WHERE id=?", (user_id,)).fetchone()
    if not fila or not fila["permisos"]:
        return {}
    try:
        return json.loads(fila["permisos"])
    except (TypeError, ValueError):
        return {}


def _puede(ctx, con, modulo):
    if ctx.user["rol"] == "administrador":
        return True
    return bool(_permisos_usuario(con, ctx.user["id"]).get(modulo))


def _requiere_permiso(ctx, con, modulo, nombre_modulo=None):
    if not _puede(ctx, con, modulo):
        nombre = nombre_modulo or dict(MODULOS_PERMISOS).get(modulo, modulo)
        raise ApiError(403, f"Tu usuario no tiene permiso para modificar «{nombre}». Pide al administrador que te lo habilite en «Usuarios».")


def _fila(r):
    return {k: r[k] for k in r.keys()}


# ---- Sesión -------------------------------------------------------------
def login(ctx, con):
    username = str(ctx.body.get("username", "")).strip()
    password = str(ctx.body.get("password", ""))
    if not username or not password:
        raise ApiError(400, "Escribe tu usuario y contraseña.")
    espera = security.login_bloqueado(username)
    if espera:
        raise ApiError(429, f"Demasiados intentos fallidos. Intenta de nuevo en {espera} segundos.")
    u = con.execute("SELECT * FROM usuarios WHERE username = ? COLLATE NOCASE", (username,)).fetchone()
    if not u or not u["activo"] or not security.verify_password(password, u["password_hash"], u["salt"]):
        security.registrar_fallo(username)
        auditar(con, username, "login_fallido", "usuarios", "Intento de inicio de sesión rechazado")
        con.commit()
        raise ApiError(401, "Usuario o contraseña incorrectos.")
    security.limpiar_fallos(username)
    user = {"id": u["id"], "username": u["username"], "nombre": u["nombre"], "rol": u["rol"]}
    token = security.create_session(user)
    auditar(con, u["username"], "inicio_sesion", "usuarios")
    con.commit()
    return {"token": token, "usuario": user}


def logout(ctx, con):
    auditar(con, ctx.user["username"], "cierre_sesion", "usuarios")
    con.commit()
    security.destroy_session(ctx.token)
    return {"ok": True}


def cambiar_clave(ctx, con):
    actual, nueva = str(ctx.body.get("actual", "")), str(ctx.body.get("nueva", ""))
    u = con.execute("SELECT * FROM usuarios WHERE id = ?", (ctx.user["id"],)).fetchone()
    if not security.verify_password(actual, u["password_hash"], u["salt"]):
        raise ApiError(400, "La contraseña actual no es correcta.", {"actual": "No coincide."})
    if len(nueva) < 6:
        raise ApiError(400, "La contraseña nueva debe tener al menos 6 caracteres.", {"nueva": "Mínimo 6 caracteres."})
    h, s = security.hash_password(nueva)
    con.execute("UPDATE usuarios SET password_hash=?, salt=? WHERE id=?", (h, s, u["id"]))
    auditar(con, u["username"], "cambio_clave", "usuarios")
    con.commit()
    return {"ok": True}


def _traducir_campo(campo, lang):
    if lang != "en":
        return campo
    c = dict(campo)
    c["label"] = i18n.tr_etiqueta(campo["label"], lang)
    if campo.get("tipo") == "select" and campo.get("opciones"):
        c["opciones"] = [{"valor": o["valor"], "texto": i18n.tr_opcion(o["texto"], lang)} for o in campo["opciones"]]
    return c


CLAVES_INICIALES = {"admin": "admin123", "estudiante": "estudiante123"}


def _usa_clave_inicial(con, user):
    """True si el usuario todavía tiene la contraseña que trae el sistema de fábrica."""
    inicial = CLAVES_INICIALES.get(user["username"])
    if not inicial:
        return False
    u = con.execute("SELECT password_hash, salt FROM usuarios WHERE id=?", (user["id"],)).fetchone()
    return bool(u) and security.verify_password(inicial, u["password_hash"], u["salt"])


def meta(ctx, con):
    lang = ctx.lang
    ents = {}
    for nombre, e in ENTIDADES.items():
        ents[nombre] = {
            "titulo": i18n.tr_etiqueta(e["titulo"], lang),
            "singular": i18n.tr_etiqueta(e["singular"], lang),
            "scoped": e["scoped"], "lista": e["lista"], "femenino": e.get("femenino", False),
            "campos": [_traducir_campo(c, lang) for c in e["campos"]],
            "solo_lectura": e.get("solo_lectura", []),
        }
    usuario = dict(ctx.user)
    usuario["permisos"] = _permisos_usuario(con, ctx.user["id"]) if ctx.user["rol"] != "administrador" else None
    usuario["clave_inicial"] = _usa_clave_inicial(con, ctx.user)
    return {"app": marca.NOMBRE, "lema": marca.LEMA,
            "moneda": settings.get("aplicacion", "moneda_por_defecto", "COP"),
            "version": __version__, "entidades": ents, "usuario": usuario,
            "modulos_permisos": [{"id": m, "titulo": i18n.tr_etiqueta(t, lang)} for m, t in MODULOS_PERMISOS]}


# ---- Usuarios (solo administrador) -------------------------------------
def _limpiar_permisos(body):
    """Filtra el objeto de permisos recibido a solo los módulos configurables conocidos."""
    crudo = body.get("permisos")
    if not isinstance(crudo, dict):
        return "{}"
    modulos_validos = {m for m, _ in MODULOS_PERMISOS}
    limpio = {m: bool(crudo.get(m)) for m in modulos_validos if crudo.get(m)}
    return json.dumps(limpio)


def usuarios(ctx, con):
    _requiere_admin(ctx)
    partes = ctx.partes
    if ctx.method == "GET":
        filas = con.execute("SELECT id, username, nombre, rol, activo, permisos, creado FROM usuarios ORDER BY username").fetchall()
        salida = []
        for r in filas:
            d = _fila(r)
            try:
                d["permisos"] = json.loads(d["permisos"]) if d["permisos"] else {}
            except (TypeError, ValueError):
                d["permisos"] = {}
            salida.append(d)
        return salida
    b = ctx.body
    username = str(b.get("username", "")).strip()
    nombre = str(b.get("nombre", "")).strip()
    rol = b.get("rol")
    permisos_json = _limpiar_permisos(b)
    errores = {}
    if ctx.method == "POST" or len(partes) < 2:
        if not username:
            errores["username"] = "«Usuario» es obligatorio."
        elif len(username) < 3 or not username.replace("_", "").replace(".", "").isalnum():
            errores["username"] = "Usa al menos 3 letras o números (se permiten _ y .)."
    if not nombre:
        errores["nombre"] = "«Nombre» es obligatorio."
    if rol not in ("administrador", "estudiante"):
        errores["rol"] = "Elige un rol válido."
    clave = str(b.get("password", ""))
    if ctx.method == "POST" and len(clave) < 6:
        errores["password"] = "La contraseña debe tener al menos 6 caracteres."
    if ctx.method == "PUT" and clave and len(clave) < 6:
        errores["password"] = "La contraseña debe tener al menos 6 caracteres."
    if ctx.method in ("POST", "PUT") and errores:
        raise ApiError(400, "Revisa los campos marcados.", errores)

    if ctx.method == "POST":
        if con.execute("SELECT 1 FROM usuarios WHERE username = ? COLLATE NOCASE", (username,)).fetchone():
            raise ApiError(400, "Ese usuario ya existe.", {"username": "Ya existe un usuario con este nombre."})
        h, s = security.hash_password(clave)
        cur = con.execute("INSERT INTO usuarios (username, nombre, rol, password_hash, salt, permisos) VALUES (?,?,?,?,?,?)",
                          (username, nombre, rol, h, s, permisos_json))
        auditar(con, ctx.user["username"], "crear", "usuarios", f"Usuario {username} ({rol})")
        con.commit()
        return {"id": cur.lastrowid}

    uid = int(partes[1])
    existente = con.execute("SELECT * FROM usuarios WHERE id = ?", (uid,)).fetchone()
    if not existente:
        raise ApiError(404, "El usuario no existe.")
    if ctx.method == "PUT":
        activo = 1 if b.get("activo", True) else 0
        if uid == ctx.user["id"] and (rol != "administrador" or not activo):
            raise ApiError(400, "No puedes quitarte el rol de administrador ni desactivar tu propia cuenta.")
        con.execute("UPDATE usuarios SET nombre=?, rol=?, activo=?, permisos=? WHERE id=?", (nombre, rol, activo, permisos_json, uid))
        if clave:
            h, s = security.hash_password(clave)
            con.execute("UPDATE usuarios SET password_hash=?, salt=? WHERE id=?", (h, s, uid))
        if not activo or clave:
            security.destroy_user_sessions(uid)
        auditar(con, ctx.user["username"], "editar", "usuarios", f"Usuario {existente['username']}" + (" (contraseña restablecida)" if clave else ""))
        con.commit()
        return {"ok": True}
    if ctx.method == "DELETE":
        if uid == ctx.user["id"]:
            raise ApiError(400, "No puedes eliminar tu propia cuenta.")
        try:
            con.execute("DELETE FROM usuarios WHERE id=?", (uid,))
        except sqlite3.IntegrityError:
            raise ApiError(409, "No se puede eliminar este usuario.")
        security.destroy_user_sessions(uid)
        auditar(con, ctx.user["username"], "eliminar", "usuarios", f"Usuario {existente['username']}")
        con.commit()
        return {"ok": True}
    raise ApiError(405, "Método no permitido.")


def bitacora(ctx, con):
    _requiere_admin(ctx)
    try:
        limite = max(1, min(int(ctx.query.get("limite", 300)), 2000))
    except ValueError:
        limite = 300
    return [_fila(r) for r in con.execute("SELECT * FROM bitacora ORDER BY id DESC LIMIT ?", (limite,))]


# ---- CRUD genérico ---------------------------------------------------------
def _empresa_id(ctx, con):
    valor = ctx.query.get("empresa_id") or ctx.body.get("empresa_id")
    try:
        eid = int(valor)
    except (TypeError, ValueError):
        raise ApiError(400, "Primero selecciona una empresa (arriba a la derecha) o crea una en «Empresas».")
    if not con.execute("SELECT 1 FROM empresas WHERE id=?", (eid,)).fetchone():
        raise ApiError(404, "La empresa seleccionada ya no existe.")
    return eid


def _limpiar(spec, ent, body, con, empresa_id, lang="es", id_actual=None):
    datos, errores = {}, {}
    for c in spec["campos"]:
        if c.get("calculado"):
            continue
        v, err = validar_campo(c, body.get(c["name"]), lang)
        if err:
            errores[c["name"]] = err
            continue
        if c["tipo"] == "ref" and v is not None:
            sql, p = f"SELECT 1 FROM {c['ref']} WHERE id=?", [v]
            if c.get("scoped"):
                sql += " AND empresa_id=?"
                p.append(empresa_id)
            if not con.execute(sql, p).fetchone():
                errores[c["name"]] = f"La opción elegida en «{c['label']}» ya no existe."
                continue
        datos[c["name"]] = v
    if errores:
        raise ApiError(400, "Revisa los campos marcados.", errores)

    # Código duplicado
    if "codigo" in datos:
        sql, p = f"SELECT id FROM {ent} WHERE codigo = ?", [datos["codigo"]]
        if spec["scoped"]:
            sql += " AND empresa_id = ?"
            p.append(empresa_id)
        if id_actual:
            sql += " AND id != ?"
            p.append(id_actual)
        if con.execute(sql, p).fetchone():
            raise ApiError(400, "Ese código ya existe.", {"codigo": f"Ya existe un registro con el código «{datos['codigo']}». Usa otro."})
    if spec.get("reglas"):
        e = spec["reglas"](datos, con, id_actual)
        if e:
            raise ApiError(400, "Revisa los campos marcados.", e)
    if spec.get("calculo"):
        spec["calculo"](datos)
    return datos


def entidad(ctx, con):
    ent = ctx.partes[0]
    spec = ENTIDADES.get(ent)
    if not spec:
        raise ApiError(404, "Recurso no encontrado.")
    partes = ctx.partes
    if ctx.method == "GET":
        sql, p = f"SELECT * FROM {ent}", []
        if spec["scoped"]:
            sql += " WHERE empresa_id = ?"
            p.append(_empresa_id(ctx, con))
        sql += f" ORDER BY {spec['orden']}"
        filas = [_fila(r) for r in con.execute(sql, p)]
        if ent == "empresas":
            for f in filas:
                try:
                    f["tema"] = json.loads(f["tema"]) if f.get("tema") else None
                except (TypeError, ValueError):
                    f["tema"] = None
        return filas

    _requiere_permiso(ctx, con, ent)
    eid = _empresa_id(ctx, con) if spec["scoped"] else None

    if ctx.method == "POST":
        datos = _limpiar(spec, ent, ctx.body, con, eid, ctx.lang)
        if spec["scoped"]:
            datos["empresa_id"] = eid
        cols = ", ".join(datos)
        cur = con.execute(f"INSERT INTO {ent} ({cols}) VALUES ({', '.join('?' * len(datos))})", list(datos.values()))
        if ent == "empresas":
            from .db.database import sembrar_bases_incorporadas
            sembrar_bases_incorporadas(con, cur.lastrowid)
        auditar(con, ctx.user["username"], "crear", ent, _resumen(datos))
        con.commit()
        return {"id": cur.lastrowid}

    if len(partes) < 2:
        raise ApiError(400, "Falta el identificador del registro.")
    rid = int(partes[1])
    sql, p = f"SELECT * FROM {ent} WHERE id=?", [rid]
    if spec["scoped"]:
        sql += " AND empresa_id=?"
        p.append(eid)
    actual = con.execute(sql, p).fetchone()
    if not actual:
        raise ApiError(404, "El registro no existe o ya fue eliminado.")

    if ent == "bases_aplicacion" and actual["protegida"]:
        if ctx.method == "DELETE":
            raise ApiError(400, "Esta base de aplicación es incorporada del sistema y no se puede eliminar. Puedes crear bases adicionales para tus propios criterios de prorrateo.")
        if ctx.method == "PUT" and str(ctx.body.get("codigo", "")).strip().lower() != actual["codigo"].lower():
            raise ApiError(400, "El código de una base incorporada no se puede cambiar.", {"codigo": "Es una base incorporada del sistema; puedes cambiar su nombre, pero no su código."})

    if ctx.method == "PUT":
        datos = _limpiar(spec, ent, ctx.body, con, eid, ctx.lang, rid)
        if ent == "bases_aplicacion" and actual["protegida"]:
            datos["codigo"] = actual["codigo"]  # el cálculo del CIF identifica las bases incorporadas por su código
        sets = ", ".join(f"{k}=?" for k in datos)
        con.execute(f"UPDATE {ent} SET {sets} WHERE id=?", list(datos.values()) + [rid])
        auditar(con, ctx.user["username"], "editar", ent, _resumen(datos))
        con.commit()
        return {"ok": True}

    if ctx.method == "DELETE":
        if ent == "empresas":
            _borrar_empresa(con, rid)
        else:
            try:
                con.execute(f"DELETE FROM {ent} WHERE id=?", (rid,))
            except sqlite3.IntegrityError:
                con.rollback()
                raise ApiError(409, f"No se puede eliminar este registro de «{spec['titulo']}» porque otros datos dependen de él. Elimina o cambia primero esos datos.")
        auditar(con, ctx.user["username"], "eliminar", ent, _resumen(_fila(actual)))
        con.commit()
        return {"ok": True}
    raise ApiError(405, "Método no permitido.")


# Datos que impiden borrar una empresa (las bases de aplicación no cuentan: se borran con ella)
_DEPENDENCIAS_EMPRESA = [
    ("periodos", "periodo(s) contable(s)"), ("centros_costo", "centro(s) de costo"), ("productos", "producto(s)"),
    ("materias_primas", "materia(s) prima(s)"), ("trabajadores", "trabajador(es)"),
    ("cif_conceptos", "concepto(s) de CIF"), ("ordenes_produccion", "orden(es) de producción"),
]


def _borrar_empresa(con, empresa_id):
    pendientes = []
    for tabla, etiqueta in _DEPENDENCIAS_EMPRESA:
        n = con.execute(f"SELECT COUNT(*) n FROM {tabla} WHERE empresa_id=?", (empresa_id,)).fetchone()["n"]
        if n:
            pendientes.append(f"{n} {etiqueta}")
    if pendientes:
        raise ApiError(409, "No se puede eliminar la empresa porque todavía tiene datos: " + ", ".join(pendientes)
                       + ". Elimínalos primero (empezando por las órdenes de producción) y vuelve a intentarlo.")
    try:
        con.execute("DELETE FROM bases_aplicacion WHERE empresa_id=?", (empresa_id,))
        con.execute("DELETE FROM empresas WHERE id=?", (empresa_id,))
    except sqlite3.IntegrityError:
        con.rollback()
        raise ApiError(409, "No se puede eliminar la empresa porque otros datos dependen de ella.")


# ---- Receta de producto (materias primas por unidad) y hoja de costo ----
def receta(ctx, con):
    if len(ctx.partes) < 2:
        raise ApiError(400, "Falta indicar el producto.")
    producto_id = int(ctx.partes[1])
    eid = _empresa_id(ctx, con)
    prod = con.execute("SELECT * FROM productos WHERE id=? AND empresa_id=?", (producto_id, eid)).fetchone()
    if not prod:
        raise ApiError(404, "El producto no existe en esta empresa.")

    if ctx.method == "GET":
        filas = con.execute(
            "SELECT r.id, r.materia_prima_id, r.cantidad_estandar, m.codigo, m.descripcion, m.costo_estandar "
            "FROM receta_producto r JOIN materias_primas m ON m.id = r.materia_prima_id "
            "WHERE r.producto_id = ? ORDER BY m.codigo", (producto_id,)).fetchall()
        return [_fila(f) for f in filas]

    _requiere_permiso(ctx, con, "productos")
    if ctx.method == "POST":
        mp_id = ctx.body.get("materia_prima_id")
        cant, err = validar_campo({"label": "Cantidad estándar", "tipo": "number", "req": True, "positivo": True}, ctx.body.get("cantidad_estandar"), ctx.lang)
        if err:
            raise ApiError(400, err, {"cantidad_estandar": err})
        mp = con.execute("SELECT 1 FROM materias_primas WHERE id=? AND empresa_id=?", (mp_id, eid)).fetchone()
        if not mp:
            raise ApiError(400, "Selecciona una materia prima válida.", {"materia_prima_id": "Selecciona una materia prima."})
        if con.execute("SELECT 1 FROM receta_producto WHERE producto_id=? AND materia_prima_id=?", (producto_id, mp_id)).fetchone():
            raise ApiError(400, "Esa materia prima ya está en la receta de este producto.", {"materia_prima_id": "Ya está agregada."})
        cur = con.execute("INSERT INTO receta_producto (producto_id, materia_prima_id, cantidad_estandar) VALUES (?,?,?)",
                          (producto_id, mp_id, cant))
        auditar(con, ctx.user["username"], "crear", "receta_producto", f"Producto {prod['codigo']}: se agregó materia prima")
        con.commit()
        return {"id": cur.lastrowid}

    if ctx.method == "DELETE":
        if len(ctx.partes) < 3:
            raise ApiError(400, "Falta el identificador del renglón de la receta.")
        rid = int(ctx.partes[2])
        con.execute("DELETE FROM receta_producto WHERE id=? AND producto_id=?", (rid, producto_id))
        auditar(con, ctx.user["username"], "eliminar", "receta_producto", f"Producto {prod['codigo']}: se quitó una materia prima")
        con.commit()
        return {"ok": True}
    raise ApiError(405, "Método no permitido.")


def periodo_base(ctx, con, eid):
    """Periodo cuyas unidades presupuestadas sirven de base al CIF.

    Se usa el periodo indicado en la solicitud; si no se indica, el periodo abierto más
    reciente y, si no hay abiertos, el más reciente. Devuelve la fila o None.
    """
    periodo_id = ctx.query.get("periodo_id")
    if periodo_id:
        p = con.execute("SELECT * FROM periodos WHERE id=? AND empresa_id=?", (periodo_id, eid)).fetchone()
        if p:
            return p
    return con.execute(
        "SELECT * FROM periodos WHERE empresa_id=? ORDER BY (estado='abierto') DESC, fecha_inicio DESC, id DESC LIMIT 1",
        (eid,)).fetchone()


def _unidades_presupuestadas(ctx, con, eid):
    """Volumen de producción presupuestado del periodo base (ver periodo_base).

    Si ningún periodo tiene el dato cargado, se usa el número de productos como último
    recurso para no dividir por cero; la hoja de costo lo advierte en `advertencias_cif`.
    """
    p = periodo_base(ctx, con, eid)
    if p and p["unidades_presupuestadas"]:
        return p["unidades_presupuestadas"]
    return con.execute("SELECT COUNT(*) n FROM productos WHERE empresa_id=?", (eid,)).fetchone()["n"] or 1


def bases_totales_cif(con, eid, unidades_presupuestadas, producto_id, base_row):
    """Base total esperada del periodo y consumo estándar del producto para una base de aplicación.

    Se asume, como aproximación para una empresa con pocas líneas de producto, que cada
    producto alcanza el mismo volumen presupuestado del periodo. Para las bases incorporadas
    (mano de obra directa y horas máquina) esa base total es la suma de las horas estándar por
    unidad de cada producto, multiplicada por ese volumen; para una base personalizada se usa
    el mismo principio, tomando el consumo estándar que se haya cargado en «Productos → Hoja de
    costo» para esa base. Devuelve (base_total, consumo_estandar_de_este_producto).
    """
    codigo = str(base_row["codigo"]).lower()
    if codigo == "mano_obra_directa":
        suma = con.execute("SELECT COALESCE(SUM(horas_mod_std),0) s FROM productos WHERE empresa_id=?", (eid,)).fetchone()["s"]
        prod = con.execute("SELECT horas_mod_std FROM productos WHERE id=?", (producto_id,)).fetchone()
        return suma * unidades_presupuestadas, (prod["horas_mod_std"] if prod else 0)
    if codigo == "hora_maquina":
        suma = con.execute("SELECT COALESCE(SUM(horas_maquina_std),0) s FROM productos WHERE empresa_id=?", (eid,)).fetchone()["s"]
        prod = con.execute("SELECT horas_maquina_std FROM productos WHERE id=?", (producto_id,)).fetchone()
        return suma * unidades_presupuestadas, (prod["horas_maquina_std"] if prod else 0)
    if codigo == "unidades_producidas":
        return unidades_presupuestadas, 1
    # Base personalizada: se busca el consumo estándar cargado por producto.
    suma = con.execute(
        "SELECT COALESCE(SUM(pb.cantidad_estandar),0) s FROM producto_base_estandar pb "
        "JOIN productos p ON p.id = pb.producto_id WHERE p.empresa_id=? AND pb.base_id=?",
        (eid, base_row["id"])).fetchone()["s"]
    fila = con.execute("SELECT cantidad_estandar FROM producto_base_estandar WHERE producto_id=? AND base_id=?",
                        (producto_id, base_row["id"])).fetchone()
    return suma * unidades_presupuestadas, (fila["cantidad_estandar"] if fila else 0)


def hoja_costo(ctx, con):
    eid = _empresa_id(ctx, con)
    try:
        producto_id = int(ctx.query.get("producto_id"))
    except (TypeError, ValueError):
        raise ApiError(400, "Selecciona un producto para ver su hoja de costo.")
    prod = con.execute("SELECT * FROM productos WHERE id=? AND empresa_id=?", (producto_id, eid)).fetchone()
    if not prod:
        raise ApiError(404, "El producto no existe en esta empresa.")

    materiales = con.execute(
        "SELECT r.cantidad_estandar, m.codigo, m.descripcion, m.costo_estandar, m.eficiencia_pct "
        "FROM receta_producto r JOIN materias_primas m ON m.id = r.materia_prima_id WHERE r.producto_id=?",
        (producto_id,)).fetchall()
    detalle_mp, costo_mp = [], 0.0
    for m in materiales:
        factor = 100.0 / m["eficiencia_pct"] if m["eficiencia_pct"] else 1.0
        cant_ajustada = m["cantidad_estandar"] * factor
        subtotal = round(cant_ajustada * m["costo_estandar"], 2)
        costo_mp += subtotal
        detalle_mp.append({"codigo": m["codigo"], "descripcion": m["descripcion"], "cantidad": round(cant_ajustada, 4),
                            "costo_unitario": m["costo_estandar"], "subtotal": subtotal})

    trabajadores = con.execute("SELECT tarifa_std_hora FROM trabajadores WHERE empresa_id=?", (eid,)).fetchall()
    tarifa_prom = (sum(t["tarifa_std_hora"] for t in trabajadores) / len(trabajadores)) if trabajadores else 0.0
    costo_mod = round(prod["horas_mod_std"] * tarifa_prom, 2)

    conceptos = con.execute(
        "SELECT c.*, b.codigo AS base_codigo, b.nombre AS base_nombre FROM cif_conceptos c "
        "JOIN bases_aplicacion b ON b.id = c.base_aplicacion_id WHERE c.empresa_id=?", (eid,)).fetchall()
    unidades_presupuestadas = _unidades_presupuestadas(ctx, con, eid)
    costo_cif, detalle_cif = 0.0, []
    cif_variable, cif_fijo_periodo = 0.0, 0.0
    for c in conceptos:
        base_row = {"id": c["base_aplicacion_id"], "codigo": c["base_codigo"]}
        base_total, base_unidad = bases_totales_cif(con, eid, unidades_presupuestadas, producto_id, base_row)
        tasa = (c["presupuestado"] / base_total) if base_total else 0.0
        aplicado = round(tasa * base_unidad, 2)
        costo_cif += aplicado
        if c["tipo"] == "variable":
            cif_variable += aplicado
        else:
            cif_fijo_periodo += c["presupuestado"]
        detalle_cif.append({"codigo": c["codigo"], "descripcion": c["descripcion"], "base": c["base_nombre"], "tipo": c["tipo"],
                             "tasa": round(tasa, 4), "aplicado": aplicado})

    costo_mp, costo_mod, costo_cif = round(costo_mp, 2), round(costo_mod, 2), round(costo_cif, 2)
    total = round(costo_mp + costo_mod + costo_cif, 2)
    costo_variable_unitario = round(costo_mp + costo_mod + cif_variable, 2)
    margen_contribucion = round(prod["precio_venta"] - costo_variable_unitario, 2) if prod["precio_venta"] else None
    punto_equilibrio_unidades = (round(cif_fijo_periodo / margen_contribucion, 1)
                                  if margen_contribucion and margen_contribucion > 0 else None)
    return {
        "producto": {"codigo": prod["codigo"], "descripcion": prod["descripcion"], "precio_venta": prod["precio_venta"]},
        "materiales": detalle_mp, "costo_mp": costo_mp,
        "costo_mod": costo_mod, "horas_mod_std": prod["horas_mod_std"], "tarifa_mod_promedio": round(tarifa_prom, 2),
        "cif": detalle_cif, "costo_cif": costo_cif,
        "total": total,
        "margen": round(prod["precio_venta"] - total, 2) if prod["precio_venta"] else None,
        "costo_variable_unitario": costo_variable_unitario,
        "costos_fijos_periodo": round(cif_fijo_periodo, 2),
        "margen_contribucion_unitario": margen_contribucion,
        "punto_equilibrio_unidades": punto_equilibrio_unidades,
        "periodo": _periodo_info(ctx, con, eid),
        "advertencias_cif": _advertencias_cif(ctx, con, eid, conceptos),
    }


def _periodo_info(ctx, con, eid):
    p = periodo_base(ctx, con, eid)
    return {"id": p["id"], "nombre": p["nombre"]} if p else None


def advertencias_bases_cif(con, eid, unidades_presupuestadas):
    """Conceptos de CIF con valor presupuestado que NO se están aplicando porque su base no tiene consumo cargado."""
    avisos = []
    filas = con.execute(
        "SELECT c.descripcion, b.id AS base_id, b.codigo, b.nombre FROM cif_conceptos c "
        "JOIN bases_aplicacion b ON b.id = c.base_aplicacion_id WHERE c.empresa_id=? AND c.presupuestado > 0 ORDER BY c.codigo", (eid,)).fetchall()
    for c in filas:
        total, _ = bases_totales_cif(con, eid, unidades_presupuestadas, 0, {"id": c["base_id"], "codigo": c["codigo"]})
        if total > 0:
            continue
        codigo = str(c["codigo"]).lower()
        donde = ("cargue las horas de mano de obra por unidad de cada producto en «Productos»" if codigo == "mano_obra_directa" else
                 "cargue las horas máquina por unidad de cada producto en «Productos»" if codigo == "hora_maquina" else
                 "cárguelo en «Hoja de costo», panel «Bases de aplicación personalizadas»")
        avisos.append(f"El CIF «{c['descripcion']}» usa la base «{c['nombre']}», pero ningún producto tiene consumo estándar de esa base: "
                      f"por ahora no se está aplicando a ningún costo. Para aplicarlo, {donde}.")
    return avisos


def _advertencias_cif(ctx, con, eid, conceptos):
    avisos = []
    if not conceptos:
        return avisos
    p = periodo_base(ctx, con, eid)
    if not p:
        avisos.append("No hay periodos contables: el CIF se repartió de forma aproximada. Crea un periodo con sus unidades presupuestadas.")
    elif not p["unidades_presupuestadas"]:
        avisos.append(f"El periodo «{p['nombre']}» no tiene unidades de producción presupuestadas: el CIF se repartió de forma "
                      "aproximada. Cárgalas en «Periodos contables» para un costo correcto.")
    return avisos + advertencias_bases_cif(con, eid, _unidades_presupuestadas(ctx, con, eid))
    p = periodo_base(ctx, con, eid)
    if not p:
        return "No hay periodos contables: el CIF se repartió de forma aproximada. Crea un periodo con sus unidades presupuestadas."
    if not p["unidades_presupuestadas"]:
        return (f"El periodo «{p['nombre']}» no tiene unidades de producción presupuestadas: el CIF se repartió de forma "
                "aproximada. Cárgalas en «Periodos contables» para un costo correcto.")
    return None


MIME_LOGO_PERMITIDOS = ("image/png", "image/jpeg", "image/webp", "image/svg+xml")
LOGO_MAX_BYTES = 350_000


def subir_logo(ctx, con, empresa_id):
    _requiere_permiso(ctx, con, "empresas")
    e = con.execute("SELECT * FROM empresas WHERE id=?", (empresa_id,)).fetchone()
    if not e:
        raise ApiError(404, "La empresa no existe.")
    data_uri = str(ctx.body.get("data", ""))
    if not data_uri.startswith("data:"):
        raise ApiError(400, "El archivo no tiene un formato de imagen válido.")
    try:
        cabecera, b64 = data_uri.split(",", 1)
        mime = cabecera.split(";")[0][5:]
    except ValueError:
        raise ApiError(400, "El archivo no tiene un formato de imagen válido.")
    if mime not in MIME_LOGO_PERMITIDOS:
        raise ApiError(400, "Solo se aceptan imágenes PNG, JPG, WEBP o SVG para el logo.")
    if len(b64) > LOGO_MAX_BYTES:
        raise ApiError(400, "El logo es demasiado grande. Usa una imagen de menos de 250 KB.")
    con.execute("UPDATE empresas SET logo=? WHERE id=?", (data_uri, empresa_id))
    auditar(con, ctx.user["username"], "editar", "empresas", f"Logo actualizado para {e['razon_social']}")
    con.commit()
    return {"ok": True}


def quitar_logo(ctx, con, empresa_id):
    _requiere_permiso(ctx, con, "empresas")
    e = con.execute("SELECT * FROM empresas WHERE id=?", (empresa_id,)).fetchone()
    if not e:
        raise ApiError(404, "La empresa no existe.")
    con.execute("UPDATE empresas SET logo=NULL WHERE id=?", (empresa_id,))
    auditar(con, ctx.user["username"], "editar", "empresas", f"Logo eliminado para {e['razon_social']}")
    con.commit()
    return {"ok": True}


def producto_base(ctx, con):
    """Consumo estándar de bases de aplicación personalizadas para un producto (producto_base_estandar)."""
    if len(ctx.partes) < 2:
        raise ApiError(400, "Falta indicar el producto.")
    producto_id = int(ctx.partes[1])
    eid = _empresa_id(ctx, con)
    prod = con.execute("SELECT * FROM productos WHERE id=? AND empresa_id=?", (producto_id, eid)).fetchone()
    if not prod:
        raise ApiError(404, "El producto no existe en esta empresa.")

    if ctx.method == "GET":
        filas = con.execute(
            "SELECT pb.id, pb.base_id, pb.cantidad_estandar, b.codigo, b.nombre FROM producto_base_estandar pb "
            "JOIN bases_aplicacion b ON b.id = pb.base_id WHERE pb.producto_id=? ORDER BY b.codigo", (producto_id,)).fetchall()
        return [_fila(f) for f in filas]

    _requiere_permiso(ctx, con, "productos")
    if ctx.method == "POST":
        base_id = ctx.body.get("base_id")
        cant, err = validar_campo({"label": "Cantidad estándar", "tipo": "number", "req": True, "positivo": False}, ctx.body.get("cantidad_estandar"), ctx.lang)
        if err:
            raise ApiError(400, err, {"cantidad_estandar": err})
        base = con.execute("SELECT * FROM bases_aplicacion WHERE id=? AND empresa_id=?", (base_id, eid)).fetchone()
        if not base:
            raise ApiError(400, "Selecciona una base de aplicación válida.", {"base_id": "No existe en esta empresa."})
        if base["protegida"]:
            raise ApiError(400, "Las horas de MOD y de máquina se cargan en «Productos», no aquí. Esta pantalla es solo para bases personalizadas.")
        existente = con.execute("SELECT id FROM producto_base_estandar WHERE producto_id=? AND base_id=?", (producto_id, base_id)).fetchone()
        if existente:
            con.execute("UPDATE producto_base_estandar SET cantidad_estandar=? WHERE id=?", (cant, existente["id"]))
            rid = existente["id"]
        else:
            rid = con.execute("INSERT INTO producto_base_estandar (producto_id, base_id, cantidad_estandar) VALUES (?,?,?)",
                              (producto_id, base_id, cant)).lastrowid
        auditar(con, ctx.user["username"], "editar", "producto_base_estandar", f"Producto {prod['codigo']}: consumo estándar de «{base['nombre']}»")
        con.commit()
        return {"id": rid}

    if ctx.method == "DELETE":
        if len(ctx.partes) < 3:
            raise ApiError(400, "Falta el identificador del renglón.")
        rid = int(ctx.partes[2])
        con.execute("DELETE FROM producto_base_estandar WHERE id=? AND producto_id=?", (rid, producto_id))
        auditar(con, ctx.user["username"], "eliminar", "producto_base_estandar", f"Producto {prod['codigo']}")
        con.commit()
        return {"ok": True}
    raise ApiError(405, "Método no permitido.")


PATRON_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
CLAVES_TEMA = ("acento", "lateral", "fondo")


def guardar_tema(ctx, con, empresa_id):
    _requiere_permiso(ctx, con, "empresas")
    e = con.execute("SELECT * FROM empresas WHERE id=?", (empresa_id,)).fetchone()
    if not e:
        raise ApiError(404, "La empresa no existe.")
    tema = ctx.body.get("tema")
    if tema is None:
        con.execute("UPDATE empresas SET tema=NULL WHERE id=?", (empresa_id,))
        auditar(con, ctx.user["username"], "editar", "empresas", f"Colores restablecidos a los predeterminados para {e['razon_social']}")
        con.commit()
        return {"ok": True, "tema": None}
    if not isinstance(tema, dict):
        raise ApiError(400, "Los colores enviados no tienen un formato válido.")
    limpio = {}
    for clave in CLAVES_TEMA:
        valor = tema.get(clave)
        if not valor:
            continue
        if not PATRON_COLOR.match(str(valor)):
            raise ApiError(400, f"El color elegido para «{clave}» no es válido.")
        limpio[clave] = valor.lower()
    con.execute("UPDATE empresas SET tema=? WHERE id=?", (json.dumps(limpio), empresa_id))
    auditar(con, ctx.user["username"], "editar", "empresas", f"Colores personalizados para {e['razon_social']}")
    con.commit()
    return {"ok": True, "tema": limpio}


def _resumen(datos):
    for k in ("codigo", "numero", "nombre", "descripcion", "razon_social"):
        if k in datos:
            return f"{k}: {datos[k]}"
    return ""
