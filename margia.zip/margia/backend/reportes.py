"""Dashboard (KPIs y series para gráficos) y reportes exportables (Excel .xlsx, con respaldo en CSV)."""
import csv
import io

from .api import ApiError, _empresa_id, _fila

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    _TIENE_OPENPYXL = True
except ImportError:  # el .exe empaquetado siempre lo trae; esto es solo respaldo para ejecutar el código fuente sin instalarlo
    _TIENE_OPENPYXL = False


def dashboard(ctx, con):
    eid = _empresa_id(ctx, con)
    periodo_id = ctx.query.get("periodo_id")
    producto_id = ctx.query.get("producto_id")

    sql = ("SELECT o.*, p.codigo AS producto_codigo, p.descripcion AS producto_descripcion "
           "FROM ordenes_produccion o JOIN productos p ON p.id=o.producto_id "
           "WHERE o.empresa_id=? AND o.estado='terminada'")
    params = [eid]
    if periodo_id:
        sql += " AND o.periodo_id=?"
        params.append(periodo_id)
    if producto_id:
        sql += " AND o.producto_id=?"
        params.append(producto_id)
    ordenes = con.execute(sql, params).fetchall()

    if not ordenes:
        return {"ordenes": 0, "sin_datos": True}

    total_producido = sum(o["cantidad_producida"] for o in ordenes)
    costo_total = 0.0
    costo_std_total = 0.0
    var_por_tipo = {}
    serie_costo = []
    for o in ordenes:
        cr = con.execute("SELECT * FROM costos_reales WHERE orden_id=?", (o["id"],)).fetchone()
        if not cr:
            continue
        costo_total += cr["total"]
        # costo estándar equivalente para la cantidad producida (recalculado con la misma lógica que hoja de costo,
        # usando el mismo periodo de la orden para que la base de aplicación del CIF coincida con la del costo real)
        from .api import hoja_costo, Ctx
        h = hoja_costo(Ctx("GET", [], {"producto_id": o["producto_id"], "empresa_id": eid, "periodo_id": o["periodo_id"]}, {}, None, None), con)
        std_unit = h["total"]
        costo_std_total += std_unit * o["cantidad_producida"]
        serie_costo.append({"orden": o["numero"], "fecha": o["fecha"], "producto": o["producto_codigo"],
                             "estandar_unitario": std_unit, "real_unitario": cr["total_unitario"]})
        for v in con.execute("SELECT tipo, monto FROM variaciones WHERE orden_id=? AND tipo != 'total'", (o["id"],)):
            var_por_tipo[v["tipo"]] = var_por_tipo.get(v["tipo"], 0.0) + v["monto"]

    costo_real_unitario_prom = round(costo_total / total_producido, 2) if total_producido else 0
    costo_std_unitario_prom = round(costo_std_total / total_producido, 2) if total_producido else 0
    diff_pct = round(100 * (costo_real_unitario_prom - costo_std_unitario_prom) / costo_std_unitario_prom, 1) if costo_std_unitario_prom else 0

    return {
        "sin_datos": False,
        "ordenes": len(ordenes),
        "unidades_producidas": total_producido,
        "costo_total_produccion": round(costo_total, 2),
        "costo_estandar_unitario": costo_std_unitario_prom,
        "costo_real_unitario": costo_real_unitario_prom,
        "diferencia_pct": diff_pct,
        "variaciones": {k: round(v, 2) for k, v in var_por_tipo.items()},
        "serie": serie_costo,
    }


# ---- Reportes: se arma (título, encabezados, filas) y se exporta a .xlsx o .csv ----
REPORTES_NOMBRES = {
    "materiales": "reporte_materiales", "mod": "reporte_mano_de_obra", "cif": "reporte_cif",
    "hoja_costos": "hoja_de_costos", "produccion": "reporte_produccion", "variaciones": "reporte_variaciones",
    "estado_costos_produccion": "estado_de_costos_de_produccion", "inventario": "reporte_inventario",
    "historico_costos": "historico_costo_estandar",
}


def _datos_reporte(ctx, con, tipo):
    eid = _empresa_id(ctx, con)

    if tipo == "materiales":
        filas = con.execute("SELECT codigo, descripcion, costo_estandar, proveedor, eficiencia_pct, stock_minimo "
                             "FROM materias_primas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall()
        return ("Reporte de materiales",
                ["Código", "Descripción", "Costo estándar", "Proveedor", "Eficiencia %", "Existencia mínima"],
                [[f["codigo"], f["descripcion"], f["costo_estandar"], f["proveedor"] or "", f["eficiencia_pct"], f["stock_minimo"]] for f in filas])

    if tipo == "mod":
        filas = con.execute("SELECT codigo, nombre, cargo, salario_mensual, tarifa_std_hora FROM trabajadores WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall()
        return ("Reporte de mano de obra",
                ["Código", "Nombre", "Cargo", "Salario mensual", "Tarifa estándar por hora"],
                [[f["codigo"], f["nombre"], f["cargo"], f["salario_mensual"], f["tarifa_std_hora"]] for f in filas])

    if tipo == "cif":
        filas = con.execute(
            "SELECT c.codigo, c.descripcion, c.tipo, b.nombre AS base, c.presupuestado, c.real FROM cif_conceptos c "
            "JOIN bases_aplicacion b ON b.id = c.base_aplicacion_id WHERE c.empresa_id=? ORDER BY c.codigo", (eid,)).fetchall()
        return ("Reporte de CIF",
                ["Código", "Descripción", "Tipo", "Base de aplicación", "Presupuestado", "Real"],
                [[f["codigo"], f["descripcion"], f["tipo"], f["base"], f["presupuestado"], f["real"]] for f in filas])

    if tipo == "hoja_costos":
        from .api import hoja_costo, Ctx
        filas = con.execute("SELECT id, codigo, descripcion FROM productos WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall()
        from .api import periodo_base
        per = periodo_base(ctx, con, eid)
        q = {"empresa_id": eid, **({"periodo_id": per["id"]} if per else {})}
        salida = []
        for p in filas:
            h = hoja_costo(Ctx("GET", [], {**q, "producto_id": p["id"]}, {}, None, None), con)
            salida.append([p["codigo"], p["descripcion"], h["costo_mp"], h["costo_mod"], h["costo_cif"], h["total"], h["producto"]["precio_venta"], h["margen"]])
        return ("Hoja de costos" + (f" — {per['nombre']}" if per else ""),
                ["Código", "Producto", "Costo MP", "Costo MOD", "Costo CIF", "Costo estándar unitario", "Precio de venta", "Margen"], salida)

    if tipo == "produccion":
        filas = con.execute(
            "SELECT o.numero, o.fecha, p.codigo AS producto, o.cantidad_planeada, o.cantidad_producida, "
            "o.unidades_en_proceso, o.estado FROM ordenes_produccion o JOIN productos p ON p.id=o.producto_id "
            "WHERE o.empresa_id=? ORDER BY o.fecha DESC", (eid,)).fetchall()
        return ("Reporte de producción",
                ["N° orden", "Fecha", "Producto", "Cantidad planeada", "Cantidad producida", "Unidades en proceso", "Estado"],
                [[f["numero"], f["fecha"], f["producto"], f["cantidad_planeada"], f["cantidad_producida"], f["unidades_en_proceso"], f["estado"]] for f in filas])

    if tipo == "variaciones":
        filas = con.execute(
            "SELECT o.numero, o.fecha, v.tipo, v.monto, v.clasificacion FROM variaciones v "
            "JOIN ordenes_produccion o ON o.id=v.orden_id WHERE o.empresa_id=? ORDER BY o.fecha DESC, v.id", (eid,)).fetchall()
        return ("Reporte de variaciones",
                ["N° orden", "Fecha", "Variación", "Monto", "Clasificación"],
                [[f["numero"], f["fecha"], f["tipo"], f["monto"], f["clasificacion"]] for f in filas])

    if tipo == "estado_costos_produccion":
        filas = con.execute(
            "SELECT o.numero, o.fecha, p.codigo AS producto, o.cantidad_producida, cr.costo_mp, cr.costo_mod, cr.costo_cif, cr.total "
            "FROM costos_reales cr JOIN ordenes_produccion o ON o.id=cr.orden_id JOIN productos p ON p.id=o.producto_id "
            "WHERE o.empresa_id=? ORDER BY o.fecha DESC", (eid,)).fetchall()
        return ("Estado de costos de producción",
                ["N° orden", "Fecha", "Producto", "Unidades producidas", "Costo MP", "Costo MOD", "Costo CIF", "Costo total"],
                [[f["numero"], f["fecha"], f["producto"], f["cantidad_producida"], f["costo_mp"], f["costo_mod"], f["costo_cif"], f["total"]] for f in filas])

    if tipo == "inventario":
        from . import inventario
        datos = inventario.existencias(ctx, con)
        return ("Reporte de inventario",
                ["Código", "Descripción", "Existencias", "Costo promedio", "Valor en inventario", "Existencia mínima", "Estado"],
                [[m["codigo"], m["descripcion"], m["existencias"], m["costo_promedio"], m["valor"], m["stock_minimo"],
                  {"ok": "Normal", "bajo": "Por debajo del mínimo", "negativo": "Negativo (revisar)", "sin_datos": "Sin movimientos"}[m["estado"]]]
                 for m in datos["materiales"]])

    if tipo == "historico_costos":
        filas = con.execute(
            "SELECT pe.nombre AS periodo, p.codigo, p.descripcion, ce.costo_mp, ce.costo_mod, ce.costo_cif, ce.total, ce.precio_venta "
            "FROM costos_estandar ce JOIN productos p ON p.id=ce.producto_id JOIN periodos pe ON pe.id=ce.periodo_id "
            "WHERE p.empresa_id=? ORDER BY p.codigo, pe.fecha_inicio", (eid,)).fetchall()
        return ("Histórico del costo estándar",
                ["Periodo", "Código", "Producto", "Costo MP", "Costo MOD", "Costo CIF", "Costo estándar unitario", "Precio de venta"],
                [[f["periodo"], f["codigo"], f["descripcion"], f["costo_mp"], f["costo_mod"], f["costo_cif"], f["total"], f["precio_venta"]] for f in filas])

    raise ApiError(404, "Ese reporte no existe.")


def _a_csv(encabezados, filas):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(encabezados)
    for f in filas:
        w.writerow(f)
    return buf.getvalue().encode("utf-8-sig")


def _a_xlsx(titulo, encabezados, filas, color="0F766E"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = titulo[:31] or "Reporte"
    ws.append(encabezados)
    for celda in ws[1]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor=color)
    for fila in filas:
        ws.append(fila)
    for col in ws.columns:
        ancho = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[col[0].column_letter].width = min(max(ancho + 2, 10), 45)
    ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _color_empresa(ctx, con):
    """Color principal de la empresa en formato RRGGBB (para los encabezados de Excel)."""
    import json as _json
    fila = con.execute("SELECT tema FROM empresas WHERE id=?", (_empresa_id(ctx, con),)).fetchone()
    try:
        return (_json.loads(fila["tema"]).get("acento") or "#0f766e").lstrip("#").upper()
    except (TypeError, ValueError, AttributeError):
        return "0F766E"


def generar_reporte(ctx, con, tipo):
    """Devuelve (nombre_de_archivo, bytes, tipo_mime) — .xlsx si openpyxl está disponible, si no .csv."""
    titulo, encabezados, filas = _datos_reporte(ctx, con, tipo)
    base = REPORTES_NOMBRES.get(tipo, tipo)
    if _TIENE_OPENPYXL:
        return f"{base}.xlsx", _a_xlsx(titulo, encabezados, filas, _color_empresa(ctx, con)), \
               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    return f"{base}.csv", _a_csv(encabezados, filas), "text/csv; charset=utf-8"


def generar_csv(ctx, con, tipo):
    """Se mantiene para la vista de «Ver e imprimir» (siempre en texto plano, tabla sencilla)."""
    _titulo, encabezados, filas = _datos_reporte(ctx, con, tipo)
    nombre = f"{REPORTES_NOMBRES.get(tipo, tipo)}.csv"
    return nombre, _a_csv(encabezados, filas).decode("utf-8-sig")


# ---- PDF con la identidad de la empresa -------------------------------------
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
    _TIENE_REPORTLAB = True
except ImportError:
    _TIENE_REPORTLAB = False


def _formato_celda(v):
    if isinstance(v, bool) or v is None:
        return "" if v is None else ("Sí" if v else "No")
    if isinstance(v, (int, float)):
        texto = f"{v:,.2f}" if isinstance(v, float) else f"{v:,.0f}"
        return texto.replace(",", "§").replace(".", ",").replace("§", ".")
    return str(v)


def _logo_flowable(data_uri, alto_mm=16):
    """Convierte el logo guardado (data URI) en imagen para el PDF. Los SVG no se incrustan."""
    if not data_uri or "base64," not in data_uri or data_uri.startswith("data:image/svg"):
        return None
    try:
        import base64
        from PIL import Image as PILImage
        crudo = base64.b64decode(data_uri.split("base64,", 1)[1])
        img = PILImage.open(io.BytesIO(crudo))
        if img.mode not in ("RGB", "L"):
            fondo = PILImage.new("RGB", img.size, (255, 255, 255))
            fondo.paste(img.convert("RGBA"), mask=img.convert("RGBA").split()[-1])
            img = fondo
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        alto = alto_mm * mm
        ancho = alto * img.width / img.height
        if ancho > 45 * mm:
            ancho, alto = 45 * mm, 45 * mm * img.height / img.width
        return Image(buf, width=ancho, height=alto)
    except Exception:
        return None


def generar_pdf(ctx, con, tipo):
    if not _TIENE_REPORTLAB:
        raise ApiError(500, "Falta la librería reportlab para generar PDF. Instálela con: python -m pip install -r requirements.txt")
    titulo, encabezados, filas = _datos_reporte(ctx, con, tipo)
    import datetime
    import json as _json
    eid = _empresa_id(ctx, con)
    emp = con.execute("SELECT * FROM empresas WHERE id=?", (eid,)).fetchone()
    try:
        tema = _json.loads(emp["tema"]) if emp["tema"] else {}
    except (TypeError, ValueError):
        tema = {}
    acento = colors.HexColor(tema.get("acento", "#0f766e"))
    tinta, suave, linea = colors.HexColor("#161b22"), colors.HexColor("#6b7280"), colors.HexColor("#e7e9ec")

    horizontal = len(encabezados) > 5
    tam = landscape(A4) if horizontal else A4
    margen = 14 * mm
    buf = io.BytesIO()
    generado = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    def pie(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(linea)
        canvas.line(margen, 11 * mm, tam[0] - margen, 11 * mm)
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(suave)
        canvas.drawString(margen, 7 * mm, f"{emp['razon_social']} · {titulo} · Generado el {generado} por {ctx.user['nombre']}")
        canvas.drawRightString(tam[0] - margen, 7 * mm, f"Página {doc.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=tam, leftMargin=margen, rightMargin=margen, topMargin=margen, bottomMargin=16 * mm,
                            title=f"{titulo} — {emp['razon_social']}", author=emp["razon_social"])
    est_empresa = ParagraphStyle("e", fontName="Helvetica-Bold", fontSize=13, textColor=tinta, leading=16)
    est_datos = ParagraphStyle("d", fontName="Helvetica", fontSize=8.5, textColor=suave, leading=11)
    est_titulo = ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=15, textColor=acento, leading=19, spaceBefore=4)
    est_celda = ParagraphStyle("c", fontName="Helvetica", fontSize=8, leading=10, textColor=tinta)
    est_enc = ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=7.5, leading=9, textColor=colors.white)

    datos_emp = f"NIT {emp['nit']}"
    if emp["direccion"]:
        datos_emp += f" · {emp['direccion']}"
    if emp["telefono"]:
        datos_emp += f" · Tel. {emp['telefono']}"
    if emp["email"]:
        datos_emp += f" · {emp['email']}"
    texto_cab = [Paragraph(emp["razon_social"], est_empresa), Paragraph(datos_emp, est_datos)]
    logo = _logo_flowable(emp["logo"])
    ancho_util = tam[0] - 2 * margen
    cab = Table([[logo, texto_cab]] if logo else [[texto_cab]],
                colWidths=[logo.drawWidth + 5 * mm, ancho_util - logo.drawWidth - 5 * mm] if logo else [ancho_util])
    cab.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    historia = [cab, Spacer(1, 3 * mm),
                Table([[""]], colWidths=[ancho_util], rowHeights=[1.2], style=[("BACKGROUND", (0, 0), (-1, -1), acento)]),
                Paragraph(titulo, est_titulo), Spacer(1, 3 * mm)]

    if not filas:
        historia.append(Paragraph("Este reporte no tiene datos todavía.", est_datos))
    else:
        numericas = [all(isinstance(f[i], (int, float)) or f[i] in (None, "") for f in filas) for i in range(len(encabezados))]
        est_enc_der = ParagraphStyle("hd", parent=est_enc, alignment=2)
        cuerpo = [[Paragraph(h, est_enc_der if numericas[i] else est_enc) for i, h in enumerate(encabezados)]]
        for f in filas:
            cuerpo.append([Paragraph(_formato_celda(v), ParagraphStyle("n", parent=est_celda, alignment=2) if numericas[i] else est_celda)
                           for i, v in enumerate(f)])
        tabla = Table(cuerpo, repeatRows=1, colWidths=[ancho_util / len(encabezados)] * len(encabezados))
        estilo = [
            ("BACKGROUND", (0, 0), (-1, 0), acento),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LINEBELOW", (0, 1), (-1, -1), 0.4, linea),
        ]
        for i in range(2, len(cuerpo), 2):
            estilo.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f7f8f9")))
        tabla.setStyle(TableStyle(estilo))
        historia.append(tabla)
        historia.append(Spacer(1, 3 * mm))
        historia.append(Paragraph(f"{len(filas)} registro{'s' if len(filas) != 1 else ''}", est_datos))

    doc.build(historia, onFirstPage=pie, onLaterPages=pie)
    return f"{REPORTES_NOMBRES.get(tipo, tipo)}.pdf", buf.getvalue()


# ---- Guía de primeros pasos (dashboard) --------------------------------------
def primeros_pasos(ctx, con):
    """Estado real de cada paso recomendado para empezar, calculado desde los datos de la empresa."""
    eid = _empresa_id(ctx, con)
    n = lambda sql: con.execute(sql, (eid,)).fetchone()[0]
    periodos = n("SELECT COUNT(*) FROM periodos WHERE empresa_id=?")
    periodos_con_unidades = n("SELECT COUNT(*) FROM periodos WHERE empresa_id=? AND unidades_presupuestadas > 0")
    materias = n("SELECT COUNT(*) FROM materias_primas WHERE empresa_id=?")
    trabajadores = n("SELECT COUNT(*) FROM trabajadores WHERE empresa_id=?")
    cif = n("SELECT COUNT(*) FROM cif_conceptos WHERE empresa_id=?")
    cif_con_valor = n("SELECT COUNT(*) FROM cif_conceptos WHERE empresa_id=? AND presupuestado > 0")
    productos = n("SELECT COUNT(*) FROM productos WHERE empresa_id=?")
    con_receta = n("SELECT COUNT(DISTINCT r.producto_id) FROM receta_producto r JOIN productos p ON p.id=r.producto_id WHERE p.empresa_id=?")
    ordenes = n("SELECT COUNT(*) FROM ordenes_produccion WHERE empresa_id=?")
    cerradas = n("SELECT COUNT(*) FROM ordenes_produccion WHERE empresa_id=? AND estado='terminada'")
    s = lambda k, uno, varios: f"{k} {uno if k == 1 else varios}."
    return {
        "empresa": {"hecho": True, "detalle": "Empresa creada."},
        "periodo": {"hecho": periodos_con_unidades > 0,
                    "detalle": (s(periodos, "periodo creado", "periodos creados") if periodos_con_unidades else
                                "Falta cargar las unidades presupuestadas del periodo." if periodos else "Aún no hay periodos.")},
        "materias": {"hecho": materias > 0, "detalle": s(materias, "materia prima", "materias primas") if materias else "Aún no hay materias primas."},
        "mano_obra": {"hecho": trabajadores > 0, "detalle": s(trabajadores, "trabajador", "trabajadores") if trabajadores else "Aún no hay trabajadores."},
        "cif": {"hecho": cif_con_valor > 0,
                "detalle": (s(cif, "concepto de CIF", "conceptos de CIF") if cif_con_valor else
                            "Los conceptos no tienen valor presupuestado." if cif else "Aún no hay costos indirectos.")},
        "productos": {"hecho": productos > 0, "detalle": s(productos, "producto", "productos") if productos else "Aún no hay productos."},
        "recetas": {"hecho": productos > 0 and con_receta == productos,
                    "detalle": (f"{con_receta} de {productos} productos tienen receta." if productos else "Primero crea tus productos.")},
        "orden": {"hecho": ordenes > 0, "detalle": s(ordenes, "orden registrada", "órdenes registradas") if ordenes else "Aún no hay órdenes."},
        "cierre": {"hecho": cerradas > 0, "detalle": s(cerradas, "orden cerrada", "órdenes cerradas") if cerradas else "Ninguna orden cerrada todavía."},
    }
