"""Validaciones de campos, con mensajes comprensibles para el usuario en español o inglés."""
import datetime

from .i18n import tr_etiqueta


def _num(v):
    if isinstance(v, bool):
        raise ValueError
    if isinstance(v, (int, float)):
        return float(v)
    return float(str(v).strip().replace(",", "."))


def validar_campo(campo, valor, lang="es"):
    """Devuelve (valor_limpio, mensaje_error). mensaje_error es None si todo está bien."""
    et = tr_etiqueta(campo["label"], lang)
    en = lang == "en"
    tipo = campo["tipo"]
    vacio = valor is None or (isinstance(valor, str) and valor.strip() == "")
    if vacio:
        if campo.get("req"):
            return None, (f"\u00ab{et}\u00bb is required." if en else f"«{et}» es obligatorio.")
        return campo.get("defecto"), None

    if tipo in ("text", "email"):
        v = str(valor).strip()
        mx = campo.get("max", 120)
        if len(v) > mx:
            return None, (f"\u00ab{et}\u00bb allows at most {mx} characters." if en else f"«{et}» admite máximo {mx} caracteres.")
        if tipo == "email" and ("@" not in v or "." not in v.split("@")[-1]):
            return None, (f"\u00ab{et}\u00bb doesn't look like a valid email (example: name@company.com)." if en
                           else f"«{et}» no parece un correo válido (ejemplo: nombre@empresa.com).")
        if campo.get("mayus"):
            v = v.upper()
        return v, None

    if tipo in ("number", "percent", "int"):
        try:
            n = _num(valor)
        except ValueError:
            return None, (f"\u00ab{et}\u00bb must be a number (example: 1250.50)." if en else f"«{et}» debe ser un número (ejemplo: 1250.50).")
        if n != n or n in (float("inf"), float("-inf")):
            return None, (f"\u00ab{et}\u00bb isn't a valid number." if en else f"«{et}» no es un número válido.")
        if n < 0:
            return None, (f"\u00ab{et}\u00bb can't be negative." if en else f"«{et}» no puede ser negativo.")
        if tipo == "int" and n != int(n):
            return None, (f"\u00ab{et}\u00bb must be a whole number." if en else f"«{et}» debe ser un número entero.")
        if tipo == "percent" and n > 100:
            return None, (f"\u00ab{et}\u00bb is a percentage and can't be greater than 100." if en
                           else f"«{et}» es un porcentaje y no puede ser mayor a 100.")
        if campo.get("positivo") and n <= 0:
            return None, (f"\u00ab{et}\u00bb must be greater than zero." if en else f"«{et}» debe ser mayor que cero.")
        if "min" in campo and n < campo["min"]:
            return None, (f"\u00ab{et}\u00bb must be at least {campo['min']}." if en else f"«{et}» debe ser al menos {campo['min']}.")
        return (int(n) if tipo == "int" else n), None

    if tipo == "date":
        try:
            d = datetime.date.fromisoformat(str(valor).strip())
        except ValueError:
            return None, (f"\u00ab{et}\u00bb isn't a valid date (use year-month-day, example: 2026-03-31)." if en
                           else f"«{et}» no es una fecha válida (use el formato año-mes-día, ejemplo: 2026-03-31).")
        if d.year < 1990 or d.year > 2100:
            return None, (f"\u00ab{et}\u00bb has a year out of range (1990 to 2100)." if en else f"«{et}» tiene un año fuera de rango (1990 a 2100).")
        return d.isoformat(), None

    if tipo == "select":
        opciones = [o["valor"] for o in campo["opciones"]]
        if valor not in opciones:
            return None, (f"\u00ab{et}\u00bb has a value that isn't allowed." if en else f"«{et}» tiene un valor no permitido.")
        return valor, None

    if tipo == "ref":
        try:
            return int(valor), None
        except (TypeError, ValueError):
            return None, (f"Select an option for \u00ab{et}\u00bb." if en else f"Seleccione una opción en «{et}».")

    return valor, None
