"""Lectura de config/config.ini y rutas del programa (funciona con PyInstaller)."""
import os
import sys
import configparser

FROZEN = getattr(sys, "frozen", False)
# Carpeta donde viven config/ y data/ (junto al .exe o en la raíz del proyecto)
APP_DIR = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Carpeta con los recursos empaquetados (frontend, esquema SQL)
RES_DIR = getattr(sys, "_MEIPASS", APP_DIR)


def resource(*parts):
    return os.path.join(RES_DIR, *parts)


def _carpeta_datos():
    """Carpeta base para data/ (base de datos y respaldos automáticos).

    Normalmente es la misma del programa. Si Windows no deja escribir ahí (por ejemplo,
    si se copió en «Archivos de programa»), se usa %LOCALAPPDATA%\\Margia para que
    el sistema funcione igual en vez de fallar al guardar.
    """
    prueba = os.path.join(APP_DIR, "data", ".prueba_escritura")
    try:
        os.makedirs(os.path.dirname(prueba), exist_ok=True)
        with open(prueba, "w") as f:
            f.write("ok")
        os.remove(prueba)
        return APP_DIR
    except OSError:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
        nueva, anterior = os.path.join(base, "Margia"), os.path.join(base, "Cifra")
        # Quien ya guardó sus datos con el nombre anterior sigue usando esa carpeta: no se mueve ni se pierde nada.
        return anterior if (os.path.isdir(anterior) and not os.path.isdir(nueva)) else nueva


DATA_BASE = _carpeta_datos()


AVISOS_CONFIG = []  # problemas encontrados en config.ini; el programa los muestra al iniciar


def _avisar(texto):
    if texto not in AVISOS_CONFIG:
        AVISOS_CONFIG.append(texto)


def _leer_config():
    """Lee config/config.ini aunque se haya editado con el Bloc de notas (con o sin BOM, UTF-8 o ANSI).

    Un archivo con errores nunca debe impedir que el programa abra: se avisa y se usan los valores por defecto.
    """
    ruta = os.path.join(APP_DIR, "config", "config.ini")
    cfg = configparser.ConfigParser(interpolation=None)
    if not os.path.isfile(ruta):
        _avisar("No se encontró config/config.ini: se usan los valores por defecto.")
        return cfg
    crudo = open(ruta, "rb").read()
    for codificacion in ("utf-8-sig", "cp1252"):
        try:
            cfg.read_string(crudo.decode(codificacion))
            return cfg
        except UnicodeDecodeError:
            continue
        except configparser.Error as e:
            _avisar(f"El archivo config/config.ini tiene un error y se ignoró ({str(e).splitlines()[0]}). "
                    "Se usan los valores por defecto; corrija el archivo o bórrelo.")
            return configparser.ConfigParser(interpolation=None)
    _avisar("No se pudo leer config/config.ini (codificación desconocida): se usan los valores por defecto.")
    return configparser.ConfigParser(interpolation=None)


_cfg = _leer_config()


def _variable_de_entorno(nombre):
    """MARGIA_<nombre>; si no existe, la que usaba el nombre anterior del programa (CIFRA_<nombre>), para no romper instalaciones."""
    for prefijo in ("MARGIA_", "CIFRA_"):
        valor = os.environ.get(prefijo + nombre.upper())
        if valor is not None and valor.strip() != "":
            return valor.strip()
    return None


def get(section, key, default=""):
    """Valor de config.ini. Una variable de entorno MARGIA_<SECCION>_<CLAVE> (por ejemplo MARGIA_SERVIDOR_HOST) tiene
    prioridad: permite configurar un servicio o un contenedor sin tocar el archivo."""
    env = _variable_de_entorno(f"{section}_{key}")
    if env is not None:
        return env
    return _cfg.get(section, key, fallback=str(default))


def get_int(section, key, default=0):
    try:
        return int(get(section, key, default))
    except ValueError:
        return int(default)


def puerto():
    """Puerto del servidor, validado (1024 a 65535)."""
    crudo = get("servidor", "puerto", 8765).strip()
    if crudo.isdigit() and 1024 <= int(crudo) <= 65535:
        return int(crudo)
    _avisar(f"El puerto «{crudo}» de config.ini no es válido (use un número entre 1024 y 65535). Se usa 8765.")
    return 8765


def clave_inicial_admin():
    """Contraseña con la que se crea el usuario «admin» en una base nueva, si se definió MARGIA_ADMIN_PASSWORD.

    Es lo que permite instalar Margia en un servidor sin dejar nunca la contraseña de fábrica (que es pública).
    """
    valor = os.environ.get("MARGIA_ADMIN_PASSWORD") or os.environ.get("CIFRA_ADMIN_PASSWORD") or ""  # CIFRA_: nombre anterior
    if not valor:
        return None
    if len(valor) < 6:
        _avisar("MARGIA_ADMIN_PASSWORD tiene menos de 6 caracteres: se ignoró.")
        return None
    return valor
