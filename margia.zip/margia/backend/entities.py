"""Definición de las entidades (tablas) administrables desde la interfaz.

Cada entidad describe sus campos; el frontend construye tablas y formularios
a partir de esta descripción y el backend valida con la misma definición.
"""


def F(name, label, tipo="text", req=False, **kw):
    d = {"name": name, "label": label, "tipo": tipo, "req": req}
    d.update(kw)
    return d


def opciones(*pares):
    return [{"valor": v, "texto": t} for v, t in pares]


def _regla_periodo(datos, con, existente):
    if datos["fecha_fin"] < datos["fecha_inicio"]:
        return {"fecha_fin": "La fecha final no puede ser anterior a la fecha inicial."}
    return {}


def _calc_trabajador(datos):
    factor = 1 + datos["prestaciones_pct"] / 100 + datos["cargas_pct"] / 100
    datos["tarifa_std_hora"] = round(datos["salario_mensual"] * factor / datos["horas_mes"], 2)


ENTIDADES = {
    "empresas": {
        "titulo": "Empresas", "singular": "empresa", "femenino": True, "scoped": False, "orden": "razon_social",
        "lista": ["codigo", "razon_social", "nit", "regimen", "moneda"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("razon_social", "Razón social", req=True, max=150),
            F("nit", "NIT", req=True, max=25),
            F("regimen", "Régimen tributario", "select", opciones=opciones(("comun", "Régimen ordinario"), ("simple", "Régimen simple"), ("especial", "Régimen especial"))),
            F("responsable_iva", "Responsable de IVA", "select", opciones=opciones(("si", "Sí"), ("no", "No"))),
            F("actividad_economica", "Actividad económica (CIIU)", max=60),
            F("direccion", "Dirección", max=150),
            F("telefono", "Teléfono", max=30),
            F("email", "Correo electrónico", "email"),
            F("moneda", "Moneda", req=True, max=5, mayus=True, defecto="COP"),
        ],
    },
    "periodos": {
        "titulo": "Periodos contables", "singular": "periodo", "scoped": True, "orden": "fecha_inicio DESC",
        "lista": ["codigo", "nombre", "fecha_inicio", "fecha_fin", "estado"],
        "reglas": _regla_periodo,
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("nombre", "Nombre", req=True, max=80),
            F("fecha_inicio", "Fecha inicial", "date", True),
            F("fecha_fin", "Fecha final", "date", True),
            F("estado", "Estado", "select", True, opciones=opciones(("abierto", "Abierto"), ("cerrado", "Cerrado")), defecto="abierto"),
            F("unidades_presupuestadas", "Unidades de producción presupuestadas para el periodo", "number", False, defecto=0,
              ayuda="Se usa para calcular la tasa de CIF cuya base es «unidades producidas». Déjelo en 0 si no aplica."),
        ],
    },
    "unidades_medida": {
        "titulo": "Unidades de medida", "singular": "unidad", "femenino": True, "scoped": False, "orden": "nombre",
        "lista": ["codigo", "nombre", "abreviatura"],
        "campos": [
            F("codigo", "Código", req=True, max=10, mayus=True),
            F("nombre", "Nombre", req=True, max=40),
            F("abreviatura", "Abreviatura", req=True, max=10),
        ],
    },
    "centros_costo": {
        "titulo": "Centros de costo", "singular": "centro de costo", "scoped": True, "orden": "codigo",
        "lista": ["codigo", "nombre", "tipo"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("nombre", "Nombre", req=True, max=80),
            F("tipo", "Tipo", "select", True, opciones=opciones(("produccion", "Producción"), ("servicio", "Servicio"), ("administrativo", "Administrativo")), defecto="produccion"),
        ],
    },
    "productos": {
        "titulo": "Productos", "singular": "producto", "scoped": True, "orden": "codigo",
        "lista": ["codigo", "descripcion", "unidad_id", "precio_venta", "horas_mod_std"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("descripcion", "Descripción", req=True, max=150),
            F("unidad_id", "Unidad de medida", "ref", True, ref="unidades_medida", ref_texto="abreviatura"),
            F("precio_venta", "Precio de venta", "number", True, defecto=0),
            F("horas_mod_std", "Horas de mano de obra estándar por unidad", "number", True, defecto=0),
            F("horas_maquina_std", "Horas máquina estándar por unidad", "number", True, defecto=0),
        ],
    },
    "materias_primas": {
        "titulo": "Materias primas", "singular": "materia prima", "femenino": True, "scoped": True, "orden": "codigo",
        "lista": ["codigo", "descripcion", "unidad_id", "costo_estandar", "proveedor", "eficiencia_pct"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("descripcion", "Descripción", req=True, max=150),
            F("unidad_id", "Unidad de medida (compra)", "ref", True, ref="unidades_medida", ref_texto="abreviatura"),
            F("unidad_estandar_id", "Unidad estándar", "ref", True, ref="unidades_medida", ref_texto="abreviatura"),
            F("costo_estandar", "Costo estándar por unidad estándar", "number", True, defecto=0),
            F("proveedor", "Proveedor", max=120),
            F("stock_minimo", "Existencia mínima (alerta de reposición)", "number", False, defecto=0),
            F("eficiencia_pct", "Eficiencia (100 = sin desperdicio)", "percent", True, defecto=100, positivo=True),
        ],
    },
    "trabajadores": {
        "titulo": "Mano de obra directa", "singular": "trabajador", "scoped": True, "orden": "codigo",
        "lista": ["codigo", "nombre", "cargo", "salario_mensual", "tarifa_std_hora"],
        "calculo": _calc_trabajador,
        "solo_lectura": ["tarifa_std_hora"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("nombre", "Nombre completo", req=True, max=120),
            F("cargo", "Cargo", req=True, max=80),
            F("salario_mensual", "Salario mensual", "number", True, positivo=True),
            F("prestaciones_pct", "Prestaciones sociales (%)", "percent", True, defecto=0),
            F("cargas_pct", "Cargas laborales (%)", "percent", True, defecto=0),
            F("horas_mes", "Horas laborales por mes", "number", True, defecto=192, min=1),
            F("tarifa_std_hora", "Tarifa estándar por hora (se calcula)", "number", False, calculado=True),
        ],
    },
    "bases_aplicacion": {
        "titulo": "Bases de aplicación de CIF", "singular": "base de aplicación", "femenino": True, "scoped": True, "orden": "protegida DESC, codigo",
        "lista": ["codigo", "nombre"],
        "campos": [
            F("codigo", "Código", req=True, max=30, mayus=True),
            F("nombre", "Nombre", req=True, max=80),
        ],
    },
    "cif_conceptos": {
        "titulo": "Conceptos de CIF", "singular": "concepto de CIF", "scoped": True, "orden": "codigo",
        "lista": ["codigo", "descripcion", "tipo", "base_aplicacion_id", "presupuestado", "real"],
        "campos": [
            F("codigo", "Código", req=True, max=20, mayus=True),
            F("descripcion", "Descripción", req=True, max=150),
            F("centro_costo_id", "Centro de costo", "ref", False, ref="centros_costo", ref_texto="nombre", scoped=True),
            F("tipo", "Comportamiento", "select", True, opciones=opciones(("fijo", "Fijo"), ("variable", "Variable"))),
            F("base_aplicacion_id", "Base de aplicación", "ref", True, ref="bases_aplicacion", ref_texto="nombre", scoped=True),
            F("presupuestado", "CIF presupuestado", "number", True, defecto=0),
            F("real", "CIF real", "number", True, defecto=0),
        ],
    },
}
