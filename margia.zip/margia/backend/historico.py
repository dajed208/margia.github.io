"""Histórico del costo estándar: se «congela» el costo estándar de cada producto al cierre de un
periodo, para comparar cómo evolucionó entre periodos aunque luego cambien recetas, precios o CIF."""
from .api import ApiError, _empresa_id, _requiere_permiso, auditar, hoja_costo, Ctx


def guardar(ctx, con):
    _requiere_permiso(ctx, con, "productos")
    eid = _empresa_id(ctx, con)
    try:
        periodo_id = int(ctx.body.get("periodo_id"))
    except (TypeError, ValueError):
        raise ApiError(400, "Selecciona el periodo cuyo costo estándar quieres guardar.")
    periodo = con.execute("SELECT * FROM periodos WHERE id=? AND empresa_id=?", (periodo_id, eid)).fetchone()
    if not periodo:
        raise ApiError(404, "El periodo no existe en esta empresa.")
    productos = con.execute("SELECT id, precio_venta FROM productos WHERE empresa_id=?", (eid,)).fetchall()
    if not productos:
        raise ApiError(400, "No hay productos para guardar.")
    for p in productos:
        h = hoja_costo(Ctx("GET", [], {"producto_id": p["id"], "empresa_id": eid, "periodo_id": periodo_id}, {}, None, None, ctx.lang), con)
        con.execute(
            "INSERT INTO costos_estandar (producto_id, periodo_id, costo_mp, costo_mod, costo_cif, total, precio_venta, guardado, guardado_por) "
            "VALUES (?,?,?,?,?,?,?,datetime('now','localtime'),?) "
            "ON CONFLICT(producto_id, periodo_id) DO UPDATE SET costo_mp=excluded.costo_mp, costo_mod=excluded.costo_mod, "
            "costo_cif=excluded.costo_cif, total=excluded.total, precio_venta=excluded.precio_venta, "
            "guardado=excluded.guardado, guardado_por=excluded.guardado_por",
            (p["id"], periodo_id, h["costo_mp"], h["costo_mod"], h["costo_cif"], h["total"], p["precio_venta"], ctx.user["username"]))
    auditar(con, ctx.user["username"], "guardar_historico", "costos_estandar",
            f"Costo estándar de {len(productos)} producto(s) guardado para el periodo {periodo['nombre']}")
    con.commit()
    return {"ok": True, "productos": len(productos), "periodo": periodo["nombre"]}


def consultar(ctx, con):
    eid = _empresa_id(ctx, con)
    periodos = con.execute(
        "SELECT DISTINCT pe.id, pe.nombre, pe.fecha_inicio FROM costos_estandar ce "
        "JOIN periodos pe ON pe.id = ce.periodo_id WHERE pe.empresa_id=? ORDER BY pe.fecha_inicio, pe.id", (eid,)).fetchall()
    filas = con.execute(
        "SELECT ce.*, p.codigo, p.descripcion FROM costos_estandar ce JOIN productos p ON p.id = ce.producto_id "
        "WHERE p.empresa_id=? ORDER BY p.codigo", (eid,)).fetchall()
    productos = {}
    for f in filas:
        prod = productos.setdefault(f["producto_id"], {"id": f["producto_id"], "codigo": f["codigo"], "descripcion": f["descripcion"], "periodos": {}})
        prod["periodos"][f["periodo_id"]] = {"costo_mp": f["costo_mp"], "costo_mod": f["costo_mod"], "costo_cif": f["costo_cif"],
                                               "total": f["total"], "precio_venta": f["precio_venta"], "guardado": f["guardado"]}
    orden = [pe["id"] for pe in periodos]
    for prod in productos.values():
        anterior = None
        for pid in orden:
            actual = prod["periodos"].get(pid)
            if actual:
                actual["variacion_pct"] = (round(100 * (actual["total"] - anterior) / anterior, 1) if anterior else None)
                anterior = actual["total"]
    guardados = {r["periodo_id"]: r["g"] for r in con.execute(
        "SELECT ce.periodo_id, MAX(ce.guardado) g FROM costos_estandar ce JOIN productos p ON p.id=ce.producto_id "
        "WHERE p.empresa_id=? GROUP BY ce.periodo_id", (eid,))}
    return {"periodos": [{"id": pe["id"], "nombre": pe["nombre"], "guardado": guardados.get(pe["id"])} for pe in periodos],
            "productos": list(productos.values())}


def eliminar_periodo(ctx, con, periodo_id):
    _requiere_permiso(ctx, con, "productos")
    eid = _empresa_id(ctx, con)
    per = con.execute("SELECT nombre FROM periodos WHERE id=? AND empresa_id=?", (periodo_id, eid)).fetchone()
    if not per:
        raise ApiError(404, "El periodo no existe en esta empresa.")
    con.execute("DELETE FROM costos_estandar WHERE periodo_id=?", (periodo_id,))
    auditar(con, ctx.user["username"], "eliminar", "costos_estandar", f"Histórico del periodo {per['nombre']} eliminado")
    con.commit()
    return {"ok": True}
