"""Traducción del backend. El español es el idioma "fuente": todo el código construye
los textos en español y, cuando el idioma pedido es inglés, se traducen aquí — por
diccionario exacto para los textos fijos, y con un puñado de patrones para los pocos
mensajes que llevan un valor incrustado (código, nombre de módulo, etc.).
Si un texto no está en el diccionario, se devuelve tal cual en español: degradar con
gracia es preferible a que un mensaje deje de mostrarse.
"""
import re

IDIOMAS = ("es", "en")


# Títulos de entidades y su forma en singular (usados en "Nuevo <singular>", menús, etc.)
TITULOS = {
    "Empresas": "Companies", "empresa": "company",
    "Periodos contables": "Accounting periods", "periodo": "period",
    "Unidades de medida": "Units of measure", "unidad": "unit",
    "Centros de costo": "Cost centers", "centro de costo": "cost center",
    "Productos": "Products", "producto": "product",
    "Materias primas": "Raw materials", "materia prima": "raw material",
    "Mano de obra directa": "Direct labor", "trabajador": "worker",
    "Bases de aplicación de CIF": "Overhead application bases", "base de aplicación": "application base",
    "Conceptos de CIF": "Overhead items", "concepto de CIF": "overhead item",
    "Producción": "Production",
    "Usuarios": "Users",
}

# Etiquetas de campos de formulario (entities.py y los campos ad-hoc de api.py/produccion.py)
ETIQUETAS = {
    "Código": "Code", "Nombre": "Name", "Nombre completo": "Full name",
    "Razón social": "Legal name", "NIT": "Tax ID", "Régimen tributario": "Tax regime",
    "Responsable de IVA": "VAT liable", "Actividad económica (CIIU)": "Economic activity",
    "Dirección": "Address", "Teléfono": "Phone", "Correo electrónico": "Email", "Moneda": "Currency",
    "Fecha inicial": "Start date", "Fecha final": "End date", "Estado": "Status",
    "Unidades de producción presupuestadas para el periodo": "Budgeted production units for the period",
    "Abreviatura": "Abbreviation", "Tipo": "Type",
    "Descripción": "Description", "Unidad de medida": "Unit of measure",
    "Precio de venta": "Sale price", "Horas de mano de obra estándar por unidad": "Standard labor hours per unit",
    "Horas máquina estándar por unidad": "Standard machine hours per unit",
    "Unidad de medida (compra)": "Unit of measure (purchase)", "Unidad estándar": "Standard unit",
    "Costo estándar por unidad estándar": "Standard cost per standard unit", "Proveedor": "Supplier",
    "Eficiencia (100 = sin desperdicio)": "Efficiency (100 = no waste)",
    "Cargo": "Position", "Salario mensual": "Monthly salary",
    "Prestaciones sociales (%)": "Statutory benefits (%)", "Cargas laborales (%)": "Payroll charges (%)",
    "Horas laborales por mes": "Working hours per month", "Tarifa estándar por hora (se calcula)": "Standard hourly rate (calculated)",
    "Centro de costo": "Cost center", "Comportamiento": "Behavior", "Base de aplicación": "Application base",
    "CIF presupuestado": "Budgeted overhead", "CIF real": "Actual overhead",
    "Cantidad estándar": "Standard quantity", "Cantidad planeada": "Planned quantity",
    "Cantidad producida": "Quantity produced", "Cantidad real": "Actual quantity", "Fecha": "Date",
    "Horas máquina reales": "Actual machine hours", "Horas reales": "Actual hours",
    "Monto real": "Actual amount", "Número de orden": "Order number", "Periodo contable": "Accounting period",
    "Precio real": "Actual price", "Producto": "Product", "Tarifa real": "Actual rate",
    "Unidades en proceso": "Units in process",
}

# Textos de opciones de campos "select"
OPCIONES = {
    "Régimen ordinario": "Ordinary regime", "Régimen simple": "Simplified regime", "Régimen especial": "Special regime",
    "Sí": "Yes", "No": "No",
    "Abierto": "Open", "Cerrado": "Closed",
    "Producción": "Production", "Servicio": "Service", "Administrativo": "Administrative",
    "Fijo": "Fixed", "Variable": "Variable",
    "Administrador": "Administrator", "Estudiante": "Student",
    "Activo": "Active", "Inactivo": "Inactive",
}

# Mensajes completos y fijos (coincidencia exacta)
MENSAJES = {
    "Tu rol (estudiante) solo permite consultar. Pide al administrador que haga este cambio.":
        "Your role (student) only allows viewing. Ask the administrator to make this change.",
    "Escribe tu usuario y contraseña.": "Enter your username and password.",
    "Usuario o contraseña incorrectos.": "Incorrect username or password.",
    "La contraseña actual no es correcta.": "The current password is incorrect.",
    "La contraseña nueva debe tener al menos 6 caracteres.": "The new password must be at least 6 characters long.",
    "Revisa los campos marcados.": "Check the marked fields.",
    "Ese usuario ya existe.": "That username already exists.",
    "El usuario no existe.": "The user does not exist.",
    "No puedes quitarte el rol de administrador ni desactivar tu propia cuenta.":
        "You can't remove your own administrator role or deactivate your own account.",
    "No puedes eliminar tu propia cuenta.": "You can't delete your own account.",
    "No se puede eliminar este usuario.": "This user can't be deleted.",
    "Método no permitido.": "Method not allowed.",
    "Primero selecciona una empresa (arriba a la derecha) o crea una en «Empresas».":
        "First select a company (top right) or create one in \u00abCompanies\u00bb.",
    "La empresa seleccionada ya no existe.": "The selected company no longer exists.",
    "Ese código ya existe.": "That code already exists.",
    "Recurso no encontrado.": "Resource not found.",
    "Falta el identificador del registro.": "Missing record identifier.",
    "El registro no existe o ya fue eliminado.": "The record doesn't exist or was already deleted.",
    "Esta base de aplicación es incorporada del sistema y no se puede eliminar. Puedes crear bases adicionales para tus propios criterios de prorrateo.":
        "This application base is built into the system and can't be deleted. You can create additional bases for your own allocation criteria.",
    "El código de una base incorporada no se puede cambiar.": "The code of a built-in base can't be changed.",
    "Falta indicar el producto.": "The product wasn't specified.",
    "El producto no existe en esta empresa.": "The product doesn't exist in this company.",
    "Selecciona una materia prima válida.": "Select a valid raw material.",
    "Esa materia prima ya está en la receta de este producto.": "That raw material is already in this product's recipe.",
    "Falta el identificador del renglón de la receta.": "Missing recipe line identifier.",
    "Selecciona un producto para ver su hoja de costo.": "Select a product to see its cost sheet.",
    "La empresa no existe.": "The company doesn't exist.",
    "El archivo no tiene un formato de imagen válido.": "The file isn't in a valid image format.",
    "Solo se aceptan imágenes PNG, JPG, WEBP o SVG para el logo.": "Only PNG, JPG, WEBP or SVG images are accepted for the logo.",
    "El logo es demasiado grande. Usa una imagen de menos de 250 KB.": "The logo is too large. Use an image under 250 KB.",
    "Selecciona una base de aplicación válida.": "Select a valid application base.",
    "Las horas de MOD y de máquina se cargan en «Productos», no aquí. Esta pantalla es solo para bases personalizadas.":
        "Labor and machine hours are entered in \u00abProducts\u00bb, not here. This screen is only for custom bases.",
    "Falta el identificador del renglón.": "Missing line identifier.",
    "La orden de producción no existe en esta empresa.": "The production order doesn't exist in this company.",
    "Esta orden ya está terminada y no se puede modificar. Puede consultarla en el reporte de producción.":
        "This order is already closed and can't be modified. You can review it in the production report.",
    "Selecciona un producto válido.": "Select a valid product.",
    "Selecciona un periodo válido.": "Select a valid period.",
    "Ya existe una orden con ese número.": "An order with that number already exists.",
    "Selecciona un trabajador válido.": "Select a valid worker.",
    "Selecciona un concepto de CIF válido.": "Select a valid overhead item.",
    "Ese concepto de CIF ya está registrado en esta orden.": "That overhead item is already registered on this order.",
    "Esta base se registra en otra sección de la orden (materiales, mano de obra u horas máquina).":
        "This base is recorded in another section of the order (materials, labor, or machine hours).",
    "Esa base ya está registrada en esta orden.": "That base is already registered on this order.",
    "La solicitud es demasiado grande.": "The request is too large.",
    "Los datos enviados no tienen un formato válido.": "The submitted data isn't in a valid format.",
    "Tu sesión terminó. Inicia sesión de nuevo.": "Your session has ended. Please log in again.",
    "No coincide.": "It doesn't match.",
    "Mínimo 6 caracteres.": "At least 6 characters.",
    "No existe en esta empresa.": "It doesn't exist in this company.",
    "Ya está agregada.": "It's already added.",
    "Ya existe un usuario con este nombre.": "A user with this name already exists.",
    "Es una base incorporada del sistema; puedes cambiar su nombre, pero no su código.":
        "It's a base built into the system; you can change its name, but not its code.",
    "Ya está registrada; elimínala primero si quieres cambiar el valor.": "It's already registered; delete it first if you want to change the value.",
    "Ya está registrado; elimínalo primero si quieres cambiar el monto.": "It's already registered; delete it first if you want to change the amount.",
    "El periodo no existe en esta empresa.": "The period doesn't exist in this company.",
    "Ya existe una orden con este número.": "An order with this number already exists.",
    "No se pudo generar el reporte.": "The report couldn't be generated.",
    "Ese reporte no existe.": "That report doesn't exist.",
    "No se pudo conectar con el servidor local. Verifica que el programa siga en ejecución.":
        "Couldn't connect to the local server. Check that the program is still running.",
    "La solicitud no es válida.": "The request isn't valid.",
    "Error en la base de datos. Revisa que el archivo no esté bloqueado o dañado.":
        "Database error. Check that the file isn't locked or corrupted.",
    "Ocurrió un error inesperado en el sistema.": "An unexpected system error occurred.",
}

# Patrones para los pocos mensajes que incrustan un valor dinámico (nombre de módulo, código, número)
_PATRONES = [
    (re.compile(r"^Tu usuario no tiene permiso para modificar «(?P<nombre>.+?)»\. Pide al administrador que te lo habilite en «Usuarios»\.$"),
     lambda m, lang: f"Your user doesn't have permission to modify \u00ab{TITULOS.get(m['nombre'], m['nombre'])}\u00bb. Ask the administrator to enable it for you in \u00abUsers\u00bb."),
    (re.compile(r"^Demasiados intentos fallidos\. Intenta de nuevo en (?P<seg>\d+) segundos\.$"),
     lambda m, lang: f"Too many failed attempts. Try again in {m['seg']} seconds."),
    (re.compile(r"^No se puede eliminar este registro de «(?P<titulo>.+?)» porque otros datos dependen de él\. Elimina o cambia primero esos datos\.$"),
     lambda m, lang: f"This record from \u00ab{TITULOS.get(m['titulo'], m['titulo'])}\u00bb can't be deleted because other data depends on it. Remove or change that data first."),
    (re.compile(r"^Ya existe un registro con el código «(?P<codigo>.+?)»\. Usa otro\.$"),
     lambda m, lang: f"A record with the code \u00ab{m['codigo']}\u00bb already exists. Use a different one."),
]


def tr_etiqueta(texto, lang):
    """Traduce una etiqueta de campo, título de entidad o singular."""
    if lang != "en" or not texto:
        return texto
    return TITULOS.get(texto) or ETIQUETAS.get(texto, texto)


def tr_opcion(texto, lang):
    if lang != "en" or not texto:
        return texto
    return OPCIONES.get(texto, texto)


def tr_mensaje(texto, lang):
    """Traduce un mensaje de error o de campo, ya sea fijo o con un valor incrustado."""
    if lang != "en" or not texto:
        return texto
    if texto in MENSAJES:
        return MENSAJES[texto]
    for patron, plantilla in _PATRONES:
        m = patron.match(texto)
        if m:
            return plantilla(m, lang)
    return texto


def lang_de(headers):
    """Extrae el idioma pedido (es/en) del encabezado X-Lang; 'es' por defecto."""
    valor = (headers.get("X-Lang") or "es").strip().lower()
    return valor if valor in IDIOMAS else "es"
