"""Inventario de materias primas: entradas (compras), salidas, existencias y costo promedio ponderado."""
import datetime

from .api import ApiError, auditar, _fila, _empresa_id, _requiere_permiso
from .validators import validar_campo

EPS = 1e-9


def _movimientos(con, mp_id):
    return con.execute(
        "SELECT * FROM movimientos_inventario WHERE materia_prima_id=? ORDER BY fecha, id", (mp_id,)).fetchall()


def _kardex(movs):
    """Recorre los movimientos en orden y devuelve (lista con saldos, existencias, costo promedio).

    Costo promedio ponderado móvil: cada entrada recalcula el promedio; las salidas
    descuentan existencias al costo promedio vigente y no lo modifican.
    """
    existencias, promedio, filas = 0.0, 0.0, []
    for m in movs:
        if m["tipo"] == "entrada":
            total = existencias + m["cantidad"]
            promedio = ((existencias * promedio) + (m["cantidad"] * m["costo_unitario"])) / total if total > EPS else m["costo_unitario"]
            existencias = total
        else:
            existencias -= m["cantidad"]
        filas.append({**_fila(m), "saldo": round(existencias, 4), "costo_promedio": round(promedio, 4)})
    return filas, existencias, promedio


def costo_promedio_actual(con, mp_id):
    """Costo promedio vigente de una materia prima (None si no tiene movimientos)."""
    movs = _movimientos(con, mp_id)
    if not movs:
        return None
    _, _, promedio = _kardex(movs)
    return promedio


def registrar_salida_por_orden(con, empresa_id, orden, consumos):
    """Descuenta del inventario lo consumido en una orden, solo para materias primas que ya llevan movimientos."""
    for c in consumos:
        movs = _movimientos(con, c["materia_prima_id"])
        if not movs:
            continue  # la empresa no lleva inventario de este material
        _, _, promedio = _kardex(movs)
        con.execute(
            "INSERT INTO movimientos_inventario (empresa_id, materia_prima_id, fecha, tipo, cantidad, costo_unitario, orden_id, nota) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (empresa_id, c["materia_prima_id"], orden["fecha"], "salida", c["cantidad_real"], round(promedio, 4), orden["id"],
             f"Consumo de la orden {orden['numero']}"))


def existencias(ctx, con):
    eid = _empresa_id(ctx, con)
    materiales = con.execute("SELECT * FROM materias_primas WHERE empresa_id=? ORDER BY codigo", (eid,)).fetchall()
    salida, valor_total = [], 0.0
    for m in materiales:
        _, exist, prom = _kardex(_movimientos(con, m["id"]))
        valor = round(max(exist, 0) * prom, 2)
        valor_total += valor
        estado = "negativo" if exist < -EPS else ("bajo" if m["stock_minimo"] and exist <= m["stock_minimo"] + EPS else "ok")
        tiene = con.execute("SELECT 1 FROM movimientos_inventario WHERE materia_prima_id=? LIMIT 1", (m["id"],)).fetchone() is not None
        salida.append({"id": m["id"], "codigo": m["codigo"], "descripcion": m["descripcion"],
                       "existencias": round(exist, 4), "costo_promedio": round(prom, 4), "costo_estandar": m["costo_estandar"],
                       "valor": valor, "stock_minimo": m["stock_minimo"], "estado": estado if tiene or m["stock_minimo"] else "sin_datos",
                       "con_movimientos": tiene})
    return {"materiales": salida, "valor_total": round(valor_total, 2)}


def kardex(ctx, con, mp_id):
    eid = _empresa_id(ctx, con)
    mp = con.execute("SELECT * FROM materias_primas WHERE id=? AND empresa_id=?", (mp_id, eid)).fetchone()
    if not mp:
        raise ApiError(404, "La materia prima no existe en esta empresa.")
    filas, exist, prom = _kardex(_movimientos(con, mp_id))
    return {"materia": {"codigo": mp["codigo"], "descripcion": mp["descripcion"]},
            "existencias": round(exist, 4), "costo_promedio": round(prom, 4), "movimientos": list(reversed(filas))}


def registrar_movimiento(ctx, con):
    _requiere_permiso(ctx, con, "inventario")
    eid = _empresa_id(ctx, con)
    b = ctx.body
    tipo = b.get("tipo")
    if tipo not in ("entrada", "salida"):
        raise ApiError(400, "Elige si es una entrada o una salida.", {"tipo": "Elige entrada o salida."})
    mp = con.execute("SELECT * FROM materias_primas WHERE id=? AND empresa_id=?", (b.get("materia_prima_id"), eid)).fetchone()
    if not mp:
        raise ApiError(400, "Selecciona una materia prima válida.", {"materia_prima_id": "Selecciona una materia prima."})
    cant, e1 = validar_campo({"label": "Cantidad", "tipo": "number", "req": True, "positivo": True}, b.get("cantidad"))
    fecha, e2 = validar_campo({"label": "Fecha", "tipo": "date", "req": True}, b.get("fecha") or datetime.date.today().isoformat())
    costo, e3 = 0.0, None
    if tipo == "entrada":
        costo, e3 = validar_campo({"label": "Costo unitario", "tipo": "number", "req": True, "positivo": True}, b.get("costo_unitario"))
    errores = {k: v for k, v in (("cantidad", e1), ("fecha", e2), ("costo_unitario", e3)) if v}
    if errores:
        raise ApiError(400, "Revisa los campos marcados.", errores)
    movs = _movimientos(con, mp["id"])
    _, exist, prom = _kardex(movs)
    if tipo == "salida":
        if cant > exist + EPS:
            raise ApiError(400, f"No hay suficientes existencias: quedan {round(exist, 4)} y quieres sacar {cant}.",
                           {"cantidad": f"Solo hay {round(exist, 4)} disponibles."})
        costo = round(prom, 4)
    nota = str(b.get("nota") or "").strip()[:200]
    cur = con.execute(
        "INSERT INTO movimientos_inventario (empresa_id, materia_prima_id, fecha, tipo, cantidad, costo_unitario, nota) VALUES (?,?,?,?,?,?,?)",
        (eid, mp["id"], fecha, tipo, cant, costo, nota))
    auditar(con, ctx.user["username"], "crear", "movimientos_inventario", f"{tipo} de {cant} de {mp['codigo']}")
    con.commit()
    return {"id": cur.lastrowid}


def eliminar_movimiento(ctx, con, mid):
    _requiere_permiso(ctx, con, "inventario")
    eid = _empresa_id(ctx, con)
    m = con.execute("SELECT * FROM movimientos_inventario WHERE id=? AND empresa_id=?", (mid, eid)).fetchone()
    if not m:
        raise ApiError(404, "El movimiento no existe.")
    if m["orden_id"]:
        raise ApiError(400, "Este movimiento lo generó el cierre de una orden de producción y no se puede borrar desde aquí.")
    # Al quitar el movimiento, el inventario no puede quedar en negativo por eso.
    con.execute("DELETE FROM movimientos_inventario WHERE id=?", (mid,))
    _, exist, _ = _kardex(_movimientos(con, m["materia_prima_id"]))
    if exist < -EPS:
        con.rollback()
        raise ApiError(400, "No se puede eliminar: dejaría las existencias en negativo porque hay salidas posteriores que dependen de esta entrada.")
    auditar(con, ctx.user["username"], "eliminar", "movimientos_inventario", f"Movimiento {mid}")
    con.commit()
    return {"ok": True}
