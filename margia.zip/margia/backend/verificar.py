"""Autoverificación: `Margia.exe --verificar`.

Comprueba, en el mismo equipo donde se ejecuta, que el programa empaquetado tiene todo lo que
necesita. La usa el script de construcción justo después de generar el .exe. Solo imprime ASCII
para que funcione aunque la salida de la consola de Windows se redirija con otra codificación.
"""
import io
import os
import sys
import tempfile


def main():
    from . import settings
    resultados = []

    def paso(nombre, funcion):
        try:
            detalle = funcion() or ""
            resultados.append(True)
            print(f"  [OK]    {nombre} {detalle}".rstrip())
        except Exception as e:  # noqa: BLE001 — se informa cualquier fallo
            resultados.append(False)
            print(f"  [FALLA] {nombre}: {type(e).__name__}: {e}")

    from .version import __version__
    print(f"Verificando Margia {__version__}...")
    print(f"  Programa en: {settings.APP_DIR}")
    print(f"  Recursos en: {settings.RES_DIR}")

    def interfaz():
        for f in ("index.html", "css/estilos.css", "js/app.js", "js/modulos/historico.js"):
            if not os.path.isfile(settings.resource("frontend", *f.split("/"))):
                raise FileNotFoundError(f"falta frontend/{f}")
    paso("Interfaz (HTML, CSS y JavaScript)", interfaz)

    def esquema():
        if not os.path.isfile(settings.resource("backend", "db", "schema.sql")):
            raise FileNotFoundError("falta backend/db/schema.sql")
    paso("Esquema de la base de datos", esquema)

    paso("Archivo de configuracion", lambda: "(config/config.ini)" if os.path.isfile(os.path.join(settings.APP_DIR, "config", "config.ini"))
         else "(no se encontro config/config.ini: se usaran valores por defecto)")

    def carpeta_datos():
        prueba = os.path.join(settings.DATA_BASE, "data", ".verificacion")
        os.makedirs(os.path.dirname(prueba), exist_ok=True)
        with open(prueba, "w") as f:
            f.write("ok")
        os.remove(prueba)
        return f"({os.path.join(settings.DATA_BASE, 'data')})"
    paso("Permiso para guardar datos", carpeta_datos)

    def base_datos():
        from .db import database
        temporal = os.path.join(tempfile.mkdtemp(), "verificacion.db")
        original = database.db_path
        database.db_path = lambda: temporal
        try:
            database.init()
            con = database.connect()
            n = con.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]
            tablas = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
            con.close()
            return f"({tablas} tablas, {n} usuarios iniciales)"
        finally:
            database.db_path = original
    paso("Crear base de datos de prueba", base_datos)

    def copias():
        from . import respaldos
        from .db import database
        carpeta = tempfile.mkdtemp()
        origen = os.path.join(carpeta, "a.db")
        original = database.db_path
        database.db_path = lambda: origen
        try:
            database.init()
            destino = os.path.join(carpeta, "b.db")
            respaldos.copia_consistente(origen, destino)
            import sqlite3
            c = sqlite3.connect(destino)
            ok = c.execute("PRAGMA integrity_check").fetchone()[0]
            c.close()
            if ok != "ok":
                raise ValueError("la copia no es integra")
            return "(respaldos automaticos)"
        finally:
            database.db_path = original
    paso("Copias de respaldo", copias)

    def excel():
        import openpyxl
        wb = openpyxl.Workbook()
        wb.active.append(["Prueba", 1.5])
        buf = io.BytesIO()
        wb.save(buf)
        openpyxl.load_workbook(io.BytesIO(buf.getvalue()))
        return f"(openpyxl {openpyxl.__version__})"
    paso("Reportes e importacion en Excel", excel)

    def pdf():
        import reportlab
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Table
        from reportlab.lib.styles import ParagraphStyle
        buf = io.BytesIO()
        SimpleDocTemplate(buf, pagesize=A4).build([Paragraph("Prueba ñ á", ParagraphStyle("p")), Table([["a", "b"]])])
        if not buf.getvalue().startswith(b"%PDF-"):
            raise ValueError("el PDF generado no es valido")
        return f"(reportlab {reportlab.Version})"
    paso("Reportes en PDF", pdf)

    def logo():
        from PIL import Image
        img = Image.new("RGBA", (4, 4), (31, 122, 92, 255))
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return "(Pillow)"
    paso("Logo en los PDF", logo)

    bien = all(resultados)
    print("")
    print("RESULTADO: todo listo." if bien else "RESULTADO: hay fallas. Revise los puntos marcados con [FALLA].")
    return 0 if bien else 1


if __name__ == "__main__":
    sys.exit(main())
