"""Contraseñas con hash, sesiones con token y bloqueo por intentos fallidos."""
import hashlib
import hmac
import os
import secrets
import threading
import time

from . import settings

_ITER = 200_000
_lock = threading.Lock()
_sessions = {}   # token -> {"user": {...}, "expira": epoch}
_fallos = {}     # username -> {"n": int, "hasta": epoch}


def hash_password(password, salt_hex=None):
    salt = bytes.fromhex(salt_hex) if salt_hex else os.urandom(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _ITER)
    return h.hex(), salt.hex()


def verify_password(password, hash_hex, salt_hex):
    calc, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(calc, hash_hex)


def create_session(user):
    token = secrets.token_urlsafe(32)
    minutos = settings.get_int("aplicacion", "sesion_minutos", 120)
    with _lock:
        _sessions[token] = {"user": user, "expira": time.time() + minutos * 60}
    return token


def get_session(token):
    if not token:
        return None
    with _lock:
        s = _sessions.get(token)
        if not s:
            return None
        if s["expira"] < time.time():
            _sessions.pop(token, None)
            return None
        # sesión deslizante
        s["expira"] = time.time() + settings.get_int("aplicacion", "sesion_minutos", 120) * 60
        return s["user"]


def destroy_session(token):
    with _lock:
        _sessions.pop(token, None)


def destroy_user_sessions(user_id):
    with _lock:
        for t in [t for t, s in _sessions.items() if s["user"]["id"] == user_id]:
            _sessions.pop(t, None)


def login_bloqueado(username):
    """Devuelve los segundos restantes de bloqueo (0 si no está bloqueado)."""
    with _lock:
        f = _fallos.get(username.lower())
        if f and f["hasta"] > time.time():
            return int(f["hasta"] - time.time()) + 1
    return 0


def registrar_fallo(username):
    maximo = settings.get_int("aplicacion", "intentos_login_max", 5)
    espera = settings.get_int("aplicacion", "bloqueo_segundos", 60)
    with _lock:
        f = _fallos.setdefault(username.lower(), {"n": 0, "hasta": 0})
        f["n"] += 1
        if f["n"] >= maximo:
            f["n"] = 0
            f["hasta"] = time.time() + espera


def limpiar_fallos(username):
    with _lock:
        _fallos.pop(username.lower(), None)
