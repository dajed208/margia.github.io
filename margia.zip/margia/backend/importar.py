"""Importación y exportación en Excel (.xlsx).

- Catálogos (empresas, periodos, unidades, centros de costo, productos, materias primas,
  mano de obra, bases de aplicación y CIF): una hoja con las mismas columnas del formulario.
- Recetas (hoja de costo estándar): producto, materia prima y cantidad estándar.
- Órdenes de producción: hojas «Órdenes», «Consumo de materiales», «Mano de obra» y «CIF real».

La exportación usa exactamente el formato de la importación, así que un archivo exportado se
puede corregir en Excel y volver a importar marcando «actualizar». Importar es un proceso en dos
pasos: `revisar` (vista previa, no guarda) y `confirmar`. Las filas de catálogos pasan por
`api._limpiar`, la misma validación del formulario de la pantalla.
"""
import base64
import datetime
import io
import unicodedata
import warnings

from .api import ApiError, _limpiar, _requiere_permiso, _empresa_id, auditar
from .entities import ENTIDADES
from .validators import validar_campo

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.worksheet.datavalidation import DataValidation
    _TIENE_OPENPYXL = True
except ImportError:
    _TIENE_OPENPYXL = False

GENERICAS = ("empresas", "periodos", "unidades_medida", "centros_costo", "productos", "materias_primas",
             "trabajadores", "bases_aplicacion", "cif_conceptos")
ESPECIALES = {"recetas": "Recetas (hoja de costo estándar)", "ordenes": "Órdenes de producción"}
PERMISO_ESPECIAL = {"recetas": "productos", "ordenes": "ordenes"}
MAX_FILAS = 5000

EJEMPLOS = {
    "empresas": {"codigo": "EMP01", "razon_social": "Mi Empresa S.A.S.", "nit": "900123456-7", "regimen": "comun",
                 "responsable_iva": "si", "actividad_economica": "1011", "direccion": "Calle 1 # 2-3",
                 "telefono": "3001234567", "email": "contacto@miempresa.com", "moneda": "COP"},
    "periodos": {"codigo": "2026", "nombre": "Año 2026", "fecha_inicio": "2026-01-01",
                 "fecha_fin": "2026-12-31", "estado": "abierto", "unidades_presupuestadas": 2000},
    "unidades_medida": {"codigo": "CAJA", "nombre": "Caja", "abreviatura": "cj"},
    "centros_costo": {"codigo": "CC01", "nombre": "Planta de producción", "tipo": "produccion"},
    "productos": {"codigo": "P01", "descripcion": "Pincho de pollo", "precio_venta": 6500, "horas_mod_std": 0.05, "horas_maquina_std": 0.01},
    "materias_primas": {"codigo": "MP01", "descripcion": "Pechuga de pollo", "costo_estandar": 14000, "proveedor": "Proveedor S.A.S.",
                        "stock_minimo": 10, "eficiencia_pct": 95},
    "trabajadores": {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Operaria", "salario_mensual": 1423500,
                     "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192},
    "bases_aplicacion": {"codigo": "KILOS", "nombre": "Kilos procesados"},
    "cif_conceptos": {"codigo": "CIF01", "descripcion": "Energía eléctrica", "tipo": "variable", "presupuestado": 600000, "real": 0},
}
NOMBRE_ARCHIVO = {"unidades_medida": "unidades_de_medida", "centros_costo": "centros_de_costo", "trabajadores": "mano_de_obra",
                  "cif_conceptos": "conceptos_cif", "bases_aplicacion": "bases_de_aplicacion", "ordenes": "ordenes_de_produccion"}
TITULO_LISTA = {"unidades_medida": "Unidades", "centros_costo": "Centros de costo", "bases_aplicacion": "Bases de aplicación",
                "productos": "Productos", "materias_primas": "Materias primas", "periodos": "Periodos",
                "trabajadores": "Trabajadores", "cif_conceptos": "Conceptos de CIF"}


# ---- utilidades --------------------------------------------------------------
def _norm(texto):
    """Minúsculas, sin tildes, sin «*» ni espacios extra: «Código *» y «codigo» coinciden."""
    t = unicodedata.normalize("NFKD", str(texto or "")).encode("ascii", "ignore").decode()
    return " ".join(t.lower().replace("*", "").split())


def _requiere_libreria():
    if not _TIENE_OPENPYXL:
        raise ApiError(500, "Falta la librería openpyxl para leer y crear archivos de Excel. Instálela con: python -m pip install -r requirements.txt")


def _validar_modulo(ent):
    if ent not in GENERICAS and ent not in ESPECIALES:
        raise ApiError(404, "Ese módulo no se puede importar ni exportar.")


def titulo_de(ent):
    return ENTIDADES[ent]["titulo"] if ent in ENTIDADES else ESPECIALES[ent]


def _eid(ctx, con, ent):
    """Empresa activa, salvo para los catálogos que no dependen de una empresa (empresas y unidades)."""
    if ent in ENTIDADES and not ENTIDADES[ent]["scoped"]:
        return None
    return _empresa_id(ctx, con)


def _color(ctx, con):
    try:
        from .reportes import _color_empresa
        return _color_empresa(ctx, con)
    except Exception:  # sin empresa activa (por ejemplo al importar la primera empresa)
        return "0F766E"


def _campos(ent):
    return [c for c in ENTIDADES[ent]["campos"] if not c.get("calculado")]


def _filas_tabla(con, tabla, eid):
    scoped = ENTIDADES.get(tabla, {}).get("scoped", True)
    sql = f"SELECT * FROM {tabla}" + (" WHERE empresa_id=?" if scoped else "") + " ORDER BY codigo"
    return [dict(f) for f in con.execute(sql, (eid,) if scoped else ())]


def _nombre_fila(f):
    return f.get("descripcion") or f.get("nombre") or f.get("razon_social") or f.get("abreviatura") or ""


def _buscar(filas, valor):
    """Encuentra un registro por código, nombre, descripción o abreviatura."""
    clave = _norm(valor)
    if not clave:
        return None
    for f in filas:
        for k in ("codigo", "nombre", "descripcion", "abreviatura"):
            if f.get(k) is not None and _norm(f[k]) == clave:
                return f
    return None


def _a_texto(valor):
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))  # Excel convierte el código 101 en 101.0
    if isinstance(valor, (datetime.datetime, datetime.date)):
        return valor.strftime("%Y-%m-%d")
    return str(valor).strip()


def _a_fecha(valor):
    if isinstance(valor, datetime.datetime):
        return valor.date().isoformat()
    if isinstance(valor, datetime.date):
        return valor.isoformat()
    return valor


def _vacio(valor):
    return valor is None or (isinstance(valor, str) and not valor.strip())


# ---- construcción de libros --------------------------------------------------
def _hoja_datos(wb, titulo, columnas, filas, color, listas=None, opciones=None, primera=False):
    """columnas: [(etiqueta, obligatoria)]. listas: {índice: (hoja, n)}. opciones: {índice: [textos]}."""
    ws = wb.active if primera else wb.create_sheet()
    ws.title = titulo[:31]
    ws.append([e + (" *" if req else "") for e, req in columnas])
    for celda in ws[1]:
        celda.font = Font(bold=True, color="FFFFFF")
        celda.fill = PatternFill("solid", fgColor=color)
        celda.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 22
    for fila in filas:
        ws.append(fila)
    for i, (etiqueta, _) in enumerate(columnas):
        letra = ws.cell(row=1, column=i + 1).column_letter
        largo = max([len(etiqueta)] + [len(_a_texto(f[i])) for f in filas if i < len(f) and f[i] is not None])
        ws.column_dimensions[letra].width = min(max(largo + 4, 12), 46)
        for celda in ws[letra][1:]:
            if isinstance(celda.value, (datetime.date, datetime.datetime)):
                celda.number_format = "yyyy-mm-dd"
        rango = f"{letra}2:{letra}{MAX_FILAS + 1}"
        if listas and i in listas and listas[i][1]:
            hoja, n = listas[i]
            dv = DataValidation(type="list", formula1=f"='{hoja}'!$A$2:$A${n + 1}", allow_blank=True)
            ws.add_data_validation(dv)
            dv.add(rango)
        elif opciones and i in opciones:
            dv = DataValidation(type="list", formula1='"' + ",".join(opciones[i]) + '"', allow_blank=True)
            ws.add_data_validation(dv)
            dv.add(rango)
    ws.freeze_panes = "A2"
    return ws


def _hoja_lista(wb, titulo, filas):
    """Hoja de consulta con los códigos válidos (alimenta las listas desplegables)."""
    if titulo[:31] in wb.sheetnames:
        return
    ws = wb.create_sheet(titulo[:31])
    ws.append(["Código", "Nombre"])
    for celda in ws[1]:
        celda.font = Font(bold=True)
    for codigo, nombre in filas:
        ws.append([codigo, nombre])
    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 42


def _hoja_instrucciones(wb, titulo, lineas):
    ws = wb.create_sheet("Instrucciones")
    ws.column_dimensions["A"].width = 115
    ws.append([titulo])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([""])
    for texto in lineas:
        ws.append([texto])


def _bytes(wb):
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


INSTRUCCIONES_COMUNES = [
    "• Las columnas marcadas con * son obligatorias. No cambie los títulos de la primera fila.",
    "• Los números van sin símbolo de moneda ni separador de miles (ejemplo: 14000 o 0.05).",
    "• Las fechas van como fecha de Excel o con el formato año-mes-día (ejemplo: 2026-01-31).",
    "• Donde se pide un código de otro dato (unidad, producto, periodo…), use la lista desplegable o las hojas de consulta de este archivo.",
    "• Si un código ya existe, el sistema le avisará. Marque «actualizar» al importar para reemplazar esos registros con los datos del archivo.",
    "• Un archivo exportado desde el sistema tiene este mismo formato: puede corregirlo aquí y volver a importarlo.",
]


def _libro_generico(ctx, con, ent, exportar):
    spec = ENTIDADES[ent]
    eid = _eid(ctx, con, ent)
    campos = _campos(ent)
    refs = {c["name"]: _filas_tabla(con, c["ref"], eid) for c in campos if c["tipo"] == "ref"}
    por_id = {k: {f["id"]: f for f in v} for k, v in refs.items()}

    def celda(c, v):
        if v is None:
            return None
        if c["tipo"] == "ref":
            f = por_id[c["name"]].get(v)
            return f["codigo"] if f else None
        if c["tipo"] == "select":
            return next((o["texto"] for o in c["opciones"] if o["valor"] == v), v)
        if c["tipo"] == "date":
            try:
                return datetime.date.fromisoformat(str(v))
            except ValueError:
                return v
        return v

    if exportar:
        registros = _filas_tabla(con, ent, eid)
    else:
        ej = dict(EJEMPLOS.get(ent, {}))
        for c in campos:
            if c["tipo"] == "ref" and c["name"] not in ej and refs[c["name"]] and c.get("req"):
                primero = next((f for f in refs[c["name"]] if f.get("codigo") in ("UND", "KG", "mano_obra_directa")), refs[c["name"]][0])
                ej[c["name"]] = primero["id"]
        registros = [ej]
    filas = [[celda(c, r.get(c["name"], c.get("defecto"))) for c in campos] for r in registros]

    wb = openpyxl.Workbook()
    listas, opciones = {}, {}
    for i, c in enumerate(campos):
        if c["tipo"] == "ref":
            listas[i] = (TITULO_LISTA.get(c["ref"], c["ref"]), len(refs[c["name"]]))
        elif c["tipo"] == "select":
            opciones[i] = [o["texto"] for o in c["opciones"]]
    _hoja_datos(wb, spec["titulo"], [(c["label"], c.get("req")) for c in campos], filas, _color(ctx, con), listas, opciones, primera=True)
    lineas = list(INSTRUCCIONES_COMUNES)
    for c in campos:
        if c["tipo"] == "select":
            lineas.append(f"• Valores válidos para «{c['label']}»: " + ", ".join(o["texto"] for o in c["opciones"]) + ".")
    _hoja_instrucciones(wb, f"{'Datos exportados' if exportar else 'Plantilla de importación'} — {spec['titulo']}", lineas)
    for c in campos:
        if c["tipo"] == "ref":
            _hoja_lista(wb, TITULO_LISTA.get(c["ref"], c["ref"]), [(f["codigo"], _nombre_fila(f)) for f in refs[c["name"]]])
    return wb


# ---- recetas -----------------------------------------------------------------
COLS_RECETA = [("Código del producto", True), ("Código de materia prima", True), ("Cantidad estándar por unidad", True)]


def _libro_recetas(ctx, con, exportar):
    eid = _empresa_id(ctx, con)
    productos, materias = _filas_tabla(con, "productos", eid), _filas_tabla(con, "materias_primas", eid)
    if exportar:
        filas = [[r["pc"], r["mc"], r["cantidad_estandar"]] for r in con.execute(
            "SELECT p.codigo pc, m.codigo mc, r.cantidad_estandar FROM receta_producto r JOIN productos p ON p.id=r.producto_id "
            "JOIN materias_primas m ON m.id=r.materia_prima_id WHERE p.empresa_id=? ORDER BY p.codigo, m.codigo", (eid,))]
    else:
        filas = [[productos[0]["codigo"] if productos else "P01", materias[0]["codigo"] if materias else "MP01", 0.12]]
    wb = openpyxl.Workbook()
    _hoja_datos(wb, "Recetas", COLS_RECETA, filas, _color(ctx, con),
                listas={0: ("Productos", len(productos)), 1: ("Materias primas", len(materias))}, primera=True)
    _hoja_instrucciones(wb, f"{'Recetas exportadas' if exportar else 'Plantilla de recetas'} — hoja de costo estándar", [
        "• Una fila por cada materia prima de cada producto: cuánto lleva una unidad del producto (en la unidad estándar del material).",
        "• El producto y la materia prima deben existir antes en el sistema (impórtelos primero si hace falta).",
        "• Las horas de mano de obra y de máquina de cada producto se cargan en la plantilla de Productos, no aquí.",
    ] + INSTRUCCIONES_COMUNES)
    _hoja_lista(wb, "Productos", [(f["codigo"], f["descripcion"]) for f in productos])
    _hoja_lista(wb, "Materias primas", [(f["codigo"], f["descripcion"]) for f in materias])
    return wb


# ---- órdenes de producción ---------------------------------------------------
HOJAS_ORDENES = [
    ("Órdenes", [("Número de orden", True), ("Código del producto", True), ("Código del periodo", True), ("Fecha", True), ("Cantidad planeada", True)]),
    ("Consumo de materiales", [("Número de orden", True), ("Código de materia prima", True), ("Cantidad real", True), ("Precio real", True)]),
    ("Mano de obra", [("Número de orden", True), ("Código del trabajador", True), ("Horas reales", True), ("Tarifa real", True)]),
    ("CIF real", [("Número de orden", True), ("Código del concepto de CIF", True), ("Monto real", True)]),
]
INFO_ORDEN = [("Estado (informativo)", False), ("Cantidad producida (informativo)", False)]
CONSULTAS_DETALLE = {
    "Consumo de materiales": "SELECT o.numero, m.codigo, d.cantidad_real, d.precio_real FROM consumo_mp d "
                             "JOIN materias_primas m ON m.id=d.materia_prima_id",
    "Mano de obra": "SELECT o.numero, t.codigo, d.horas_reales, d.tarifa_real FROM horas_mod d JOIN trabajadores t ON t.id=d.trabajador_id",
    "CIF real": "SELECT o.numero, k.codigo, d.monto_real FROM cif_real_orden d JOIN cif_conceptos k ON k.id=d.concepto_id",
}


def _libro_ordenes(ctx, con, exportar):
    eid = _empresa_id(ctx, con)
    t = {k: _filas_tabla(con, k, eid) for k in ("productos", "periodos", "materias_primas", "trabajadores", "cif_conceptos")}
    datos = {h: [] for h, _ in HOJAS_ORDENES}
    if exportar:
        for o in con.execute(
                "SELECT o.*, p.codigo pc, pe.codigo pec FROM ordenes_produccion o JOIN productos p ON p.id=o.producto_id "
                "JOIN periodos pe ON pe.id=o.periodo_id WHERE o.empresa_id=? ORDER BY o.fecha, o.numero", (eid,)):
            datos["Órdenes"].append([o["numero"], o["pc"], o["pec"], datetime.date.fromisoformat(o["fecha"]), o["cantidad_planeada"],
                                     "Terminada" if o["estado"] == "terminada" else "Abierta", o["cantidad_producida"]])
        for hoja, sql in CONSULTAS_DETALLE.items():
            sql += " JOIN ordenes_produccion o ON o.id=d.orden_id WHERE o.empresa_id=? ORDER BY o.fecha, o.numero, d.id"
            datos[hoja] = [list(f) for f in con.execute(sql, (eid,))]
    else:
        prim = {k: (v[0]["codigo"] if v else "") for k, v in t.items()}
        datos["Órdenes"] = [["OP-001", prim["productos"] or "P01", prim["periodos"] or "2026", datetime.date.today(), 200]]
        datos["Consumo de materiales"] = [["OP-001", prim["materias_primas"] or "MP01", 25.5, 14200]]
        datos["Mano de obra"] = [["OP-001", prim["trabajadores"] or "T01", 11, 11500]]
        datos["CIF real"] = [["OP-001", prim["cif_conceptos"] or "CIF01", 70000]]
    wb = openpyxl.Workbook()
    color = _color(ctx, con)
    listas = {
        "Órdenes": {1: ("Productos", len(t["productos"])), 2: ("Periodos", len(t["periodos"]))},
        "Consumo de materiales": {1: ("Materias primas", len(t["materias_primas"]))},
        "Mano de obra": {1: ("Trabajadores", len(t["trabajadores"]))},
        "CIF real": {1: ("Conceptos de CIF", len(t["cif_conceptos"]))},
    }
    for n, (hoja, cols) in enumerate(HOJAS_ORDENES):
        _hoja_datos(wb, hoja, cols + (INFO_ORDEN if hoja == "Órdenes" and exportar else []), datos[hoja], color, listas[hoja], primera=(n == 0))
    _hoja_instrucciones(wb, "Órdenes exportadas" if exportar else "Plantilla de órdenes de producción", [
        "• Hoja «Órdenes»: una fila por orden. Las demás hojas se enlazan con la orden por su número.",
        "• Hojas «Consumo de materiales», «Mano de obra» y «CIF real»: lo que realmente se usó en cada orden. Puede dejarlas vacías.",
        "• Sin «actualizar» solo se crean órdenes nuevas. Con «actualizar», una orden abierta que ya exista se actualiza,",
        "  y sus consumos, horas o CIF real se reemplazan por los del archivo (solo en las hojas donde el archivo trae filas de esa orden).",
        "• Las órdenes cerradas no se modifican desde un archivo: sus costos reales y variaciones ya quedaron calculados.",
        "  El cierre de las órdenes se hace en la pantalla «Órdenes de producción».",
        "• Las columnas «(informativo)» de un archivo exportado no se leen al importar.",
    ] + INSTRUCCIONES_COMUNES)
    for k in ("productos", "periodos", "materias_primas", "trabajadores", "cif_conceptos"):
        _hoja_lista(wb, TITULO_LISTA[k], [(f["codigo"], _nombre_fila(f)) for f in t[k]])
    return wb


def _libro(ctx, con, ent, exportar):
    if ent == "recetas":
        return _libro_recetas(ctx, con, exportar)
    if ent == "ordenes":
        return _libro_ordenes(ctx, con, exportar)
    return _libro_generico(ctx, con, ent, exportar)


# ---- API pública: plantilla y exportación ------------------------------------
def plantilla(ctx, con, ent):
    _requiere_libreria()
    _validar_modulo(ent)
    return f"plantilla_{NOMBRE_ARCHIVO.get(ent, ent)}.xlsx", _bytes(_libro(ctx, con, ent, False))


def exportar(ctx, con, ent):
    _requiere_libreria()
    _validar_modulo(ent)
    data = _bytes(_libro(ctx, con, ent, True))
    auditar(con, ctx.user["username"], "exportar", ent, f"Exportó {titulo_de(ent)} a Excel")
    con.commit()
    return f"{NOMBRE_ARCHIVO.get(ent, ent)}_{datetime.date.today().isoformat()}.xlsx", data


# ---- lectura -----------------------------------------------------------------
def _leer_libro(b64):
    # openpyxl avisa (UserWarning) de partes del archivo que no usa; la más común: las listas desplegables que Excel guarda
    # en formato extendido cuando se vuelve a guardar una plantilla. Aquí solo se leen valores, así que no se pierde nada
    # y el aviso solo parecería una falla en la consola de quien usa el programa.
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=UserWarning, module=r"openpyxl(\..*)?")
            data = base64.b64decode(str(b64).split(",", 1)[-1], validate=False)
            wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
            hojas = {ws.title: [f for f in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
            wb.close()
    except Exception:
        raise ApiError(400, "No se pudo leer el archivo. Asegúrese de que sea un Excel (.xlsx), que no esté dañado y que no esté protegido con contraseña.")
    return hojas


def _hoja(hojas, nombre, primera_si_falta=False):
    for titulo, filas in hojas.items():
        if _norm(titulo) == _norm(nombre):
            return filas
    return next(iter(hojas.values())) if primera_si_falta and hojas else None


def _mapear(encabezados, columnas):
    """columnas: [(clave, [nombres aceptados], obligatoria, etiqueta)] -> ({clave: índice}, [faltantes])."""
    norm = [_norm(h) for h in (encabezados or [])]
    mapa, faltan = {}, []
    for clave, nombres, req, etiqueta in columnas:
        aceptados = {_norm(n) for n in nombres}
        idx = next((i for i, h in enumerate(norm) if h in aceptados), None)
        if idx is None:
            if req:
                faltan.append(etiqueta)
        else:
            mapa[clave] = idx
    return mapa, faltan


def _filas_con_datos(filas):
    datos = [(n, f) for n, f in enumerate(filas[1:], start=2) if f and any(not _vacio(v) for v in f)]
    if len(datos) > MAX_FILAS:
        raise ApiError(400, f"El archivo tiene {len(datos)} filas; el máximo por importación es {MAX_FILAS}.")
    return datos


def _valor(fila, mapa, clave):
    i = mapa.get(clave)
    return fila[i] if i is not None and i < len(fila) else None


def _numero(etiqueta, valor):
    return validar_campo({"label": etiqueta, "tipo": "number", "req": True, "positivo": True}, valor)


def _resultado(filas):
    publico = [{k: r.get(k) for k in ("hoja", "fila", "codigo", "nombre", "accion", "errores")} for r in filas]
    return {"filas": publico,
            "crear": sum(r["accion"] == "crear" for r in filas),
            "actualizar": sum(r["accion"] == "actualizar" for r in filas),
            "omitir": sum(r["accion"] == "omitir" for r in filas),
            "con_error": sum(r["accion"] == "error" for r in filas)}


# ---- procesamiento: catálogos ------------------------------------------------
def _convertir(c, valor, refs):
    if _vacio(valor):
        return None, None
    if c["tipo"] == "ref":
        f = _buscar(refs[c["name"]], _a_texto(valor))
        if f:
            return f["id"], None
        lista = TITULO_LISTA.get(c["ref"], c["ref"])
        return None, f"«{_a_texto(valor)}» no existe. Use un código de la hoja «{lista}»."
    if c["tipo"] == "select":
        clave = _norm(valor)
        for o in c["opciones"]:
            if clave in (_norm(o["valor"]), _norm(o["texto"])):
                return o["valor"], None
        return None, f"«{valor}» no es válido. Use: " + ", ".join(o["texto"] for o in c["opciones"]) + "."
    if c["tipo"] == "date":
        return _a_fecha(valor), None
    if c["tipo"] in ("text", "email") and not isinstance(valor, str):
        return _a_texto(valor), None
    return valor, None


def _procesar_generico(ctx, con, ent, body):
    spec = ENTIDADES[ent]
    eid = _eid(ctx, con, ent)
    campos = _campos(ent)
    filas = _hoja(_leer_libro(body.get("archivo")), spec["titulo"], primera_si_falta=True)
    if not filas:
        raise ApiError(400, "El archivo está vacío.")
    mapa, faltan = _mapear(filas[0], [(c["name"], [c["label"], c["name"], c["name"].replace("_", " ")], c.get("req"), c["label"]) for c in campos])
    if faltan:
        raise ApiError(400, "Al archivo le faltan columnas obligatorias: " + ", ".join(faltan) + ". Descargue la plantilla y use sus títulos tal como vienen.")
    datos = _filas_con_datos(filas)
    if not datos:
        raise ApiError(400, "El archivo no tiene filas con datos debajo de los títulos.")
    refs = {c["name"]: _filas_tabla(con, c["ref"], eid) for c in campos if c["tipo"] == "ref"}
    existentes = {str(r["codigo"]).upper(): r["id"] for r in _filas_tabla(con, ent, eid)}
    actualizar = bool(body.get("actualizar"))
    etiquetas = {c["name"]: c["label"] for c in campos}
    vistos, resultado = set(), []
    for n, fila in datos:
        crudo, errores = {}, {}
        for c in campos:
            v, err = _convertir(c, _valor(fila, mapa, c["name"]), refs)
            if err:
                errores[c["name"]] = err
            crudo[c["name"]] = v
        codigo = str(crudo.get("codigo") or "").strip().upper()
        id_actual = existentes.get(codigo) if actualizar else None
        limpio = None
        if not errores:
            try:
                limpio = _limpiar(spec, ent, crudo, con, eid, ctx.lang, id_actual)
            except ApiError as e:
                errores = e.campos or {"_": e.mensaje}
                if "codigo" in errores and codigo in existentes and not actualizar:
                    errores["codigo"] = f"El código «{codigo}» ya existe. Marca «actualizar» si quieres reemplazarlo con los datos del archivo."
        if codigo and codigo in vistos:
            errores["codigo"] = f"El código «{codigo}» está repetido dentro del archivo."
        vistos.add(codigo)
        resultado.append({"fila": n, "codigo": codigo, "nombre": _nombre_fila({k: str(v) for k, v in crudo.items() if v is not None}),
                          "accion": "error" if errores else ("actualizar" if id_actual else "crear"), "datos": limpio, "id": id_actual,
                          "errores": [f"{etiquetas.get(k, 'Fila')}: {v}" if k != "_" else v for k, v in errores.items()]})
    return eid, resultado


def _guardar_generico(con, ent, eid, resultado):
    from .db.database import sembrar_bases_incorporadas
    scoped = ENTIDADES[ent]["scoped"]
    for r in resultado:
        if r["accion"] not in ("crear", "actualizar"):
            continue
        d = dict(r["datos"])
        if r["accion"] == "actualizar":
            if ent == "bases_aplicacion":
                d.pop("codigo", None)  # nunca se cambia el código de una base (las incorporadas se reconocen por él)
            con.execute(f"UPDATE {ent} SET {', '.join(f'{k}=?' for k in d)} WHERE id=?", list(d.values()) + [r["id"]])
        else:
            if scoped:
                d["empresa_id"] = eid
            nuevo = con.execute(f"INSERT INTO {ent} ({', '.join(d)}) VALUES ({', '.join('?' * len(d))})", list(d.values())).lastrowid
            if ent == "empresas":
                sembrar_bases_incorporadas(con, nuevo)


# ---- procesamiento: recetas --------------------------------------------------
def _procesar_recetas(ctx, con, body):
    eid = _empresa_id(ctx, con)
    filas = _hoja(_leer_libro(body.get("archivo")), "Recetas", primera_si_falta=True)
    if not filas:
        raise ApiError(400, "El archivo está vacío.")
    mapa, faltan = _mapear(filas[0], [("p", ["Código del producto", "producto"], True, "Código del producto"),
                                      ("m", ["Código de materia prima", "materia prima"], True, "Código de materia prima"),
                                      ("q", ["Cantidad estándar por unidad", "cantidad estandar", "cantidad"], True, "Cantidad estándar por unidad")])
    if faltan:
        raise ApiError(400, "Al archivo le faltan columnas obligatorias: " + ", ".join(faltan) + ".")
    productos, materias = _filas_tabla(con, "productos", eid), _filas_tabla(con, "materias_primas", eid)
    existentes = {(r["producto_id"], r["materia_prima_id"]): r["id"] for r in con.execute(
        "SELECT r.* FROM receta_producto r JOIN productos p ON p.id=r.producto_id WHERE p.empresa_id=?", (eid,))}
    actualizar, vistos, resultado = bool(body.get("actualizar")), set(), []
    for n, fila in _filas_con_datos(filas):
        errores = []
        texto_p, texto_m = _a_texto(_valor(fila, mapa, "p")), _a_texto(_valor(fila, mapa, "m"))
        p, m = _buscar(productos, texto_p), _buscar(materias, texto_m)
        if not p:
            errores.append(f"Producto: «{texto_p}» no existe. Impórtelo o créelo primero.")
        if not m:
            errores.append(f"Materia prima: «{texto_m}» no existe. Impórtela o créela primero.")
        q, err = _numero("Cantidad estándar", _valor(fila, mapa, "q"))
        if err:
            errores.append(err)
        accion, rid = "crear", None
        if p and m:
            par = (p["id"], m["id"])
            if par in vistos:
                errores.append("Esta materia prima está repetida para el mismo producto dentro del archivo.")
            vistos.add(par)
            if par in existentes:
                if actualizar:
                    accion, rid = "actualizar", existentes[par]
                else:
                    errores.append("Esta materia prima ya está en la receta del producto. Marca «actualizar» para cambiar su cantidad.")
        resultado.append({"fila": n, "codigo": f"{p['codigo'] if p else texto_p} · {m['codigo'] if m else texto_m}",
                          "nombre": f"{p['descripcion'] if p else ''} — {m['descripcion'] if m else ''}",
                          "accion": "error" if errores else accion, "errores": errores,
                          "datos": (p["id"] if p else None, m["id"] if m else None, q), "id": rid})
    return eid, resultado


def _guardar_recetas(con, resultado):
    for r in resultado:
        pid, mid, q = r["datos"]
        if r["accion"] == "actualizar":
            con.execute("UPDATE receta_producto SET cantidad_estandar=? WHERE id=?", (q, r["id"]))
        elif r["accion"] == "crear":
            con.execute("INSERT INTO receta_producto (producto_id, materia_prima_id, cantidad_estandar) VALUES (?,?,?)", (pid, mid, q))


# ---- procesamiento: órdenes --------------------------------------------------
DETALLES_ORDEN = [
    ("Consumo de materiales", "materias_primas", "Materia prima", ["Cantidad real", "Precio real"],
     ["Código de materia prima", "materia prima"]),
    ("Mano de obra", "trabajadores", "Trabajador", ["Horas reales", "Tarifa real"], ["Código del trabajador", "trabajador"]),
    ("CIF real", "cif_conceptos", "Concepto de CIF", ["Monto real"], ["Código del concepto de CIF", "concepto de cif", "concepto"]),
]
CERRADA = "La orden ya está cerrada: no se modifica desde un archivo."


def _procesar_ordenes(ctx, con, body):
    eid = _empresa_id(ctx, con)
    hojas = _leer_libro(body.get("archivo"))
    actualizar = bool(body.get("actualizar"))
    t = {k: _filas_tabla(con, k, eid) for k in ("productos", "periodos", "materias_primas", "trabajadores", "cif_conceptos")}
    existentes = {r["numero"]: dict(r) for r in con.execute("SELECT * FROM ordenes_produccion WHERE empresa_id=?", (eid,))}
    resultado, en_archivo = [], {}  # en_archivo: número -> acción de su fila en «Órdenes»

    filas = _hoja(hojas, "Órdenes", primera_si_falta=True)
    if not filas:
        raise ApiError(400, "El archivo no tiene la hoja «Órdenes».")
    mapa, faltan = _mapear(filas[0], [("num", ["Número de orden", "numero"], True, "Número de orden"),
                                      ("prod", ["Código del producto", "producto"], True, "Código del producto"),
                                      ("per", ["Código del periodo", "periodo"], True, "Código del periodo"),
                                      ("fecha", ["Fecha"], True, "Fecha"),
                                      ("cant", ["Cantidad planeada"], True, "Cantidad planeada")])
    if faltan:
        raise ApiError(400, "A la hoja «Órdenes» le faltan columnas obligatorias: " + ", ".join(faltan) + ".")
    for n, fila in _filas_con_datos(filas):
        errores = []
        numero = _a_texto(_valor(fila, mapa, "num"))
        if not numero:
            errores.append("Falta el número de orden.")
        elif len(numero) > 20:
            errores.append("El número de orden admite máximo 20 caracteres.")
        texto_p, texto_pe = _a_texto(_valor(fila, mapa, "prod")), _a_texto(_valor(fila, mapa, "per"))
        p, pe = _buscar(t["productos"], texto_p), _buscar(t["periodos"], texto_pe)
        if not p:
            errores.append(f"Producto: «{texto_p}» no existe.")
        if not pe:
            errores.append(f"Periodo: «{texto_pe}» no existe.")
        fecha, err = validar_campo({"label": "Fecha", "tipo": "date", "req": True}, _a_fecha(_valor(fila, mapa, "fecha")))
        if err:
            errores.append(err)
        cant, err = _numero("Cantidad planeada", _valor(fila, mapa, "cant"))
        if err:
            errores.append(err)
        accion, oid = "crear", None
        if numero and numero in en_archivo:
            errores.append(f"El número de orden «{numero}» está repetido en la hoja.")
        elif numero in existentes:
            ex = existentes[numero]
            if ex["estado"] == "terminada":
                accion, errores = "omitir", [CERRADA]
            elif actualizar:
                accion, oid = "actualizar", ex["id"]
            else:
                errores.append(f"La orden «{numero}» ya existe. Marca «actualizar» para reemplazar sus datos.")
        if accion != "omitir" and errores:
            accion = "error"
        if numero and numero not in en_archivo:
            en_archivo[numero] = accion
        resultado.append({"hoja": "Órdenes", "fila": n, "codigo": numero, "nombre": p["descripcion"] if p else "",
                          "accion": accion, "errores": errores, "id": oid,
                          "datos": {"producto_id": p["id"] if p else None, "periodo_id": pe["id"] if pe else None,
                                    "fecha": fecha, "cantidad_planeada": cant}})

    for hoja, tabla, etiqueta, numeros, nombres_item in DETALLES_ORDEN:
        filas = _hoja(hojas, hoja)
        if not filas or len(filas) < 2:
            continue
        columnas = [("num", ["Número de orden", "numero"], True, "Número de orden"), ("item", nombres_item, True, nombres_item[0])]
        columnas += [(f"v{i}", [texto], True, texto) for i, texto in enumerate(numeros)]
        mapa, faltan = _mapear(filas[0], columnas)
        if faltan:
            raise ApiError(400, f"A la hoja «{hoja}» le faltan columnas obligatorias: " + ", ".join(faltan) + ".")
        pares = set()
        for n, fila in _filas_con_datos(filas):
            errores, accion = [], "crear"
            numero = _a_texto(_valor(fila, mapa, "num"))
            estado, ex = en_archivo.get(numero), existentes.get(numero)
            texto_item = _a_texto(_valor(fila, mapa, "item"))
            item = _buscar(t[tabla], texto_item)
            valores = []
            if estado == "omitir" or (estado is None and ex and ex["estado"] == "terminada"):
                accion, errores = "omitir", [CERRADA]
            else:
                if estado == "error":
                    errores.append(f"La orden «{numero}» tiene errores en la hoja «Órdenes».")
                elif estado is None and not ex:
                    errores.append(f"La orden «{numero}» no está en la hoja «Órdenes» ni en el sistema.")
                elif estado is None and ex and not actualizar:
                    errores.append(f"La orden «{numero}» ya existe. Marca «actualizar» para reemplazar su {hoja.lower()}.")
                if not item:
                    errores.append(f"{etiqueta}: «{texto_item}» no existe.")
                for i, texto in enumerate(numeros):
                    v, err = _numero(texto, _valor(fila, mapa, f"v{i}"))
                    if err:
                        errores.append(err)
                    valores.append(v)
                if tabla == "cif_conceptos" and item:
                    if (numero, item["id"]) in pares:
                        errores.append("Este concepto de CIF está repetido para la misma orden.")
                    pares.add((numero, item["id"]))
                if errores:
                    accion = "error"
            resultado.append({"hoja": hoja, "fila": n, "codigo": numero, "nombre": _nombre_fila(item) if item else texto_item,
                              "accion": accion, "errores": errores, "datos": (numero, item["id"] if item else None, *valores)})
    return eid, resultado, existentes


TABLAS_DETALLE = {"Consumo de materiales": ("consumo_mp", "materia_prima_id, cantidad_real, precio_real"),
                  "Mano de obra": ("horas_mod", "trabajador_id, horas_reales, tarifa_real"),
                  "CIF real": ("cif_real_orden", "concepto_id, monto_real")}


def _guardar_ordenes(con, eid, resultado, existentes):
    ids = {num: o["id"] for num, o in existentes.items()}
    for r in resultado:
        if r["hoja"] != "Órdenes" or r["accion"] not in ("crear", "actualizar"):
            continue
        d = r["datos"]
        if r["accion"] == "actualizar":
            con.execute("UPDATE ordenes_produccion SET producto_id=?, periodo_id=?, fecha=?, cantidad_planeada=? WHERE id=? AND estado!='terminada'",
                        (d["producto_id"], d["periodo_id"], d["fecha"], d["cantidad_planeada"], r["id"]))
        else:
            ids[r["codigo"]] = con.execute(
                "INSERT INTO ordenes_produccion (empresa_id, periodo_id, numero, producto_id, fecha, cantidad_planeada) VALUES (?,?,?,?,?,?)",
                (eid, d["periodo_id"], r["codigo"], d["producto_id"], d["fecha"], d["cantidad_planeada"])).lastrowid
    reemplazadas = set()
    for r in resultado:
        if r["hoja"] not in TABLAS_DETALLE or r["accion"] != "crear":
            continue
        tabla, cols = TABLAS_DETALLE[r["hoja"]]
        numero, *valores = r["datos"]
        oid = ids[numero]
        if numero in existentes and (tabla, oid) not in reemplazadas:  # orden existente: el archivo reemplaza este detalle
            con.execute(f"DELETE FROM {tabla} WHERE orden_id=?", (oid,))
            reemplazadas.add((tabla, oid))
        con.execute(f"INSERT INTO {tabla} (orden_id, {cols}) VALUES (?{', ?' * len(valores)})", (oid, *valores))


# ---- API pública: revisar y confirmar ----------------------------------------
def _procesar(ctx, con, ent):
    _requiere_libreria()
    _validar_modulo(ent)
    _requiere_permiso(ctx, con, PERMISO_ESPECIAL.get(ent, ent))
    if not ctx.body.get("archivo"):
        raise ApiError(400, "Elija un archivo de Excel para importar.")
    if ent == "recetas":
        eid, res = _procesar_recetas(ctx, con, ctx.body)
        return eid, res, None
    if ent == "ordenes":
        return _procesar_ordenes(ctx, con, ctx.body)
    eid, res = _procesar_generico(ctx, con, ent, ctx.body)
    return eid, res, None


def revisar(ctx, con, ent):
    _, resultado, _ = _procesar(ctx, con, ent)
    return _resultado(resultado)


def confirmar(ctx, con, ent):
    eid, resultado, extra = _procesar(ctx, con, ent)
    if not any(r["accion"] in ("crear", "actualizar") for r in resultado):
        raise ApiError(400, "No hay filas válidas para importar. Corrija los errores del archivo y vuelva a intentarlo.")
    if ent == "ordenes" and any(r["accion"] == "actualizar" for r in resultado):
        # Actualizar órdenes existentes es editarlas: se pide el mismo código que en la pantalla (si no, sería una puerta trasera)
        from . import produccion
        produccion.verificar_codigo(ctx, con, "actualizar órdenes existentes desde un archivo de Excel")
    try:
        if ent == "recetas":
            _guardar_recetas(con, resultado)
        elif ent == "ordenes":
            _guardar_ordenes(con, eid, resultado, extra)
        else:
            _guardar_generico(con, ent, eid, resultado)
    except ApiError:
        con.rollback()
        raise
    except Exception:
        con.rollback()
        raise ApiError(500, "La importación se canceló por un error al guardar; no se guardó ninguna fila.")
    r = _resultado(resultado)
    omitidas = r["con_error"] + r["omitir"]
    auditar(con, ctx.user["username"], "importar", ent,
            f"Desde Excel: {r['crear']} creados, {r['actualizar']} actualizados, {omitidas} filas omitidas")
    con.commit()
    return {"creadas": r["crear"], "actualizadas": r["actualizar"], "omitidas": omitidas}
