"""Conexión a SQLite, creación del esquema y datos iniciales."""
import os
import sqlite3

from .. import settings
from ..security import hash_password


# Versión del esquema de la base. Súbala cada vez que el esquema cambie de forma que una versión anterior de Margia
# no pueda leerlo. Se guarda dentro del propio archivo (PRAGMA user_version) y viaja con cada respaldo.
SCHEMA_VERSION = 1


class VersionNuevaError(Exception):
    """La base la creó una versión más nueva de Margia que la que se está ejecutando."""


def db_path():
    ruta = settings.get("base_datos", "ruta", "data/costos.db")
    return ruta if os.path.isabs(ruta) else os.path.join(settings.DATA_BASE, ruta)


def connect():
    con = sqlite3.connect(db_path(), timeout=20)  # espera hasta 20 s si otra persona está guardando
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


UNIDADES = [
    ("KG", "Kilogramo", "kg"), ("G", "Gramo", "g"), ("LB", "Libra", "lb"),
    ("L", "Litro", "l"), ("ML", "Mililitro", "ml"), ("UND", "Unidad", "und"),
    ("M", "Metro", "m"), ("HR", "Hora", "h"),
]


BASES_INCORPORADAS = [
    ("mano_obra_directa", "Mano de obra directa"),
    ("hora_maquina", "Horas máquina"),
    ("unidades_producidas", "Unidades producidas"),
]


def sembrar_bases_incorporadas(con, empresa_id):
    """Crea, si faltan, las 3 bases de aplicación incorporadas para una empresa."""
    for codigo, nombre in BASES_INCORPORADAS:
        if not con.execute("SELECT 1 FROM bases_aplicacion WHERE empresa_id=? AND lower(codigo)=?", (empresa_id, codigo)).fetchone():
            con.execute("INSERT INTO bases_aplicacion (empresa_id, codigo, nombre, protegida) VALUES (?,?,?,1)",
                        (empresa_id, codigo, nombre))


def _migrar(con):
    """Agrega columnas y tablas nuevas a bases de datos creadas con una versión anterior del esquema."""
    cols = {r["name"] for r in con.execute("PRAGMA table_info(usuarios)")}
    if "permisos" not in cols:
        con.execute("ALTER TABLE usuarios ADD COLUMN permisos TEXT NOT NULL DEFAULT '{}'")
    cols_emp = {r["name"] for r in con.execute("PRAGMA table_info(empresas)")}
    if "logo" not in cols_emp:
        con.execute("ALTER TABLE empresas ADD COLUMN logo TEXT")
    if "tema" not in cols_emp:
        con.execute("ALTER TABLE empresas ADD COLUMN tema TEXT")
    cols_mp = {r["name"] for r in con.execute("PRAGMA table_info(materias_primas)")}
    if cols_mp and "stock_minimo" not in cols_mp:
        con.execute("ALTER TABLE materias_primas ADD COLUMN stock_minimo REAL NOT NULL DEFAULT 0")
    cols_ce = {r["name"] for r in con.execute("PRAGMA table_info(costos_estandar)")}
    if cols_ce:
        for col, tipo in (("precio_venta", "REAL NOT NULL DEFAULT 0"), ("guardado", "TEXT"), ("guardado_por", "TEXT")):
            if col not in cols_ce:
                con.execute(f"ALTER TABLE costos_estandar ADD COLUMN {col} {tipo}")
    cols_per = {r["name"] for r in con.execute("PRAGMA table_info(periodos)")}
    if "unidades_presupuestadas" not in cols_per:
        con.execute("ALTER TABLE periodos ADD COLUMN unidades_presupuestadas REAL NOT NULL DEFAULT 0")
    con.commit()

    # Corregir bases incorporadas cuyo código quedó en mayúscula (error de versiones anteriores al editarlas)
    if con.execute("SELECT 1 FROM sqlite_master WHERE name='bases_aplicacion'").fetchone():
        for codigo, _ in BASES_INCORPORADAS:
            con.execute("UPDATE bases_aplicacion SET codigo=? WHERE lower(codigo)=? AND protegida=1", (codigo, codigo))
    # Sembrar las 3 bases incorporadas en toda empresa que aún no las tenga
    for e in con.execute("SELECT id FROM empresas").fetchall():
        sembrar_bases_incorporadas(con, e["id"])
    con.commit()

    # cif_conceptos: si todavía tiene la columna vieja base_aplicacion (texto con CHECK fijo),
    # se reconstruye la tabla para pasar a base_aplicacion_id (referencia a bases_aplicacion).
    cols_cif = {r["name"] for r in con.execute("PRAGMA table_info(cif_conceptos)")}
    if "base_aplicacion" in cols_cif and "base_aplicacion_id" not in cols_cif:
        con.execute("ALTER TABLE cif_conceptos RENAME TO cif_conceptos_viejo")
        con.execute("""CREATE TABLE cif_conceptos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          empresa_id INTEGER NOT NULL REFERENCES empresas(id),
          centro_costo_id INTEGER REFERENCES centros_costo(id),
          codigo TEXT NOT NULL,
          descripcion TEXT NOT NULL,
          tipo TEXT NOT NULL CHECK (tipo IN ('fijo','variable')),
          base_aplicacion_id INTEGER NOT NULL REFERENCES bases_aplicacion(id),
          presupuestado REAL NOT NULL DEFAULT 0,
          real REAL NOT NULL DEFAULT 0,
          UNIQUE (empresa_id, codigo)
        )""")
        for fila in con.execute("SELECT * FROM cif_conceptos_viejo").fetchall():
            base = con.execute("SELECT id FROM bases_aplicacion WHERE empresa_id=? AND codigo=?",
                                (fila["empresa_id"], fila["base_aplicacion"])).fetchone()
            if not base:
                continue  # base desconocida; se omite el concepto huérfano
            con.execute(
                "INSERT INTO cif_conceptos (id, empresa_id, centro_costo_id, codigo, descripcion, tipo, base_aplicacion_id, presupuestado, real) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (fila["id"], fila["empresa_id"], fila["centro_costo_id"], fila["codigo"], fila["descripcion"],
                 fila["tipo"], base["id"], fila["presupuestado"], fila["real"]))
        con.execute("DROP TABLE cif_conceptos_viejo")
        con.commit()

    con.execute("CREATE TABLE IF NOT EXISTS ajustes (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")  # código de autorización de órdenes
    con.commit()

    for tabla, sql in (
        ("producto_base_estandar", """CREATE TABLE IF NOT EXISTS producto_base_estandar (
            id INTEGER PRIMARY KEY AUTOINCREMENT, producto_id INTEGER NOT NULL REFERENCES productos(id),
            base_id INTEGER NOT NULL REFERENCES bases_aplicacion(id), cantidad_estandar REAL NOT NULL,
            UNIQUE (producto_id, base_id))"""),
        ("orden_base_real", """CREATE TABLE IF NOT EXISTS orden_base_real (
            id INTEGER PRIMARY KEY AUTOINCREMENT, orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
            base_id INTEGER NOT NULL REFERENCES bases_aplicacion(id), cantidad_real REAL NOT NULL,
            UNIQUE (orden_id, base_id))"""),
    ):
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (tabla,)).fetchone():
            con.execute(sql)
    con.commit()


def init():
    os.makedirs(os.path.dirname(db_path()), exist_ok=True)
    con = connect()
    version = con.execute("PRAGMA user_version").fetchone()[0]
    if version > SCHEMA_VERSION:
        con.close()
        raise VersionNuevaError(
            f"La base de datos fue creada por una versión más nueva de Margia (esquema {version}) y esta versión solo "
            f"entiende hasta el esquema {SCHEMA_VERSION}. Abrirla podría dañarla.")
    with open(settings.resource("backend", "db", "schema.sql"), encoding="utf-8") as f:
        con.executescript(f.read())
    _migrar(con)
    if con.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
        clave_admin = settings.clave_inicial_admin()
        iniciales = ((("admin", "Administrador", "administrador", clave_admin),) if clave_admin else (
            ("admin", "Administrador", "administrador", "admin123"),
            ("estudiante", "Estudiante", "estudiante", "estudiante123"),
        ))  # con contraseña propia no se crea la cuenta pública de estudiante
        for username, nombre, rol, clave in iniciales:
            h, s = hash_password(clave)
            con.execute(
                "INSERT INTO usuarios (username, nombre, rol, password_hash, salt) VALUES (?,?,?,?,?)",
                (username, nombre, rol, h, s),
            )
        con.execute("INSERT INTO bitacora (usuario, accion, detalle) VALUES ('sistema','crear_bd','Base de datos creada con usuarios iniciales')")
    if con.execute("SELECT COUNT(*) FROM unidades_medida").fetchone()[0] == 0:
        con.executemany("INSERT INTO unidades_medida (codigo, nombre, abreviatura) VALUES (?,?,?)", UNIDADES)
    con.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    con.commit()
    con.close()
