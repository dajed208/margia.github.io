PRAGMA foreign_keys = ON;

-- Seguridad ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  nombre TEXT NOT NULL,
  rol TEXT NOT NULL CHECK (rol IN ('administrador','estudiante')),
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  activo INTEGER NOT NULL DEFAULT 1,
  permisos TEXT NOT NULL DEFAULT '{}',
  creado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS bitacora (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  usuario TEXT,
  accion TEXT NOT NULL,
  entidad TEXT,
  detalle TEXT
);

CREATE TABLE IF NOT EXISTS permisos (
  clave TEXT PRIMARY KEY,
  habilitado INTEGER NOT NULL DEFAULT 0
);

-- Datos generales ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS empresas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT NOT NULL UNIQUE,
  razon_social TEXT NOT NULL,
  nit TEXT NOT NULL,
  regimen TEXT,
  responsable_iva TEXT,
  actividad_economica TEXT,
  direccion TEXT,
  telefono TEXT,
  email TEXT,
  moneda TEXT NOT NULL DEFAULT 'COP',
  logo TEXT,
  tema TEXT
);

CREATE TABLE IF NOT EXISTS periodos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  nombre TEXT NOT NULL,
  fecha_inicio TEXT NOT NULL,
  fecha_fin TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','cerrado')),
  unidades_presupuestadas REAL NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

CREATE TABLE IF NOT EXISTS unidades_medida (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo TEXT NOT NULL UNIQUE,
  nombre TEXT NOT NULL,
  abreviatura TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS centros_costo (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  nombre TEXT NOT NULL,
  tipo TEXT NOT NULL DEFAULT 'produccion',
  UNIQUE (empresa_id, codigo)
);

CREATE TABLE IF NOT EXISTS productos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  unidad_id INTEGER NOT NULL REFERENCES unidades_medida(id),
  precio_venta REAL NOT NULL DEFAULT 0,
  horas_mod_std REAL NOT NULL DEFAULT 0,
  horas_maquina_std REAL NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

CREATE TABLE IF NOT EXISTS materias_primas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  unidad_id INTEGER NOT NULL REFERENCES unidades_medida(id),
  unidad_estandar_id INTEGER NOT NULL REFERENCES unidades_medida(id),
  costo_estandar REAL NOT NULL DEFAULT 0,
  proveedor TEXT,
  eficiencia_pct REAL NOT NULL DEFAULT 100,
  stock_minimo REAL NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

CREATE TABLE IF NOT EXISTS receta_producto (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  materia_prima_id INTEGER NOT NULL REFERENCES materias_primas(id),
  cantidad_estandar REAL NOT NULL,
  UNIQUE (producto_id, materia_prima_id)
);

-- Mano de obra directa ----------------------------------------------------
CREATE TABLE IF NOT EXISTS trabajadores (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  nombre TEXT NOT NULL,
  cargo TEXT NOT NULL,
  salario_mensual REAL NOT NULL,
  prestaciones_pct REAL NOT NULL DEFAULT 0,
  cargas_pct REAL NOT NULL DEFAULT 0,
  horas_mes REAL NOT NULL DEFAULT 192,
  tarifa_std_hora REAL NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

CREATE TABLE IF NOT EXISTS bases_aplicacion (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  codigo TEXT NOT NULL,
  nombre TEXT NOT NULL,
  protegida INTEGER NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

-- Costos indirectos de fabricación ---------------------------------------
CREATE TABLE IF NOT EXISTS cif_conceptos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  centro_costo_id INTEGER REFERENCES centros_costo(id),
  codigo TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('fijo','variable')),
  base_aplicacion_id INTEGER NOT NULL REFERENCES bases_aplicacion(id),
  presupuestado REAL NOT NULL DEFAULT 0,
  real REAL NOT NULL DEFAULT 0,
  UNIQUE (empresa_id, codigo)
);

-- Consumo estándar y real de bases de aplicación personalizadas ----------
CREATE TABLE IF NOT EXISTS producto_base_estandar (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  base_id INTEGER NOT NULL REFERENCES bases_aplicacion(id),
  cantidad_estandar REAL NOT NULL,
  UNIQUE (producto_id, base_id)
);
CREATE TABLE IF NOT EXISTS orden_base_real (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  base_id INTEGER NOT NULL REFERENCES bases_aplicacion(id),
  cantidad_real REAL NOT NULL,
  UNIQUE (orden_id, base_id)
);

-- Producción (fases siguientes) ------------------------------------------
CREATE TABLE IF NOT EXISTS ordenes_produccion (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  periodo_id INTEGER NOT NULL REFERENCES periodos(id),
  numero TEXT NOT NULL,
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  fecha TEXT NOT NULL,
  cantidad_planeada REAL NOT NULL,
  cantidad_producida REAL NOT NULL DEFAULT 0,
  unidades_en_proceso REAL NOT NULL DEFAULT 0,
  pct_avance REAL NOT NULL DEFAULT 0,
  horas_maquina_reales REAL NOT NULL DEFAULT 0,
  estado TEXT NOT NULL DEFAULT 'abierta' CHECK (estado IN ('abierta','en_proceso','terminada')),
  UNIQUE (empresa_id, numero)
);
CREATE TABLE IF NOT EXISTS consumo_mp (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  materia_prima_id INTEGER NOT NULL REFERENCES materias_primas(id),
  cantidad_real REAL NOT NULL,
  precio_real REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS horas_mod (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
  horas_reales REAL NOT NULL,
  tarifa_real REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS cif_real_orden (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  concepto_id INTEGER NOT NULL REFERENCES cif_conceptos(id),
  monto_real REAL NOT NULL,
  UNIQUE (orden_id, concepto_id)
);
CREATE TABLE IF NOT EXISTS cif_aplicado (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  concepto_id INTEGER NOT NULL REFERENCES cif_conceptos(id),
  base_real REAL NOT NULL,
  monto REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS costos_estandar (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  producto_id INTEGER NOT NULL REFERENCES productos(id),
  periodo_id INTEGER NOT NULL REFERENCES periodos(id),
  costo_mp REAL NOT NULL, costo_mod REAL NOT NULL, costo_cif REAL NOT NULL, total REAL NOT NULL,
  precio_venta REAL NOT NULL DEFAULT 0,
  guardado TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  guardado_por TEXT,
  UNIQUE (producto_id, periodo_id)
);
CREATE TABLE IF NOT EXISTS costos_reales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL UNIQUE REFERENCES ordenes_produccion(id),
  costo_mp REAL NOT NULL, costo_mod REAL NOT NULL, costo_cif REAL NOT NULL, total REAL NOT NULL,
  costo_mp_unitario REAL NOT NULL DEFAULT 0, costo_mod_unitario REAL NOT NULL DEFAULT 0,
  costo_cif_unitario REAL NOT NULL DEFAULT 0, total_unitario REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS variaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  orden_id INTEGER NOT NULL REFERENCES ordenes_produccion(id),
  tipo TEXT NOT NULL,
  monto REAL NOT NULL,
  clasificacion TEXT NOT NULL CHECK (clasificacion IN ('favorable','desfavorable','neutra'))
);

-- Inventario de materias primas --------------------------------------------
CREATE TABLE IF NOT EXISTS movimientos_inventario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  empresa_id INTEGER NOT NULL REFERENCES empresas(id),
  materia_prima_id INTEGER NOT NULL REFERENCES materias_primas(id),
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL CHECK (tipo IN ('entrada','salida')),
  cantidad REAL NOT NULL,
  costo_unitario REAL NOT NULL DEFAULT 0,
  orden_id INTEGER REFERENCES ordenes_produccion(id),
  nota TEXT,
  creado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Ajustes del sistema (clave → valor). Hoy guarda el código de autorización para corregir órdenes de producción.
CREATE TABLE IF NOT EXISTS ajustes (
  clave TEXT PRIMARY KEY,
  valor TEXT NOT NULL
);
