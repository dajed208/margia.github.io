"""Registro de funcionamiento y errores: data/logs/margia.log (se rota solo: 6 archivos de hasta 1 MB).

Es lo primero que hay que mirar cuando algo falla en el computador de alguien: ahí queda el detalle técnico
(qué petición, qué usuario y el error completo) que a la persona se le muestra solo como «ocurrió un error».
Nunca se escriben contraseñas ni el contenido de las peticiones.
"""
import logging
import os
from logging.handlers import RotatingFileHandler

log = logging.getLogger("margia")
log.addHandler(logging.NullHandler())
_ruta = None


def iniciar(carpeta):
    """Activa el archivo de registro en `carpeta`. Si no se puede escribir, el programa sigue sin registro."""
    global _ruta
    try:
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, "margia.log")
        manejador = RotatingFileHandler(ruta, maxBytes=1_000_000, backupCount=5, encoding="utf-8")
        manejador.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-8s %(message)s", "%Y-%m-%d %H:%M:%S"))
        for viejo in list(log.handlers):
            log.removeHandler(viejo)
            try:
                viejo.close()
            except Exception:  # noqa: BLE001
                pass
        log.addHandler(manejador)
        log.setLevel(logging.INFO)
        log.propagate = False
        _ruta = ruta
        return ruta
    except OSError:
        return None


def ruta():
    return _ruta
