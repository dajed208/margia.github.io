"""Punto de entrada de Margia.

    python iniciar.py              -> inicia el sistema y abre el navegador
    python iniciar.py --verificar  -> comprueba que el programa tenga todo lo necesario y termina
    python iniciar.py --version    -> muestra la versión y termina
"""
import datetime
import os
import sys
import traceback


def _fallo_inesperado():
    """Muestra el error y lo guarda en data/margia_errores.log (la ventana no se cierra sola antes de poder leerlo)."""
    texto = traceback.format_exc()
    ruta = None
    try:
        from backend import settings
        carpeta = os.path.join(settings.DATA_BASE, "data")
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, "margia_errores.log")
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(f"\n=== {datetime.datetime.now():%Y-%m-%d %H:%M:%S} ===\n{texto}")
    except Exception:  # noqa: BLE001
        pass
    print("\nCifra no pudo continuar por un error inesperado.")
    print("Última línea del error: " + (texto.strip().splitlines()[-1] if texto.strip() else "desconocido"))
    if ruta:
        print("El detalle completo quedó guardado en:\n  " + ruta)
    print("Si el problema se repite, envíe ese archivo a quien le entregó el programa.")
    try:
        input("\nPresiona Enter para salir...")
    except (EOFError, RuntimeError):
        pass


def _consola_robusta():
    """Los mensajes salen al instante (aunque la salida no sea una pantalla) y un carácter que la consola de Windows
    no sepa mostrar se reemplaza por «?» en vez de tumbar el programa."""
    for flujo in (sys.stdout, sys.stderr):
        if flujo is not None:
            try:
                flujo.reconfigure(line_buffering=True, errors="replace")
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    _consola_robusta()
    if "--version" in sys.argv:
        from backend.version import __version__
        print(__version__)
        sys.exit(0)
    if "--verificar" in sys.argv:
        from backend.verificar import main as verificar
        sys.exit(verificar())
    try:
        from backend.server import main
        main()
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception:  # noqa: BLE001
        _fallo_inesperado()
        sys.exit(1)
