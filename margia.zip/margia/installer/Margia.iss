﻿; Instalador de Margia (Inno Setup 6). SIN PROBAR: se escribio sin poder ejecutar Inno Setup en el entorno de desarrollo.
; Uso: 1) ejecute installer\build_exe.bat   2) abra este archivo con Inno Setup y pulse Compilar (F9).
; Resultado: salida\Margia-Setup-<version>.exe
;
; Decisiones:
;  - Se instala SIN permisos de administrador en %LOCALAPPDATA%\Programs\Margia: ahi Windows deja escribir, asi
;    que la base de datos (carpeta data) queda junto al programa, como en la version en carpeta.
;  - Al actualizar, NO se tocan data\ ni config\config.ini (se conservan los datos y la configuracion).
;  - Al desinstalar, la carpeta data\ se conserva (los datos del usuario no se borran por accidente).
#define AppName "Margia"
#define AppVersion "1.0.0"

[Setup]
AppId={{6F1B7E52-3C0A-4B8E-9D17-5A2C9E40B1D3}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Margia
DefaultDirName={localappdata}\Programs\{#AppName}
DefaultGroupName={#AppName}
PrivilegesRequired=lowest
OutputDir=..\salida
OutputBaseFilename=Margia-Setup-{#AppVersion}
SetupIconFile=icono.ico
UninstallDisplayIcon={app}\Margia.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ShowLanguageDialog=no
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Dirs]
Name: "{app}\data"; Flags: uninsneveruninstall

[Files]
Source: "..\dist_final\Margia\*"; DestDir: "{app}"; Excludes: "data\*,config\config.ini"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "..\dist_final\Margia\config\config.ini"; DestDir: "{app}\config"; Flags: onlyifdoesntexist

[Icons]
Name: "{group}\Margia"; Filename: "{app}\Margia.exe"; WorkingDir: "{app}"
Name: "{group}\Manual de usuario"; Filename: "{app}\MANUAL_USUARIO.md"
Name: "{group}\Desinstalar Margia"; Filename: "{uninstallexe}"
Name: "{autodesktop}\Margia"; Filename: "{app}\Margia.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\Margia.exe"; Description: "Abrir Margia ahora"; WorkingDir: "{app}"; Flags: nowait postinstall skipifsilent
