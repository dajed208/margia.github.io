# Pruebas automáticas

- `prueba_interfaz.py`: abre el sistema en un navegador real (Chromium, vía Playwright), carga datos de ejemplo,
  recorre las pantallas y verifica 24 comportamientos (buscador, validaciones, inventario, precios, respaldo,
  reportes en Excel, cambio de contraseña…). Requiere `pip install playwright` y `playwright install chromium`.

- `prueba_mejoras.py`: 11 comprobaciones de la importación desde Excel (plantilla, vista previa con errores,
  actualización de existentes), del histórico de costos entre dos periodos y de la descarga del PDF.

- `prueba_excel_ui.py`: 13 comprobaciones de exportar desde las 10 pantallas, importar órdenes con una orden
  cerrada y permisos de un estudiante.
- `prueba_import_export.py`: 49 comprobaciones sin navegador (rápida): exporta una empresa completa, la importa en
  otra vacía y compara; reimporta con «actualizar» sin duplicar, valida plantillas, errores y bases incorporadas.

- `prueba_despliegue.py`: 35 comprobaciones que ejecutan el programa como proceso aparte en situaciones de una instalación real
  (configuración editada con el Bloc de notas, consola de Windows, rutas con tildes, carpeta sin permisos, entorno empaquetado
  simulado, modo de red, respaldos automáticos, actualizaciones, fallos al iniciar, varias personas a la vez). No requiere navegador.
- `prueba_marca.py`: 45 comprobaciones de la marca (Margia): sin restos del nombre anterior, archivos del logo válidos (SVG, PNG, ICO con 7 tamaños),
  pantalla de inicio y menú, adaptación al tema claro/oscuro, y que quien venía de «Cifra» no pierda nada (variables de entorno,
  carpeta de datos y copia de la base anterior).
- `prueba_ordenes_codigo.py`: 60 comprobaciones sin navegador del código de autorización y de editar, reabrir y eliminar
  órdenes (recálculo de costos, restitución de inventario, bloqueo por intentos, permisos, importación y respaldos antiguos).
- `prueba_acciones_ui.py`: 48 comprobaciones. Recorre con clics y teclado **todas las acciones de escritura** (llenar y cerrar
  órdenes, recetas, bases personalizadas, editar y eliminar, logo y colores, usuarios con permisos, inventario, respaldo y
  restauración) y exige que ningún aviso de error salga vacío.
- `revisar_javascript.py`: busca variables no definidas en toda la interfaz (requiere TypeScript; se omite si no está).
- `prueba_cif_bases.py`: 12 comprobaciones sin navegador del CIF con bases sin consumo cargado.
- `prueba_guia.py`: 25 comprobaciones de la guía «Tu ruta para empezar» del dashboard, desde un sistema vacío hasta
  la primera orden cerrada: conteo, paso siguiente, mensajes de pasos incompletos, navegación de cada «ir →» y ocultar.

Ejecútelas desde la carpeta raíz del proyecto:

    python tests/prueba_despliegue.py
    python tests/revisar_javascript.py
    python tests/prueba_marca.py
    python tests/prueba_ordenes_codigo.py
    python tests/prueba_acciones_ui.py
    python tests/prueba_cif_bases.py
    python tests/prueba_guia.py
    python tests/prueba_interfaz.py
    python tests/prueba_mejoras.py
    python tests/prueba_excel_ui.py
    python tests/prueba_import_export.py

La prueba usa una base de datos temporal propia: **no toca** `data/costos.db` ni sus datos reales.
Las capturas de pantalla de cada paso quedan en la carpeta `capturas_prueba/`.
