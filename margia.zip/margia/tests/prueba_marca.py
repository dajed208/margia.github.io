"""Marca (Margia): nada del nombre anterior fuera de la compatibilidad, logo y archivos válidos, la pantalla, y que quien venía
de «Cifra» no pierda nada (variables de entorno, carpeta de datos y copia de la base anterior). Base de datos temporal."""
import builtins, io, json, os, re, struct, subprocess, sys, tempfile, threading, time, urllib.request, xml.etree.ElementTree as ET
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
from backend.db import database
_T = os.path.join(tempfile.mkdtemp(), "p.db"); database.db_path = lambda: _T
import backend.server as server
from backend import api, marca, respaldos, settings
from PIL import Image
from playwright.sync_api import sync_playwright

fallos = []
def check(c, t): print(("  ✓ " if c else "  ✗ ") + t); (not c) and fallos.append(t)
def leer(*p): return open(os.path.join(RAIZ, *p), encoding="utf-8-sig").read()

print("Nombre y frase")
check(marca.NOMBRE == "Margia" and marca.LEMA == "Conoce tu costo. Cuida tu margen.", "marca.py: «Margia» y «Conoce tu costo. Cuida tu margen.»")
SUFIJOS = {".py", ".js", ".html", ".css", ".md", ".txt", ".ini", ".bat", ".iss"}
PERMITIDOS = {"backend/respaldos.py", "backend/settings.py", "backend/server.py", "docs/MARCA.md", "docs/MANUAL_TECNICO.md", "tests/prueba_marca.py"}
restos = []
for base, dirs, archivos in os.walk(RAIZ):
    dirs[:] = [d for d in dirs if d not in ("data", "__pycache__", "capturas_prueba", ".git")]
    for a in archivos:
        if os.path.splitext(a)[1] not in SUFIJOS: continue
        rel = os.path.relpath(os.path.join(base, a), RAIZ).replace(os.sep, "/")
        for n, linea in enumerate(open(os.path.join(base, a), encoding="utf-8-sig").read().splitlines(), 1):
            if re.search(r"\bCifra\b|CIFRA|«cifra»|\"cifra\"", linea) and rel not in PERMITIDOS: restos.append(f"{rel}:{n}")
check(not restos, "no queda el nombre anterior en la interfaz, el instalador ni los manuales" + (f" — restos: {restos[:4]}" if restos else ""))
PALABRAS = (("docs/MANUAL_USUARIO.md", "Margia no inventa una cifra"), ("backend/produccion.py", "ni siquiera cifrado"),
            ("backend/server.py", "no está cifrada"), ("tests/prueba_cif_bases.py", "cifras absurdas"))
check(all(frase in leer(*ruta.split("/")) for ruta, frase in PALABRAS), "las palabras españolas «cifra», «cifras», «cifrado» y «cifrada» quedaron intactas (se comprobó cada una)")

print("Archivos del logo")
for ruta in ("frontend/img/margia-icono.svg", "frontend/img/margia-icono-blanco.svg", "marca/margia-icono.svg", "marca/margia-icono-blanco.svg",
             "marca/margia-logo-horizontal.svg", "marca/margia-logo-horizontal-blanco.svg"):
    try:
        raiz = ET.fromstring(open(os.path.join(RAIZ, ruta), "rb").read()); ok = raiz.tag.endswith("svg") and "viewBox" in raiz.attrib
    except Exception: ok = False
    check(ok, f"{ruta}: SVG válido con viewBox")
ic = Image.open(os.path.join(RAIZ, "marca", "margia-icono-512.png")); check(ic.size == (512, 512) and ic.mode == "RGBA", "margia-icono-512.png: 512×512 con transparencia")
for n in ("margia-logo-horizontal.png", "margia-logo-horizontal-blanco.png"):
    im = Image.open(os.path.join(RAIZ, "marca", n)); check(im.height == 512 and im.width > 1200 and im.mode == "RGBA", f"{n}: {im.width}×{im.height} con transparencia")
datos = open(os.path.join(RAIZ, "marca", "margia.ico"), "rb").read(); cant = struct.unpack("<H", datos[4:6])[0]
tam = sorted((struct.unpack("<B", datos[6 + 16 * i: 7 + 16 * i])[0] or 256) for i in range(cant))
check(tam == [16, 24, 32, 48, 64, 128, 256], f"margia.ico trae los 7 tamaños: {tam}")
check(all(Image.open(io.BytesIO(datos[struct.unpack('<I', datos[6+16*i+12:6+16*i+16])[0]:][:struct.unpack('<I', datos[6+16*i+8:6+16*i+12])[0]])).size[0] == t for i, t in enumerate(tam)), "cada tamaño del .ico es realmente de ese tamaño")
check(open(os.path.join(RAIZ, "installer", "icono.ico"), "rb").read() == datos and open(os.path.join(RAIZ, "frontend", "img", "favicon.ico"), "rb").read() == datos, "el ícono del instalador y el favicon son el logo nuevo")
nombre_svg = re.findall(r'<svg class="nombre-svg"[^>]*aria-label="Margia"', leer("frontend", "index.html"))
check(len(nombre_svg) == 2, "el nombre en trazos está en la pantalla de inicio y en el menú")

print("Servidor, pantalla y tema")
database.init()
srv, host, puerto = server.crear_servidor(); threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/"
def pedir(ruta, cab=None):
    q = urllib.request.Request(URL + ruta, headers=cab or {})
    with urllib.request.urlopen(q) as r: return r.status, r.headers, r.read()
st, h, cuerpo = pedir("img/margia-icono.svg"); check(st == 200 and h["Content-Type"].startswith("image/svg+xml"), "el servidor entrega el logo SVG con su tipo correcto")
st, h, cuerpo = pedir("img/favicon.ico"); check(st == 200 and "icon" in h["Content-Type"], f"y el favicon ({h['Content-Type']})")
check("img-src 'self' data:" in h["Content-Security-Policy"], "la política de seguridad permite estas imágenes sin abrir nada más")
_, _, html = pedir(""); html = html.decode()
check("Margia" in html and "Conoce tu costo." in html and "Cuida tu margen." in html and "Cifra" not in html, "la página trae el nombre y la frase, sin el nombre anterior")
tok = json.loads(urllib.request.urlopen(urllib.request.Request(URL + "api/login", data=json.dumps({"username": "admin", "password": "admin123"}).encode(), headers={"Content-Type": "application/json"})).read())["token"]
meta = json.loads(pedir("api/meta", {"Authorization": "Bearer " + tok})[2]); check(meta["app"] == "Margia" and meta["lema"] == marca.LEMA, "/api/meta informa el nombre y la frase")
def post(ruta, cuerpo): return json.loads(urllib.request.urlopen(urllib.request.Request(URL + "api/" + ruta, data=json.dumps(cuerpo).encode(), headers={"Content-Type": "application/json", "Authorization": "Bearer " + tok})).read())
emp = post("empresas", {"codigo": "D", "razon_social": "Delipinchitos", "nit": "1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})["id"]
errores = []
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("pageerror", lambda e: errores.append(str(e))); pg.on("console", lambda m: m.type == "error" and errores.append(m.text))
    pg.goto(URL); time.sleep(0.6)
    check(pg.title() == "Margia — Costeo estándar", f"título de la pestaña: «{pg.title()}»")
    check("Conoce tu costo." in pg.inner_text(".login-marca") and "Cuida tu margen." in pg.inner_text(".login-marca"), "la pantalla de inicio muestra la frase")
    check(pg.evaluate("[...document.querySelectorAll('.login-marca img.logo-app')].every(i => i.complete && i.naturalWidth > 0)"), "el logo de la pantalla de inicio carga")
    check(pg.get_attribute("link[rel=icon]", "href") == "img/margia-icono.svg", "el ícono de la pestaña es el logo")
    pg.fill("#login-usuario", "admin"); pg.fill("#login-clave", "admin123"); pg.click("#form-login button[type=submit]")
    pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.6)
    if pg.is_visible("#modal-fondo:not(.oculto)"): pg.click("text=Más tarde"); time.sleep(0.3)
    check(pg.evaluate("document.querySelector('.lateral img.logo-app').naturalWidth") > 0, "el logo del menú carga")
    check("Margia 1.0.0" in pg.inner_text("#lateral-pie"), f"el pie del menú dice «{pg.inner_text('#lateral-pie')}»")
    def color_nombre(): return pg.evaluate("getComputedStyle(document.querySelector('.lateral .nombre-svg')).color")
    claro = color_nombre()
    post(f"empresas/{emp}/tema", {"tema": {"acento": "#0f766e", "lateral": "#0b2b29", "fondo": "#f6f7f9"}})
    pg.reload(); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
    oscuro = color_nombre(); canal = lambda c: [int(x) for x in re.findall(r"\d+", c)[:3]]
    check(sum(canal(claro)) < 200 and sum(canal(oscuro)) > 600, f"el nombre se adapta al tema del menú: oscuro sobre fondo claro {claro}, claro sobre fondo oscuro {oscuro}")
    check("· Margia" in pg.title(), f"con una empresa activa, la pestaña dice «{pg.title()}»")
    b.close()
srv.shutdown()
check(not errores, "sin errores de JavaScript ni de política de seguridad en la consola" + (f": {errores[:2]}" if errores else ""))

print("Quien venía de «Cifra» no pierde nada")
base_env = {k: v for k, v in os.environ.items() if not k.startswith(("CIFRA_", "MARGIA_"))}
def con_entorno(codigo, **extra):
    env = dict(base_env, **extra)
    return subprocess.run([sys.executable, "-c", f"import sys; sys.path.insert(0, {RAIZ!r}); from backend import settings; {codigo}"], capture_output=True, text=True, env=env).stdout.strip()
check(con_entorno("print(settings.puerto())", CIFRA_SERVIDOR_PUERTO="9123") == "9123", "una variable CIFRA_SERVIDOR_PUERTO de la versión anterior sigue funcionando")
check(con_entorno("print(settings.puerto())", CIFRA_SERVIDOR_PUERTO="9123", MARGIA_SERVIDOR_PUERTO="9456") == "9456", "y si están las dos, gana la nueva (MARGIA_)")
check(con_entorno("print(settings.clave_inicial_admin())", CIFRA_ADMIN_PASSWORD="clave-vieja-1") == "clave-vieja-1", "CIFRA_ADMIN_PASSWORD también se respeta")
check(con_entorno("print(settings.clave_inicial_admin())", MARGIA_ADMIN_PASSWORD="clave-nueva-1", CIFRA_ADMIN_PASSWORD="clave-vieja-1") == "clave-nueva-1", "y MARGIA_ADMIN_PASSWORD tiene prioridad")
def carpeta_datos(lad):  # simula una carpeta del programa donde Windows no deja escribir
    return con_entorno(f"settings.APP_DIR = '/dev/null/no_se_puede'; print(settings._carpeta_datos())", LOCALAPPDATA=lad)
lad = tempfile.mkdtemp(); check(carpeta_datos(lad) == os.path.join(lad, "Margia"), "sin datos previos, la carpeta alternativa se llama Margia")
lad = tempfile.mkdtemp(); os.makedirs(os.path.join(lad, "Cifra")); check(carpeta_datos(lad) == os.path.join(lad, "Cifra"), "si ya había datos en %LOCALAPPDATA%\\Cifra, se siguen usando (no se pierden)")
lad = tempfile.mkdtemp(); os.makedirs(os.path.join(lad, "Cifra")); os.makedirs(os.path.join(lad, "Margia")); check(carpeta_datos(lad) == os.path.join(lad, "Margia"), "si ya existe la nueva, manda la nueva")

padre = tempfile.mkdtemp(); vieja = os.path.join(padre, "cifra"); nueva = os.path.join(padre, "margia")
os.makedirs(os.path.join(vieja, "data")); os.makedirs(os.path.join(nueva, "data"))
guardado_db, guardado_app = database.db_path, settings.APP_DIR
try:
    database.db_path = lambda: os.path.join(vieja, "data", "costos.db"); database.init()
    c = database.connect(); c.execute("INSERT INTO empresas (codigo, razon_social, nit, moneda) VALUES ('VIEJA','Datos de la versión anterior','1','COP')"); c.commit(); c.close()
    database.db_path = lambda: os.path.join(nueva, "data", "costos.db"); settings.APP_DIR = nueva
    check(respaldos.base_anterior_cercana() == os.path.abspath(os.path.join(vieja, "data", "costos.db")), "una instalación nueva encuentra los datos de la carpeta «cifra» que tiene al lado")
    entrada, salida = builtins.input, io.StringIO(); esc = sys.stdout
    def responder(texto):
        builtins.input = lambda *a: texto; sys.stdout = salida
        try: server._ofrecer_datos_anteriores()
        finally: sys.stdout = esc; builtins.input = entrada
    responder(""); check(not os.path.isfile(database.db_path()), "si no se acepta (Enter), no se copia nada y se empieza vacío")
    def eof(*a): raise EOFError
    builtins.input = eof; sys.stdout = salida
    try: server._ofrecer_datos_anteriores()
    finally: sys.stdout = esc; builtins.input = entrada
    check(not os.path.isfile(database.db_path()), "sin consola (servicio, pruebas) tampoco copia y no se queda esperando")
    responder("s"); check(os.path.isfile(database.db_path()), "al aceptar, copia la base")
    c = sqlite3 = __import__("sqlite3").connect(database.db_path()); n = c.execute("SELECT COUNT(*) FROM empresas WHERE codigo='VIEJA'").fetchone()[0]; c.close()
    check(n == 1 and respaldos.verificar(database.db_path())[0], "con todos sus datos y sana")
    check(os.path.getsize(os.path.join(vieja, "data", "costos.db")) > 0 and "SE ENCONTRARON DATOS" in salida.getvalue(), "el original queda intacto y el programa explicó qué pasaba")
    n_antes = os.path.getsize(database.db_path()); responder("s"); check(os.path.getsize(database.db_path()) == n_antes, "si ya hay base en la carpeta nueva, no pregunta ni la pisa")
    open(os.path.join(vieja, "data", "costos.db"), "wb").write(b"no soy una base" * 50); os.remove(database.db_path())
    salida2 = io.StringIO(); sys.stdout = salida2; builtins.input = lambda *a: "s"
    try: server._ofrecer_datos_anteriores()
    finally: sys.stdout = esc; builtins.input = entrada
    check(not os.path.isfile(database.db_path()) and "no se pueden copiar" in salida2.getvalue(), "si la base anterior está dañada, avisa y no copia basura")
finally:
    database.db_path, settings.APP_DIR = guardado_db, guardado_app
print("RESULTADO:", "TODO OK" if not fallos else f"{len(fallos)} FALLOS: {fallos}")
sys.exit(1 if fallos else 0)
