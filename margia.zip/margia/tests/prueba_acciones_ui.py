"""Recorre con clics y teclado TODAS las acciones de escritura de la interfaz (crear, editar, quitar, eliminar, cerrar,
importar…), como las haría una persona. Además exige que ningún aviso de error salga vacío ni haya errores de JavaScript.
Usa una base de datos temporal: no toca data/costos.db."""
import base64, io, json, os, sys, tempfile, threading, time, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.db import database
_T = os.path.join(tempfile.mkdtemp(), "prueba.db"); database.db_path = lambda: _T
import backend.server as server
from playwright.sync_api import sync_playwright
from PIL import Image

database.init()
srv, host, puerto = server.crear_servidor()
threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/"
os.makedirs("capturas_prueba", exist_ok=True)

def call(m, r, b=None, t=None):
    q = urllib.request.Request(URL + "api/" + r, data=json.dumps(b).encode() if b is not None else None, method=m)
    q.add_header("Content-Type", "application/json")
    if t: q.add_header("Authorization", "Bearer " + t)
    with urllib.request.urlopen(q) as x: return json.loads(x.read())

errores, fallos = [], []
def check(cond, texto):
    (print("  ✓", texto) if cond else (fallos.append(texto), print("  ✗", texto)))

# ---------- datos de partida (por API) ----------
T = call("POST", "login", {"username": "admin", "password": "admin123"})["token"]
E = call("POST", "empresas", {"codigo": "DELI", "razon_social": "Delipinchitos SAS", "nit": "900123456-1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, T)["id"]
unidades = call("GET", "unidades_medida", None, T)
KG = next(u["id"] for u in unidades if u["codigo"] == "KG"); UND = next(u["id"] for u in unidades if u["codigo"] == "UND")
PER = call("POST", "periodos", {"codigo": "S26", "nombre": "Septiembre 2026", "fecha_inicio": "2026-09-01", "fecha_fin": "2026-09-30", "estado": "abierto", "unidades_presupuestadas": 3000, "empresa_id": E}, T)["id"]
MP1 = call("POST", "materias_primas", {"codigo": "MP01", "descripcion": "Marshmallows", "unidad_id": KG, "unidad_estandar_id": KG, "costo_estandar": 12000, "eficiencia_pct": 98, "empresa_id": E}, T)["id"]
MP2 = call("POST", "materias_primas", {"codigo": "MP02", "descripcion": "Chocolate blanco", "unidad_id": KG, "unidad_estandar_id": KG, "costo_estandar": 30000, "eficiencia_pct": 100, "empresa_id": E}, T)["id"]
TR = call("POST", "trabajadores", {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Repostera", "salario_mensual": 1423500, "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192, "empresa_id": E}, T)["id"]
BMOD = next(x["id"] for x in call("GET", f"bases_aplicacion?empresa_id={E}", None, T) if x["codigo"] == "mano_obra_directa")
KILOS = call("POST", "bases_aplicacion", {"codigo": "KILOS", "nombre": "Kilos procesados", "empresa_id": E}, T)["id"]
C1 = call("POST", "cif_conceptos", {"codigo": "CIF01", "descripcion": "Gas", "tipo": "variable", "base_aplicacion_id": BMOD, "presupuestado": 120000, "real": 0, "empresa_id": E}, T)["id"]
C2 = call("POST", "cif_conceptos", {"codigo": "CIF02", "descripcion": "Refrigeración", "tipo": "fijo", "base_aplicacion_id": KILOS, "presupuestado": 90000, "real": 0, "empresa_id": E}, T)["id"]
P1 = call("POST", "productos", {"codigo": "P01", "descripcion": "Pinchito de marshmallows", "unidad_id": UND, "precio_venta": 1500, "horas_mod_std": 0.0167, "horas_maquina_std": 0, "empresa_id": E}, T)["id"]
call("POST", f"receta/{P1}", {"materia_prima_id": MP1, "cantidad_estandar": 0.025, "empresa_id": E}, T)
call("POST", "inventario/movimientos", {"materia_prima_id": MP1, "tipo": "entrada", "cantidad": 40, "costo_unitario": 12000, "fecha": "2026-09-01", "empresa_id": E}, T)

Image.new("RGB", (40, 40), (190, 24, 93)).save("capturas_prueba/logo.png")

with sync_playwright() as p:
    nav = p.chromium.launch()
    ctx = nav.new_context(viewport={"width": 1440, "height": 1000}, accept_downloads=True)
    ctx.add_init_script("""window.__pagina = Math.random().toString(36).slice(2); window.__avisos = []; new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
        if (n.classList && n.classList.contains('mensaje')) window.__avisos.push({tipo: n.classList.contains('error') ? 'error' : 'ok', texto: n.textContent.trim()});
    }))).observe(document, {childList: true, subtree: true});""")
    pg = ctx.new_page()
    pg.on("pageerror", lambda ex: errores.append(f"pageerror: {ex}"))
    http = []
    pg.on("response", lambda r: r.status >= 400 and http.append((r.status, r.url.split('/api/')[-1].split('?')[0])))

    acumulado, vistos, pagina = [], [0], [None]
    def recoger():
        """Guarda los avisos mostrados hasta ahora. La lista se reinicia al recargar la página: se identifica cada página."""
        try: av, pid = pg.evaluate("[window.__avisos, window.__pagina]")
        except Exception: return
        if pid != pagina[0]: pagina[0], vistos[0] = pid, 0
        acumulado.extend(av[vistos[0]:]); vistos[0] = len(av)
    def ir(item): recoger(); pg.click(f"#menu button[data-item='{item}']"); time.sleep(0.6)
    def aviso(texto, tipo="ok", espera=1.0):
        fin = time.time() + espera
        while time.time() < fin:
            if any(a["tipo"] == tipo and texto in a["texto"] for a in pg.evaluate("window.__avisos")): return True
            time.sleep(0.1)
        return False
    def panel(titulo): return pg.locator(".panel", has_text=titulo)
    def confirmar(etiqueta):
        check(pg.inner_text("#modal .modal-acciones .primario") == etiqueta, f"el cuadro de confirmación dice «{etiqueta}»")
        pg.click("#modal .modal-acciones .primario"); time.sleep(0.8)
    def entrar(usuario, clave):
        recoger(); pg.goto(URL); pg.fill("#login-usuario", usuario); pg.fill("#login-clave", clave)
        pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
        if pg.is_visible("#modal-fondo:not(.oculto)"): pg.click("text=Más tarde"); time.sleep(0.3)

    entrar("admin", "admin123")
    check("1.0.0" in pg.inner_text("#lateral-pie"), "la versión de Margia se ve al pie del menú")

    print("ÓRDENES: crear, llenar, quitar, cerrar")
    ir("ordenes"); pg.click(".mod-cabeza >> text=Nueva orden"); time.sleep(0.4)
    pg.fill(".campo[data-campo=numero] input", "OP-001"); pg.fill(".campo[data-campo=fecha] input", "2026-09-10")
    pg.fill(".campo[data-campo=cantidad_planeada] input", "300"); pg.click("#btn-crear"); time.sleep(0.8)
    check("OP-001" in pg.inner_text("#contenido"), "la orden OP-001 aparece en la lista")
    pg.click("#contenido tbody tr:first-child >> text=Ver"); time.sleep(0.8)
    c = panel("Consumo real de materiales")
    c.locator("input").nth(0).fill("7.8"); c.locator("input").nth(1).fill("12200"); c.get_by_role("button", name="Agregar consumo").click(); time.sleep(0.7)
    check("7,8" in c.inner_text(), "consumo guardado y visible")
    c.locator("select").select_option(str(MP2)); c.locator("input").nth(0).fill("0.5"); c.locator("input").nth(1).fill("31000")
    c.get_by_role("button", name="Agregar consumo").click(); time.sleep(0.7)
    check("0,5" in c.inner_text(), "segundo consumo guardado")
    c.locator("tbody tr").nth(1).get_by_role("button", name="Quitar").click(); time.sleep(0.7)
    check(c.locator("tbody tr").count() == 1, "«Quitar» elimina el segundo consumo")
    m = panel("Horas de mano de obra"); m.locator("input").nth(0).fill("5"); m.locator("input").nth(1).fill("11300")
    m.get_by_role("button", name="Agregar registro").click(); time.sleep(0.7)
    check("11.300" in m.inner_text(), "horas de mano de obra guardadas")
    k = panel("CIF real de la orden"); k.locator("input").nth(0).fill("9000"); k.get_by_role("button", name="Agregar").click(); time.sleep(0.9)
    check("9.000" in panel("CIF real de la orden").inner_text(), "CIF real guardado")
    b = panel("Bases de aplicación personalizadas")
    check(b.count() == 1, "aparece la sección de bases personalizadas (hay una creada)")
    b.locator("input").nth(0).fill("7.8"); b.get_by_role("button", name="Agregar").click(); time.sleep(0.9)
    check("Kilos procesados" in panel("Bases de aplicación personalizadas").inner_text(), "base personalizada guardada")
    panel("Bases de aplicación personalizadas").get_by_role("button", name="Quitar").click(); time.sleep(0.7)
    check("Sin bases personalizadas" in panel("Bases de aplicación personalizadas").inner_text(), "base personalizada quitada")
    panel("Bases de aplicación personalizadas").locator("input").nth(0).fill("7.8"); panel("Bases de aplicación personalizadas").get_by_role("button", name="Agregar").click(); time.sleep(0.9)
    cierre = panel("Cerrar orden y calcular")
    cierre.locator("input").nth(0).fill("300")
    cierre.get_by_role("button", name="Cerrar orden").click(); time.sleep(0.5)
    confirmar("Cerrar orden")
    check(aviso("Orden cerrada"), "aviso «Orden cerrada»")
    check(pg.locator(".tarjetas-kpi").count() == 1 and "Variaciones" in pg.inner_text("#contenido"), "queda en la orden mostrando costo real y variaciones")
    check(pg.get_by_role("button", name="Agregar consumo").count() == 0, "una orden cerrada ya no ofrece editar")
    check("000.000.000" not in pg.inner_text("#contenido") and "base «Kilos procesados»" in pg.inner_text("#contenido"),
          "ninguna variación es una cifra absurda y se avisa que un CIF no se está aplicando")
    pg.screenshot(path="capturas_prueba/a1_orden_cerrada.png", full_page=True)

    print("ÓRDENES: eliminar una abierta y cierre con error")
    call("POST", "ordenes", {"numero": "OP-002", "producto_id": P1, "periodo_id": PER, "fecha": "2026-09-12", "cantidad_planeada": 100, "empresa_id": E}, T)
    ir("ordenes")
    fila = pg.locator("#contenido tbody tr", has_text="OP-002")
    fila.get_by_role("button", name="Ver").click(); time.sleep(0.7)
    panel("Cerrar orden y calcular").get_by_role("button", name="Cerrar orden").click(); time.sleep(0.4); confirmar("Cerrar orden")
    check(aviso("Cantidad producida", "error") or aviso("obligatorio", "error"), "cerrar sin cantidad producida: avisa qué falta")
    pg.click("text=← Volver a la lista"); time.sleep(0.7)

    print("ÓRDENES: código de autorización, editar, reabrir y eliminar")
    fila = lambda n: pg.locator("#contenido tbody tr", has_text=n)
    check(pg.locator(".aviso-info >> text=Crear el código ahora").count() == 1, "el administrador ve el aviso para crear el código")
    fila("OP-002").get_by_role("button", name="Eliminar").click(); time.sleep(0.5)
    check("Crear el código de autorización" in pg.inner_text("#modal") and aviso("Antes de corregir", "error"), "sin código creado, «Eliminar» lleva a crearlo")
    pg.fill("#modal .campo[data-campo=password] input", "admin123"); pg.fill("#modal .campo[data-campo=codigo] input", "Cod2026")
    pg.fill("#modal .campo[data-campo=repetir] input", "otro"); pg.click("#btn-guardar-codigo"); time.sleep(0.4)
    check("no coinciden" in pg.inner_text("#modal"), "avisa si los dos códigos no coinciden")
    pg.fill("#modal .campo[data-campo=repetir] input", "Cod2026"); pg.click("#btn-guardar-codigo"); time.sleep(1.0)
    check(aviso("Código de autorización guardado") and pg.locator(".aviso-info >> text=Crear el código ahora").count() == 0, "código creado: desaparece el aviso")
    fila("OP-002").get_by_role("button", name="Eliminar").click(); time.sleep(0.5)
    check(pg.inner_text("#modal .modal-acciones .primario") == "Eliminar orden" and "No se puede deshacer" in pg.inner_text("#modal"), "el cuadro advierte que no se puede deshacer y su botón dice «Eliminar orden»")
    pg.fill("#modal .campo[data-campo=codigo] input", "equivocado"); pg.click("#btn-autorizar"); time.sleep(0.8)
    check(aviso("no es correcto", "error") and "Código incorrecto" in pg.inner_text("#modal") and "OP-002" in pg.inner_text("#contenido"), "código incorrecto: lo dice junto al campo y la orden sigue ahí")
    pg.fill("#modal .campo[data-campo=codigo] input", "Cod2026"); pg.fill("#modal .campo[data-campo=motivo] input", "Orden de prueba"); pg.click("#btn-autorizar"); time.sleep(1.1)
    check("OP-002" not in pg.inner_text("#contenido") and "OP-001" in pg.inner_text("#contenido"), "con el código correcto se elimina la orden abierta; la otra se queda")
    call("POST", "ordenes", {"numero": "OP-004", "producto_id": P1, "periodo_id": PER, "fecha": "2026-09-14", "cantidad_planeada": 50, "empresa_id": E}, T)
    ir("ordenes"); fila("OP-004").get_by_role("button", name="Editar").click(); time.sleep(0.5)
    pg.fill("#modal .campo[data-campo=cantidad_planeada] input", "75"); pg.fill("#modal .campo[data-campo=codigo] input", "Cod2026"); pg.click("#btn-autorizar"); time.sleep(1.1)
    check(aviso("Orden actualizada") and "75" in fila("OP-004").inner_text(), "editar una orden abierta cambia sus datos")
    fila("OP-001").get_by_role("button", name="Reabrir").click(); time.sleep(0.5)
    check("vuelve a la bodega" in pg.inner_text("#modal"), "reabrir explica qué pasa con el inventario")
    pg.fill("#modal .campo[data-campo=codigo] input", "Cod2026"); pg.fill("#modal .campo[data-campo=motivo] input", "Faltó un consumo"); pg.click("#btn-autorizar"); time.sleep(1.3)
    check(pg.get_by_role("button", name="Agregar consumo").count() == 1 and "Editar datos" in pg.inner_text("#contenido"), "reabrir lleva a la orden, ya editable")
    check(panel("Cerrar orden y calcular").locator("input").nth(0).input_value() == "300", "el formulario de cierre conserva la cantidad producida (300)")
    check(pg.locator("#contenido .botones-cabeza >> text=Eliminar").count() == 1, "en la orden también está el botón «Eliminar»")
    panel("Cerrar orden y calcular").get_by_role("button", name="Cerrar orden").click(); time.sleep(0.4); confirmar("Cerrar orden")
    check(pg.locator(".tarjetas-kpi").count() == 1 and pg.get_by_role("button", name="Agregar consumo").count() == 0 and "Reabrir orden" in pg.inner_text("#contenido"),
          "se vuelve a cerrar y muestra el costo real (con la opción de reabrir)")

    print("HOJA DE COSTO: receta y bases personalizadas")
    ir("hoja_costo")
    r = panel("Materiales de la receta"); r.locator("select").select_option(str(MP2)); r.locator("input[type=number]").fill("0.01")
    r.get_by_role("button", name="Agregar a la receta").click(); time.sleep(0.9)
    check(panel("Materiales de la receta").locator("tr", has_text="Chocolate").count() == 1, "material agregado a la receta (aparece como fila)")
    panel("Materiales de la receta").locator("input[type=number]").fill("0.02")
    panel("Materiales de la receta").get_by_role("button", name="Agregar a la receta").click(); time.sleep(0.7)
    check(aviso("ya está", "error") or aviso("Ya está", "error"), "agregar un material repetido: avisa con texto")
    panel("Materiales de la receta").locator("tr", has_text="Chocolate").get_by_role("button", name="Quitar").click(); time.sleep(0.4)
    confirmar("Quitar")
    check(panel("Materiales de la receta").locator("tr", has_text="Chocolate").count() == 0, "material quitado de la receta (ya no hay fila)")
    bp = panel("Bases de aplicación personalizadas")
    bp.locator("input[type=number]").fill("0.2"); bp.get_by_role("button", name="Agregar").click(); time.sleep(0.9)
    check("0,2" in panel("Bases de aplicación personalizadas").inner_text(), "consumo estándar de la base personalizada guardado")
    panel("Bases de aplicación personalizadas").get_by_role("button", name="Quitar").click(); time.sleep(0.7)
    check("Sin bases personalizadas" in panel("Bases de aplicación personalizadas").inner_text(), "consumo de la base quitado")

    print("DATOS GENERALES: editar, eliminar y errores")
    ir("periodos"); pg.locator("#contenido tbody tr").first.get_by_role("button", name="Editar").click(); time.sleep(0.4)
    pg.fill(".campo[data-campo=unidades_presupuestadas] input", "3500"); pg.click("#btn-guardar"); time.sleep(0.8)
    check(aviso("Cambios guardados") and call("GET", f"periodos?empresa_id={E}", None, T)[0]["unidades_presupuestadas"] == 3500, "editar un periodo guarda el cambio en la base de datos")
    ir("unidades_medida")
    pg.locator("#contenido tbody tr", has_text="Kilogramo").get_by_role("button", name="Eliminar").click(); time.sleep(0.4); confirmar("Eliminar")
    check(aviso("dependen", "error") or aviso("depend", "error"), "eliminar una unidad en uso: explica por qué no se puede")
    pg.click(".mod-cabeza >> text=Nueva unidad"); time.sleep(0.4)
    pg.fill(".campo[data-campo=codigo] input", "CAJA"); pg.fill(".campo[data-campo=nombre] input", "Caja"); pg.fill(".campo[data-campo=abreviatura] input", "cj")
    pg.click("#btn-guardar"); time.sleep(0.8)
    pg.locator("#contenido tbody tr", has_text="CAJA").get_by_role("button", name="Eliminar").click(); time.sleep(0.4); confirmar("Eliminar")
    check("CAJA" not in pg.inner_text("#contenido"), "eliminar una unidad sin uso funciona")
    ir("centros_costo"); pg.click(".mod-cabeza >> text=Nuevo centro de costo"); time.sleep(0.4)
    pg.click("#btn-guardar"); time.sleep(0.5)
    check("obligatorio" in pg.inner_text("#modal"), "guardar un formulario vacío: marca los campos obligatorios")
    pg.click("#modal >> text=Cancelar")

    print("EMPRESA: logo y colores")
    ir("empresas")
    pg.locator("#contenido tbody tr").first.get_by_role("button", name="Agregar logo").click(); time.sleep(0.4)
    pg.set_input_files("#modal input[type=file]", "capturas_prueba/logo.png"); time.sleep(0.5)
    pg.click("#btn-guardar-logo"); time.sleep(1.0)
    check(aviso("Logo actualizado") and pg.locator("#lateral-icono img").count() == 1, "el logo se guarda y aparece junto al nombre de la empresa")
    pg.locator("#contenido tbody tr").first.get_by_role("button", name="Colores").click(); time.sleep(0.4)
    pg.locator("#modal input[type=color]").nth(0).fill("#b45309"); pg.click("#btn-guardar-tema"); time.sleep(1.0)
    check(aviso("Colores actualizados") and pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--acento').trim()") == "#b45309", "los colores se guardan y se aplican a toda la interfaz")
    pg.locator("#contenido tbody tr").first.get_by_role("button", name="Colores").click(); time.sleep(0.4)
    pg.click("#btn-restablecer-tema"); time.sleep(1.0)
    check(pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--acento').trim()") == "#0f766e", "«Restablecer» vuelve a los colores originales")

    print("USUARIOS: crear con permisos, editar, probar y eliminar")
    ir("usuarios"); pg.click(".mod-cabeza >> text=Nuevo usuario"); time.sleep(0.4)
    pg.fill(".campo[data-campo=username] input", "maria"); pg.fill(".campo[data-campo=nombre] input", "María Gómez"); pg.fill(".campo[data-campo=password] input", "maria2026")
    pg.check("#perm-ordenes"); pg.click("#btn-guardar"); time.sleep(0.9)
    check("maria" in pg.inner_text("#contenido") and "Producción" in pg.inner_text("#contenido"), "usuario creado con el permiso de producción")
    pg.locator("#contenido tbody tr", has_text="maria").get_by_role("button", name="Editar").click(); time.sleep(0.4)
    pg.check("#perm-inventario"); pg.click("#btn-guardar"); time.sleep(0.9)
    check("Inventario" in pg.inner_text("#contenido"), "editar agrega el permiso de inventario")
    recoger(); pg.click("#btn-salir"); time.sleep(0.8); entrar("maria", "maria2026")
    ir("ordenes")
    check(pg.locator(".mod-cabeza >> text=Nueva orden").count() == 1, "la usuaria con permiso ve «Nueva orden»")
    ir("productos")
    check(pg.locator(".mod-cabeza >> text=Nuevo producto").count() == 0, "pero no ve «Nuevo producto» (sin permiso)")
    ir("ordenes"); pg.click(".mod-cabeza >> text=Nueva orden"); time.sleep(0.4)
    pg.fill(".campo[data-campo=numero] input", "OP-003"); pg.fill(".campo[data-campo=fecha] input", "2026-09-15"); pg.fill(".campo[data-campo=cantidad_planeada] input", "50")
    pg.click("#btn-crear"); time.sleep(0.8)
    pg.locator("#contenido tbody tr", has_text="OP-003").get_by_role("button", name="Ver").click(); time.sleep(0.7)
    c = panel("Consumo real de materiales"); c.locator("input").nth(0).fill("1"); c.locator("input").nth(1).fill("12000")
    c.get_by_role("button", name="Agregar consumo").click(); time.sleep(0.8)
    check("12.000" in c.inner_text(), "la usuaria llena una orden y se guarda")
    check(pg.locator(".mod-cabeza >> text=Código de autorización").count() == 0, "la usuaria no ve el botón para cambiar el código (solo el administrador)")
    pg.click("text=← Volver a la lista"); time.sleep(0.7)
    pg.locator("#contenido tbody tr", has_text="OP-003").get_by_role("button", name="Eliminar").click(); time.sleep(0.5)
    pg.fill("#modal .campo[data-campo=codigo] input", "no-lo-se"); pg.click("#btn-autorizar"); time.sleep(0.8)
    check(aviso("no es correcto", "error") and "OP-003" in pg.inner_text("#contenido"), "sin conocer el código, no puede eliminar")
    pg.click("#modal >> text=Cancelar")
    recoger(); pg.click("#btn-salir"); time.sleep(0.8); entrar("admin", "admin123")
    ir("usuarios")
    pg.locator("#contenido tbody tr", has_text="maria").get_by_role("button", name="Eliminar").click(); time.sleep(0.4); confirmar("Eliminar")
    check("maria" not in pg.inner_text("#contenido"), "usuario eliminado")

    print("INVENTARIO: kardex, salida y eliminar movimiento")
    ir("inventario"); pg.click(".mod-cabeza >> text=Registrar movimiento"); time.sleep(0.4)
    pg.select_option(".campo[data-campo=tipo] select", "salida"); pg.fill(".campo[data-campo=cantidad] input", "9999"); pg.click("#btn-mov"); time.sleep(0.7)
    check(aviso("No hay suficientes existencias", "error"), "sacar más de lo que hay: avisa cuánto queda")
    pg.fill(".campo[data-campo=cantidad] input", "2"); pg.click("#btn-mov"); time.sleep(0.9)
    pg.locator("#contenido tbody tr").first.get_by_role("button", name="Kardex").click(); time.sleep(0.7)
    n = pg.locator("#contenido tbody tr").count()
    pg.locator("#contenido tbody tr", has_text="Salida").filter(has_not_text="orden").first.get_by_role("button", name="Eliminar").click(); time.sleep(0.4); confirmar("Eliminar")
    check(pg.locator("#contenido tbody tr").count() == n - 1, "se elimina el movimiento manual")

    print("RESPALDO: descargar y restaurar")
    ir("respaldo")
    with pg.expect_download() as d: pg.click("text=Descargar respaldo ahora")
    ruta = "capturas_prueba/respaldo.db"; open(ruta, "wb").write(open(d.value.path(), "rb").read())
    call("POST", "periodos", {"codigo": "TEMP", "nombre": "Se perderá", "fecha_inicio": "2026-10-01", "fecha_fin": "2026-10-31", "estado": "abierto", "unidades_presupuestadas": 1, "empresa_id": E}, T)
    pg.set_input_files("input[type=file][accept='.db']", ruta); time.sleep(0.5); confirmar("Restaurar"); recoger(); time.sleep(2.2)
    pg.wait_for_load_state("load"); time.sleep(1.0)
    if pg.is_visible("#pantalla-login"): entrar("admin", "admin123")
    pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.6)
    ir("periodos")
    check("Se perderá" not in pg.inner_text("#contenido") and "Septiembre 2026" in pg.inner_text("#contenido"), "restaurar devuelve los datos al momento del respaldo")

    recoger()
    todos = [a for a in acumulado if a["tipo"] == "error"]
    vacios = [a for a in todos if not a["texto"]]
    print("AVISOS DE ERROR")
    check(len(todos) == 8, f"se provocaron {len(todos)} errores a propósito durante el recorrido (se esperaban 8)")
    check(len(vacios) == 0, "ninguno de esos avisos de error salió vacío")
    for a in todos: print("      •", a["texto"][:110])
    nav.close()
srv.shutdown()
print("ERRORES JS:", errores or "ninguno")
print("FALLOS:", fallos or "ninguno")
