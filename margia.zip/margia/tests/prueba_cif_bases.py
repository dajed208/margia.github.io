"""CIF con bases sin consumo cargado: nunca debe producir cifras absurdas y siempre debe avisar. Sin navegador, base temporal."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.db import database
_T = os.path.join(tempfile.mkdtemp(), "p.db"); database.db_path = lambda: _T
from backend import api, produccion
database.init(); con = database.connect()
ADMIN = {"id": 1, "username": "admin", "nombre": "Admin", "rol": "administrador"}
fallos = []
def check(c, t): print(("  ✓ " if c else "  ✗ ") + t); (not c) and fallos.append(t)
def ent(m, e, b, rid=None, q=None): return api.entidad(api.Ctx(m, [e] + ([str(rid)] if rid else []), q or {}, b, None, ADMIN), con)
def hoja(eid, pid, per): return api.hoja_costo(api.Ctx("GET", [], {"empresa_id": eid, "producto_id": pid, "periodo_id": per}, {}, None, ADMIN), con)

E = ent("POST", "empresas", {"codigo": "E", "razon_social": "E", "nit": "1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})["id"]
und = con.execute("SELECT id FROM unidades_medida WHERE codigo='UND'").fetchone()[0]
per = ent("POST", "periodos", {"codigo": "P", "nombre": "P", "fecha_inicio": "2026-09-01", "fecha_fin": "2026-09-30", "estado": "abierto", "unidades_presupuestadas": 1000, "empresa_id": E})["id"]
mp = ent("POST", "materias_primas", {"codigo": "M", "descripcion": "M", "unidad_id": und, "unidad_estandar_id": und, "costo_estandar": 100, "eficiencia_pct": 100, "empresa_id": E})["id"]
p1 = ent("POST", "productos", {"codigo": "P1", "descripcion": "P1", "unidad_id": und, "precio_venta": 1000, "horas_mod_std": 0, "horas_maquina_std": 0, "empresa_id": E})["id"]
api.receta(api.Ctx("POST", ["receta", str(p1)], {"empresa_id": E}, {"materia_prima_id": mp, "cantidad_estandar": 1, "empresa_id": E}, None, ADMIN), con)
bases = {b["codigo"]: b["id"] for b in ent("GET", "bases_aplicacion", {}, q={"empresa_id": E})}
kilos = ent("POST", "bases_aplicacion", {"codigo": "KILOS", "nombre": "Kilos procesados", "empresa_id": E})["id"]
cif = lambda cod, desc, base, pres, tipo="fijo": ent("POST", "cif_conceptos", {"codigo": cod, "descripcion": desc, "tipo": tipo, "base_aplicacion_id": base, "presupuestado": pres, "real": 0, "empresa_id": E})["id"]
cif("C1", "Arriendo", bases["unidades_producidas"], 90000)     # 90.000 / 1.000 unidades = 90 por unidad
cif("C2", "Refrigeración", kilos, 50000)                        # base personalizada SIN consumo cargado
cif("C3", "Gas", bases["mano_obra_directa"], 30000, "variable")  # base de MOD, pero el producto tiene 0 horas

print("Hoja de costo con bases sin consumo")
h = hoja(E, p1, per)
check(h["costo_cif"] == 90.0, f"el CIF aplicado es solo el del arriendo: $ {h['costo_cif']} (90.000 ÷ 1.000 unidades)")
tasas = {c["codigo"]: c["tasa"] for c in h["cif"]}
check(tasas["C2"] == 0 and tasas["C3"] == 0, f"las bases sin consumo tienen tasa 0, no una cifra absurda: {tasas}")
check(h["total"] == 190.0, f"costo estándar = materiales 100 + CIF 90 = $ {h['total']}")
av = h["advertencias_cif"]
check(len(av) == 2 and any("Refrigeración" in a and "Bases de aplicación personalizadas" in a for a in av) and any("Gas" in a and "«Productos»" in a for a in av),
      f"avisa de los 2 conceptos que no se aplican, con dónde corregirlo ({len(av)} avisos)")

print("Orden de producción y cierre")
o = produccion.crear(api.Ctx("POST", [], {}, {"numero": "OP", "producto_id": p1, "periodo_id": per, "fecha": "2026-09-10", "cantidad_planeada": 100, "empresa_id": E}, None, ADMIN), con)["id"]
cx = lambda b: api.Ctx("POST", [], {}, dict(b, empresa_id=E), None, ADMIN)
produccion.agregar_consumo(cx({"materia_prima_id": mp, "cantidad_real": 100, "precio_real": 100}), con, o)
produccion.agregar_base_real(cx({"base_id": kilos, "cantidad_real": 7.8}), con, o)
d = produccion.detalle(api.Ctx("GET", [], {"empresa_id": E}, {}, None, ADMIN), con, o)
check(len(d["advertencias"]) == 2, "la orden abierta ya muestra los 2 avisos, antes de cerrarla")
r = produccion.cerrar(cx({"cantidad_producida": 100}), con, o)
var = {v["tipo"]: v["monto"] for v in r["variaciones"]}
check(all(abs(m) < 1e6 for m in var.values()), f"ninguna variación es absurda: {var}")
check(var["volumen_cif"] == 0, f"variación de volumen CIF = {var['volumen_cif']} (el arriendo fijo se aplicó al volumen planeado)")
check(r["costo_real"]["costo_cif"] == 0, "el CIF real es 0: no se registró CIF real en la orden")
check(len(r["advertencias"]) == 2, "la orden cerrada conserva los avisos")

print("Al cargar el consumo estándar, el aviso desaparece y el CIF se aplica")
api.producto_base(api.Ctx("POST", ["producto-base", str(p1)], {"empresa_id": E}, {"base_id": kilos, "cantidad_estandar": 0.2, "empresa_id": E}, None, ADMIN), con)
h = hoja(E, p1, per)
tasa = {c["codigo"]: c["tasa"] for c in h["cif"]}["C2"]
check(abs(tasa - 250.0) < 0.01, f"tasa de Refrigeración = 50.000 ÷ (0,2 kg × 1.000 unidades) = {tasa} por kilo")
check(abs(h["costo_cif"] - 140.0) < 0.01, f"CIF aplicado = 90 + 250 × 0,2 = $ {h['costo_cif']}")
check(len(h["advertencias_cif"]) == 1 and "Gas" in h["advertencias_cif"][0], "queda solo el aviso del Gas (sigue sin horas de MOD)")
print("RESULTADO:", "TODO OK" if not fallos else f"{len(fallos)} FALLOS")
sys.exit(1 if fallos else 0)
