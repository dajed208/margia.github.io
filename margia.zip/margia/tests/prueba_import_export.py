"""Ida y vuelta de importación/exportación en Excel para los 10 módulos (sin navegador).

Exporta una empresa completa, la importa en otra empresa vacía y compara; luego reimporta sobre la
original con «actualizar» para comprobar que no se duplica nada y que las órdenes cerradas no cambian.
Usa una base de datos temporal: no toca data/costos.db.
"""
import base64, io, os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import openpyxl
from backend.db import database
_TMP = os.path.join(tempfile.mkdtemp(), "prueba.db"); database.db_path = lambda: _TMP
from backend import api, importar, produccion

database.init(); con = database.connect()
ADMIN = {"id": 1, "username": "admin", "nombre": "Administrador", "rol": "administrador"}
fallos = []
def check(cond, txt):
    print(("  ✓ " if cond else "  ✗ ") + txt)
    if not cond: fallos.append(txt)
def llamar(fn, *args, body=None, q=None):
    return fn(api.Ctx("POST", [], q or {}, body or {}, None, ADMIN), con, *args)
def crear(ent, datos, eid=None):
    b = dict(datos, empresa_id=eid) if eid else dict(datos)
    return api.entidad(api.Ctx("POST", [ent], {}, b, None, ADMIN), con)["id"]
def exportar(ent, eid):
    return importar.exportar(api.Ctx("GET", [], {"empresa_id": eid}, {}, None, ADMIN), con, ent)[1]
def importar_(ent, data, eid, actualizar=False, solo_revisar=False, codigo=None):
    b = {"archivo": base64.b64encode(data).decode(), "empresa_id": eid, "actualizar": actualizar}
    if codigo: b["codigo"] = codigo  # actualizar órdenes existentes exige el código de autorización del administrador
    fn = importar.revisar if solo_revisar else importar.confirmar
    return fn(api.Ctx("POST", [], {"empresa_id": eid}, b, None, ADMIN), con, ent)
def contar(sql, *p): return con.execute(sql, p).fetchone()[0]

# ---------- empresa A con datos completos ----------
A = crear("empresas", {"codigo": "DELI", "razon_social": "Delipinchitos SAS", "nit": "900123456-1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})
kg = con.execute("SELECT id FROM unidades_medida WHERE codigo='KG'").fetchone()[0]
und = con.execute("SELECT id FROM unidades_medida WHERE codigo='UND'").fetchone()[0]
crear("periodos", {"codigo": "2026", "nombre": "Año 2026", "fecha_inicio": "2026-01-01", "fecha_fin": "2026-12-31", "estado": "abierto", "unidades_presupuestadas": 2000}, A)
cc = crear("centros_costo", {"codigo": "CC01", "nombre": "Cocina", "tipo": "produccion"}, A)
p1 = crear("productos", {"codigo": "P01", "descripcion": "Pincho de pollo", "unidad_id": und, "precio_venta": 6500, "horas_mod_std": 0.05, "horas_maquina_std": 0.01}, A)
crear("productos", {"codigo": "P02", "descripcion": "Pincho de res", "unidad_id": und, "precio_venta": 7500, "horas_mod_std": 0.06, "horas_maquina_std": 0}, A)
m1 = crear("materias_primas", {"codigo": "MP01", "descripcion": "Pechuga de pollo", "unidad_id": kg, "unidad_estandar_id": kg, "costo_estandar": 14000, "proveedor": "Avícola", "eficiencia_pct": 95, "stock_minimo": 10}, A)
m2 = crear("materias_primas", {"codigo": "MP02", "descripcion": "Palitos", "unidad_id": und, "unidad_estandar_id": und, "costo_estandar": 40, "eficiencia_pct": 100}, A)
t1 = crear("trabajadores", {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Operaria", "salario_mensual": 1423500, "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192}, A)
kilos = crear("bases_aplicacion", {"codigo": "KILOS", "nombre": "Kilos procesados"}, A)
bmod = con.execute("SELECT id FROM bases_aplicacion WHERE empresa_id=? AND codigo='mano_obra_directa'", (A,)).fetchone()[0]
c1 = crear("cif_conceptos", {"codigo": "CIF01", "descripcion": "Energía", "centro_costo_id": cc, "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 600000, "real": 0}, A)
crear("cif_conceptos", {"codigo": "CIF02", "descripcion": "Refrigeración", "tipo": "fijo", "base_aplicacion_id": kilos, "presupuestado": 300000, "real": 0}, A)
for pid, mid, q in ((p1, m1, 0.12), (p1, m2, 1)):
    api.receta(api.Ctx("POST", ["receta", str(pid)], {"empresa_id": A}, {"materia_prima_id": mid, "cantidad_estandar": q, "empresa_id": A}, None, ADMIN), con)
per = con.execute("SELECT id FROM periodos WHERE empresa_id=?", (A,)).fetchone()[0]
def orden(num, cerrar):
    o = produccion.crear(api.Ctx("POST", [], {}, {"numero": num, "producto_id": p1, "periodo_id": per, "fecha": "2026-03-05", "cantidad_planeada": 200, "empresa_id": A}, None, ADMIN), con)["id"]
    cx = lambda b: api.Ctx("POST", [], {}, dict(b, empresa_id=A), None, ADMIN)
    produccion.agregar_consumo(cx({"materia_prima_id": m1, "cantidad_real": 25.5, "precio_real": 14200}), con, o)
    produccion.agregar_consumo(cx({"materia_prima_id": m2, "cantidad_real": 205, "precio_real": 40}), con, o)
    produccion.agregar_mod(cx({"trabajador_id": t1, "horas_reales": 11, "tarifa_real": 11500}), con, o)
    produccion.agregar_cif_real(cx({"concepto_id": c1, "monto_real": 70000}), con, o)
    if cerrar:
        produccion.cerrar(cx({"cantidad_producida": 200}), con, o)
    return o
orden("OP-001", True); o2 = orden("OP-002", False)

MODULOS = ["unidades_medida", "periodos", "centros_costo", "productos", "materias_primas", "trabajadores", "bases_aplicacion", "cif_conceptos", "recetas", "ordenes"]

print("Plantillas: cada una se abre y su fila de ejemplo es válida")
B0 = crear("empresas", {"codigo": "PLANT", "razon_social": "Prueba plantillas", "nit": "1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})
for ent in ["empresas"] + MODULOS:
    nombre, data = importar.plantilla(api.Ctx("GET", [], {"empresa_id": B0}, {}, None, ADMIN), con, ent)
    r = importar_(ent, data, B0, solo_revisar=True)
    esperado_error = ent in ("recetas", "ordenes")  # su ejemplo cita productos que esta empresa vacía aún no tiene
    check(nombre.endswith(".xlsx") and (r["con_error"] > 0 if esperado_error else r["con_error"] == 0),
          f"{nombre}: {r['crear']} para crear, {r['con_error']} con error" + (" (esperado: la empresa está vacía)" if esperado_error else ""))

print("Exportar la empresa A e importarla en una empresa B vacía")
archivos = {ent: exportar(ent, A) for ent in MODULOS}
B = crear("empresas", {"codigo": "COPIA", "razon_social": "Copia de prueba", "nit": "2", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})
for ent in MODULOS:
    actualizar = ent in ("unidades_medida", "bases_aplicacion")  # ya existen (globales / incorporadas)
    r = importar_(ent, archivos[ent], B, actualizar=actualizar)
    print(f"    {ent:17} → {r}")
tablas = {"periodos": "periodos", "centros_costo": "centros_costo", "productos": "productos", "materias_primas": "materias_primas",
          "trabajadores": "trabajadores", "bases_aplicacion": "bases_aplicacion", "cif_conceptos": "cif_conceptos", "ordenes": "ordenes_produccion"}
for ent, tabla in tablas.items():
    a, b = contar(f"SELECT COUNT(*) FROM {tabla} WHERE empresa_id=?", A), contar(f"SELECT COUNT(*) FROM {tabla} WHERE empresa_id=?", B)
    check(a == b, f"{ent}: {a} en A, {b} en B")
rec = lambda e: contar("SELECT COUNT(*) FROM receta_producto r JOIN productos p ON p.id=r.producto_id WHERE p.empresa_id=?", e)
check(rec(A) == rec(B) == 2, f"recetas: {rec(A)} en A, {rec(B)} en B")
det = lambda t, e: contar(f"SELECT COUNT(*) FROM {t} d JOIN ordenes_produccion o ON o.id=d.orden_id WHERE o.empresa_id=?", e)
for t in ("consumo_mp", "horas_mod", "cif_real_orden"):
    check(det(t, A) == det(t, B), f"{t}: {det(t, A)} en A, {det(t, B)} en B")
fila = lambda e: con.execute("SELECT c.presupuestado, cc.codigo cc, b.codigo base FROM cif_conceptos c LEFT JOIN centros_costo cc ON cc.id=c.centro_costo_id "
                             "JOIN bases_aplicacion b ON b.id=c.base_aplicacion_id WHERE c.empresa_id=? AND c.codigo='CIF01'", (e,)).fetchone()
check(tuple(fila(A)) == tuple(fila(B)), f"CIF01 conserva centro de costo y base: {tuple(fila(B))}")
tarifa = lambda e: con.execute("SELECT tarifa_std_hora FROM trabajadores WHERE empresa_id=?", (e,)).fetchone()[0]
check(tarifa(A) == tarifa(B), f"tarifa estándar recalculada igual: {tarifa(B)}")
h = lambda e: api.hoja_costo(api.Ctx("GET", [], {"empresa_id": e, "producto_id": con.execute("SELECT id FROM productos WHERE empresa_id=? AND codigo='P01'", (e,)).fetchone()[0]}, {}, None, ADMIN), con)["total"]
check(h(A) == h(B), f"el costo estándar de P01 es idéntico en ambas empresas: $ {h(B)}")
fechas = lambda e: con.execute("SELECT fecha_inicio, fecha_fin FROM periodos WHERE empresa_id=?", (e,)).fetchone()
check(tuple(fechas(A)) == tuple(fechas(B)), f"fechas del periodo conservadas: {tuple(fechas(B))}")

print("Reimportar sobre la empresa A con «actualizar»")
antes = {t: det(t, A) for t in ("consumo_mp", "horas_mod", "cif_real_orden")}
r = importar_("ordenes", archivos["ordenes"], A, actualizar=True, solo_revisar=True)
check(r["actualizar"] >= 1 and r["omitir"] >= 1 and r["con_error"] == 0, f"vista previa: {r['actualizar']} actualizar, {r['omitir']} omitidas (orden cerrada), {r['con_error']} errores")
produccion.configurar_codigo(api.Ctx("POST", [], {}, {"password": "admin123", "codigo": "Cod2026"}, None, ADMIN), con)
try:
    importar_("ordenes", archivos["ordenes"], A, actualizar=True); check(False, "actualizar órdenes sin código debía rechazarse")
except api.ApiError as e:
    check("código" in e.mensaje.lower(), "actualizar órdenes existentes sin el código del administrador se rechaza")
importar_("ordenes", archivos["ordenes"], A, actualizar=True, codigo="Cod2026")
check({t: det(t, A) for t in antes} == antes, f"no se duplican consumos, horas ni CIF real: {antes}")
check(contar("SELECT COUNT(*) FROM variaciones v JOIN ordenes_produccion o ON o.id=v.orden_id WHERE o.numero='OP-001' AND o.empresa_id=?", A) > 0,
      "la orden cerrada conserva sus variaciones")
for ent in MODULOS[:-1]:
    r = importar_(ent, archivos[ent], A, actualizar=True)
    check(r["creadas"] == 0 and r["omitidas"] == 0, f"{ent}: reimportar solo actualiza ({r})")

print("Errores comunes")
wb = openpyxl.load_workbook(io.BytesIO(archivos["recetas"])); ws = wb.active
ws.append(["P99", "MP01", 1]); ws.append(["P02", "MP02", -2])
b = io.BytesIO(); wb.save(b)
r = importar_("recetas", b.getvalue(), A, solo_revisar=True)
errs = " | ".join(e for f in r["filas"] for e in f["errores"])
check("«P99» no existe" in errs and "negativo" in errs and "repetida" not in errs, "recetas: producto inexistente y cantidad negativa explicados")
wb = openpyxl.load_workbook(io.BytesIO(archivos["ordenes"])); wb["Consumo de materiales"].append(["OP-777", "MP01", 1, 1])
b = io.BytesIO(); wb.save(b)
r = importar_("ordenes", b.getvalue(), A, actualizar=True, solo_revisar=True)
check(any("OP-777" in e and "no está en la hoja" in e for f in r["filas"] for e in f["errores"]), "órdenes: un consumo de una orden inexistente se señala")
print("Bases incorporadas")
antes_costo = h(A)
api.entidad(api.Ctx("PUT", ["bases_aplicacion", str(bmod)], {}, {"codigo": "mano_obra_directa", "nombre": "Horas de MOD", "empresa_id": A}, None, ADMIN), con)
cod = con.execute("SELECT codigo, nombre FROM bases_aplicacion WHERE id=?", (bmod,)).fetchone()
check(tuple(cod) == ("mano_obra_directa", "Horas de MOD") and h(A) == antes_costo, f"renombrar una base incorporada no cambia su código ni el costo ({tuple(cod)})")
con.execute("UPDATE bases_aplicacion SET codigo='MANO_OBRA_DIRECTA' WHERE id=?", (bmod,)); con.commit()  # daño de versiones anteriores
database._migrar(con)
check(con.execute("SELECT codigo FROM bases_aplicacion WHERE id=?", (bmod,)).fetchone()[0] == "mano_obra_directa" and h(A) == antes_costo,
      "la migración repara un código dañado y el costo vuelve a ser el correcto")
check(contar("SELECT COUNT(*) FROM bases_aplicacion WHERE empresa_id=?", A) == 4, "sin bases duplicadas tras la reparación")
print("Archivos guardados por Excel y archivos dañados")
import re, warnings, zipfile
C = crear("empresas", {"codigo": "EXC", "razon_social": "Prueba Excel", "nit": "3", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"})
_, plantilla = importar.plantilla(api.Ctx("GET", [], {"empresa_id": C}, {}, None, ADMIN), con, "productos")
EXT = ('<extLst><ext uri="{CCE6A557-97BC-4b89-ADB6-D9C93CAAB3DF}" xmlns:x14="http://schemas.microsoft.com/office/spreadsheetml/2009/9/main">'
       '<x14:dataValidations count="1" xmlns:xm="http://schemas.microsoft.com/office/excel/2006/main"><x14:dataValidation type="list" allowBlank="1">'
       '<x14:formula1><xm:f>Unidades!$A$2:$A$9</xm:f></x14:formula1><xm:sqref>C2:C100</xm:sqref></x14:dataValidation></x14:dataValidations></ext></extLst>')
def con_cambio(libro, reemplazo):
    ent, sal = zipfile.ZipFile(io.BytesIO(libro)), io.BytesIO()
    with zipfile.ZipFile(sal, "w", zipfile.ZIP_DEFLATED) as z:
        for it in ent.infolist(): z.writestr(it, reemplazo(it.filename, ent.read(it.filename)))
    return sal.getvalue()
guardado_por_excel = con_cambio(plantilla, lambda n, d: re.sub(rb"<dataValidations.*?</dataValidations>", b"", d, flags=re.S).replace(b"</worksheet>", EXT.encode() + b"</worksheet>") if n == "xl/worksheets/sheet1.xml" else d)
with warnings.catch_warnings(record=True) as avisos:
    warnings.simplefilter("always")
    r = importar_("productos", guardado_por_excel, C, solo_revisar=True)
check(not [a for a in avisos if "openpyxl" in str(a.filename)], "una plantilla guardada por Excel no genera avisos de openpyxl en la consola")
check(r["crear"] == 1 and r["con_error"] == 0, "y sus datos se leen completos")
check(importar_("productos", guardado_por_excel, C)["creadas"] == 1, "y se importa normalmente")
dañado = con_cambio(plantilla, lambda n, d: b"<esto no es xml" if n == "xl/worksheets/sheet1.xml" else d)
try: importar_("productos", dañado, C, solo_revisar=True); check(False, "un archivo dañado debía rechazarse")
except api.ApiError as e: check(e.status == 400 and "dañado" in e.mensaje, "un archivo dañado por dentro da un mensaje claro (400), no un error interno")

print("RESULTADO:", "TODO OK" if not fallos else f"{len(fallos)} FALLOS: {fallos}")
