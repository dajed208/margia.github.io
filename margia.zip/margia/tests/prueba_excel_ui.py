import os, threading, time, json, urllib.request, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import backend.server as server
from backend.db import database
from playwright.sync_api import sync_playwright

import tempfile
_BD_TEMPORAL = os.path.join(tempfile.mkdtemp(), "prueba.db")
database.db_path = lambda: _BD_TEMPORAL  # nunca toca data/costos.db
os.makedirs('capturas_prueba', exist_ok=True)
database.init()
srv, host, puerto = server.crear_servidor()
threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/"
def call(m, r, b=None, t=None):
    req = urllib.request.Request(URL + "api/" + r, data=json.dumps(b).encode() if b is not None else None, method=m)
    req.add_header("Content-Type", "application/json")
    if t: req.add_header("Authorization", "Bearer " + t)
    with urllib.request.urlopen(req) as x: return json.loads(x.read())

# --- datos de ejemplo vía API ---
t = call("POST", "login", {"username": "admin", "password": "admin123"})["token"]
e = call("POST", "empresas", {"codigo": "DELI", "razon_social": "Delipinchitos SAS", "nit": "900123456-1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, t)["id"]
kg = next(u for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "KG")["id"]
und = next(u for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "UND")["id"]
per = call("POST", "periodos", {"codigo": "2026", "nombre": "Año 2026", "fecha_inicio": "2026-01-01", "fecha_fin": "2026-12-31", "estado": "abierto", "unidades_presupuestadas": 2000, "empresa_id": e}, t)["id"]
mp1 = call("POST", "materias_primas", {"codigo": "MP01", "descripcion": "Pechuga de pollo", "unidad_id": kg, "unidad_estandar_id": kg, "costo_estandar": 14000, "proveedor": "Avícola del Sinú", "eficiencia_pct": 95, "stock_minimo": 10, "empresa_id": e}, t)["id"]
mp2 = call("POST", "materias_primas", {"codigo": "MP02", "descripcion": "Palitos de bambú", "unidad_id": und, "unidad_estandar_id": und, "costo_estandar": 40, "eficiencia_pct": 100, "stock_minimo": 500, "empresa_id": e}, t)["id"]
p1 = call("POST", "productos", {"codigo": "P01", "descripcion": "Pincho de pollo", "unidad_id": und, "precio_venta": 6500, "horas_mod_std": 0.05, "horas_maquina_std": 0.01, "empresa_id": e}, t)["id"]
call("POST", f"receta/{p1}", {"materia_prima_id": mp1, "cantidad_estandar": 0.12, "empresa_id": e}, t)
call("POST", f"receta/{p1}", {"materia_prima_id": mp2, "cantidad_estandar": 1, "empresa_id": e}, t)
tr = call("POST", "trabajadores", {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Operaria", "salario_mensual": 1423500, "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192, "empresa_id": e}, t)["id"]
bases = call("GET", f"bases_aplicacion?empresa_id={e}", None, t)
bmod = next(b["id"] for b in bases if b["codigo"] == "mano_obra_directa")
bund = next(b["id"] for b in bases if b["codigo"] == "unidades_producidas")
c1 = call("POST", "cif_conceptos", {"codigo": "CIF01", "descripcion": "Energía y gas", "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 600000, "real": 0, "empresa_id": e}, t)["id"]
c2 = call("POST", "cif_conceptos", {"codigo": "CIF02", "descripcion": "Arriendo del local", "tipo": "fijo", "base_aplicacion_id": bund, "presupuestado": 1800000, "real": 0, "empresa_id": e}, t)["id"]
call("POST", "inventario/movimientos", {"materia_prima_id": mp1, "tipo": "entrada", "cantidad": 40, "costo_unitario": 13800, "fecha": "2026-03-01", "nota": "Factura 551", "empresa_id": e}, t)
call("POST", "inventario/movimientos", {"materia_prima_id": mp2, "tipo": "entrada", "cantidad": 800, "costo_unitario": 38, "fecha": "2026-03-01", "empresa_id": e}, t)
o = call("POST", "ordenes", {"numero": "OP-001", "producto_id": p1, "periodo_id": per, "fecha": "2026-03-05", "cantidad_planeada": 200, "empresa_id": e}, t)["id"]
call("POST", f"ordenes/{o}/consumo", {"materia_prima_id": mp1, "cantidad_real": 25.5, "precio_real": 14200, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/consumo", {"materia_prima_id": mp2, "cantidad_real": 205, "precio_real": 40, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/mod", {"trabajador_id": tr, "horas_reales": 11, "tarifa_real": 11500, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cif", {"concepto_id": c1, "monto_real": 70000, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cif", {"concepto_id": c2, "monto_real": 180000, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cerrar", {"cantidad_producida": 200, "horas_maquina_reales": 2, "empresa_id": e}, t)


errores, fallos = [], []
def check(cond, texto):
    (print("  ✓", texto) if cond else (fallos.append(texto), print("  ✗", texto)))
import shutil
PANTALLAS = {"empresas": "Empresas", "periodos": "Periodos", "unidades_medida": "Unidades", "centros_costo": "Centros de costo",
             "productos": "Productos", "materias_primas": "Materias primas", "trabajadores": "Mano de obra",
             "cif_conceptos": "Conceptos de CIF", "hoja_costo": "Hoja de costo (recetas)", "ordenes": "Órdenes de producción"}
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
    pg = ctx.new_page()
    pg.on("pageerror", lambda ex: errores.append(f"pageerror: {ex}"))
    pg.goto(URL)
    pg.fill("#login-usuario", "admin"); pg.fill("#login-clave", "admin123")
    pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.7)
    pg.click("text=Más tarde"); time.sleep(0.3)
    print("Exportar desde cada pantalla")
    for item, nombre in PANTALLAS.items():
        pg.click(f"#menu button[data-item='{item}']"); time.sleep(0.7)
        with pg.expect_download() as d:
            pg.click(".mod-cabeza >> text=Exportar a Excel")
        ruta = f"capturas_prueba/{d.value.suggested_filename}"; shutil.copy(d.value.path(), ruta)
        ok = open(ruta, "rb").read(2) == b"PK" and pg.locator(".mod-cabeza >> text=Importar desde Excel").count() == 1
        check(ok, f"{nombre}: descarga {d.value.suggested_filename} y ofrece importar")
    pg.screenshot(path="capturas_prueba/x_ordenes.png")

    print("Importar órdenes exportadas (con una orden cerrada)")
    archivo = next(f for f in os.listdir("capturas_prueba") if f.startswith("ordenes_de_produccion_"))
    pg.click(".mod-cabeza >> text=Importar desde Excel"); time.sleep(0.3)
    pg.check("#chk-actualizar")
    pg.set_input_files("#modal input[type=file]", f"capturas_prueba/{archivo}"); time.sleep(1.2)
    txt = pg.inner_text("#modal")
    check("Hoja" in txt and "Consumo de materiales" in txt, "la vista previa muestra de qué hoja es cada fila")
    check("Se omite" in txt and "cerrada" in txt, "la orden cerrada aparece como «Se omite», no como error")
    pg.screenshot(path="capturas_prueba/x_importar_ordenes.png")
    pg.click("#modal >> text=Cancelar")

    print("Estudiante sin permisos")
    pg.click("#btn-salir"); time.sleep(0.8)
    pg.fill("#login-usuario", "estudiante"); pg.fill("#login-clave", "estudiante123")
    pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.7)
    if pg.is_visible("#modal-fondo:not(.oculto)"): pg.click("text=Más tarde"); time.sleep(0.3)
    pg.click("#menu button[data-item='productos']"); time.sleep(0.6)
    check(pg.locator(".mod-cabeza >> text=Exportar a Excel").count() == 1 and pg.locator(".mod-cabeza >> text=Importar desde Excel").count() == 0,
          "puede exportar pero no ve «Importar»")
    b.close()
srv.shutdown()
print("ERRORES JS:", errores or "ninguno")
print("FALLOS:", fallos or "ninguno")
