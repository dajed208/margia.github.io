"""Revisión estática de la interfaz: busca nombres de variables que no existen (el error que dejaba sin guardar las
órdenes de producción). Usa TypeScript solo para analizar; si no está instalado, la prueba se omite sin fallar.
Antes de revisar el código real, comprueba que el detector funciona atrapando un error puesto a propósito."""
import glob, json, os, shutil, subprocess, sys, tempfile
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def buscar_tsc():
    for c in (shutil.which("tsc"), os.path.expanduser("~/.npm-global/lib/node_modules/typescript/bin/tsc"),
              "/usr/lib/node_modules/typescript/bin/tsc", "/usr/local/lib/node_modules/typescript/bin/tsc"):
        if c and os.path.isfile(c): return c
tsc = buscar_tsc()
if not tsc:
    print("TypeScript no está instalado: revisión omitida (npm install -g typescript para activarla)."); sys.exit(0)
GLOBALES = "declare const Api: any; declare const UI: any; " + " ".join(
    f"declare const {n}: any;" for n in ("ModuloEntidad", "ModuloCosteo", "ModuloProduccion", "ModuloDashboard", "ModuloReportes",
                                          "ModuloUsuarios", "ModuloInventario", "ModuloSistema", "ModuloHistorico")) + " interface Window { App: any; I18N: any; }"
def revisar(archivos):
    tmp = tempfile.mkdtemp()
    open(os.path.join(tmp, "g.d.ts"), "w").write(GLOBALES)
    cfg = {"compilerOptions": {"allowJs": True, "checkJs": True, "noEmit": True, "target": "es2020", "lib": ["es2020", "dom"],
                               "strict": False, "skipLibCheck": True, "types": []}, "files": [os.path.join(tmp, "g.d.ts")] + archivos}
    json.dump(cfg, open(os.path.join(tmp, "tsconfig.json"), "w"))
    salida = subprocess.run([tsc, "-p", os.path.join(tmp, "tsconfig.json")], capture_output=True, text=True).stdout
    return [l for l in salida.splitlines() if "TS2304" in l or "TS2552" in l]
# 1) autocomprobación del detector
prueba = os.path.join(tempfile.mkdtemp(), "prueba.js")
open(prueba, "w").write("function f(d) { return orden_que_no_existe.id + d; }\n")
if not revisar([prueba]):
    print("✗ el detector no atrapó un error puesto a propósito: no es confiable"); sys.exit(1)
print("  ✓ el detector atrapa un nombre no definido puesto a propósito")
# 2) código real
archivos = sorted(glob.glob(os.path.join(RAIZ, "frontend", "js", "*.js")) + glob.glob(os.path.join(RAIZ, "frontend", "js", "modulos", "*.js")))
errores = revisar(archivos)
for e in errores: print("  ✗", e.replace(RAIZ + os.sep, ""))
print(f"  {'✓' if not errores else '✗'} {len(archivos)} archivos revisados: {len(errores)} nombres no definidos")
sys.exit(1 if errores else 0)
