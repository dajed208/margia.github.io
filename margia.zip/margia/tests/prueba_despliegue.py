"""Pruebas de despliegue: ejecuta el programa de verdad (como proceso aparte) en las situaciones de una instalación real:
configuración editada con el Bloc de notas, consola de Windows, rutas con tildes y espacios, carpeta sin permisos,
entorno empaquetado (PyInstaller simulado), modo de red, respaldos automáticos, actualizaciones y fallos al iniciar.
Todo en carpetas temporales: no toca data/costos.db."""
import atexit, json, os, shutil, socket, sqlite3, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fallos = []
def check(c, t): print(("  ✓ " if c else "  ✗ ") + t); (not c) and fallos.append(t)
_abiertos = []
atexit.register(lambda: [q.kill() for q in _abiertos if q.poll() is None])  # aunque la prueba se rompa, no deja servidores sueltos
_o = socket.socket()
if _o.connect_ex(("127.0.0.1", 8765)) == 0:
    print("⚠ El puerto 8765 ya está ocupado por otro programa (¿una corrida anterior de esta prueba?). Ciérrelo y vuelva a ejecutar."); sys.exit(2)
_o.close()
def puerto_libre():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p
def ip_red():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try: s.connect(("10.255.255.255", 1)); return s.getsockname()[0]
    except OSError: return None
    finally: s.close()

def copiar_app(nombre="app", base=None):
    base = base or tempfile.mkdtemp(prefix="margia_")
    app = os.path.join(base, nombre)
    shutil.copytree(RAIZ, app, ignore=shutil.ignore_patterns("data", "capturas_prueba", "__pycache__", ".git"))
    os.makedirs(os.path.join(app, "data"), exist_ok=True)
    return app

def configurar(app, host="127.0.0.1", puerto=None, extra=None, crudo=None):
    cfg = os.path.join(app, "config", "config.ini")
    texto = open(os.path.join(RAIZ, "config", "config.ini"), encoding="utf-8").read().replace("abrir_navegador = si", "abrir_navegador = no")  # siempre desde el original
    texto = texto.replace("host = 127.0.0.1", f"host = {host}")
    if puerto: texto = texto.replace("puerto = 8765", f"puerto = {puerto}")
    if extra: texto = extra(texto)
    open(cfg, "wb").write(crudo(texto) if crudo else texto.encode("utf-8"))

def iniciar(app, env=None, args=(), esperar_url=None):
    e = dict(os.environ, **(env or {}))
    p = subprocess.Popen([sys.executable, "iniciar.py", *args], cwd=app, env=e, stdin=subprocess.DEVNULL,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    _abiertos.append(p)
    if esperar_url:
        fin = time.time() + 12
        while time.time() < fin and p.poll() is None:
            try: urllib.request.urlopen(esperar_url, timeout=1); break
            except Exception: time.sleep(0.25)
    return p

def detener(p, codificacion="utf-8"):
    if p.poll() is None: p.terminate()
    try: salida = p.communicate(timeout=8)[0]
    except subprocess.TimeoutExpired: p.kill(); salida = p.communicate()[0]
    return salida.decode(codificacion, errors="replace")

def api(url, ruta, cuerpo=None, token=None, metodo=None):
    q = urllib.request.Request(url + "api/" + ruta, data=json.dumps(cuerpo).encode() if cuerpo is not None else None, method=metodo or ("POST" if cuerpo is not None else "GET"))
    q.add_header("Content-Type", "application/json")
    if token: q.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(q, timeout=10) as x: return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

print("1. Configuración editada con el Bloc de notas o con errores: el programa siempre abre")
orig = open(os.path.join(RAIZ, "config", "config.ini"), encoding="utf-8").read().replace("abrir_navegador = si", "abrir_navegador = no")
# (nombre, contenido del archivo o None para borrarlo, ¿debe avisar?, ¿usa el puerto elegido o el de fábrica 8765?)
casos = [
    ("con BOM y saltos de línea de Windows", lambda pto: b"\xef\xbb\xbf" + orig.replace("puerto = 8765", f"puerto = {pto}").replace("\n", "\r\n").encode("utf-8"), False, True),
    ("guardado como ANSI (tildes en la codificación de Windows)", lambda pto: orig.replace("puerto = 8765", f"puerto = {pto}").encode("cp1252"), False, True),
    ("con un error de sintaxis", lambda pto: b"[servidor\nhost = 127.0.0.1\n", True, False),
    ("con el puerto escrito con letras", lambda pto: orig.replace("puerto = 8765", "puerto = ocho mil").encode("utf-8"), True, False),
    ("con el puerto fuera de rango", lambda pto: orig.replace("puerto = 8765", "puerto = 99999").encode("utf-8"), True, False),
    ("borrado por completo", None, True, False),
]
for nombre, contenido, avisa, puerto_propio in casos:
    app = copiar_app(); pto = puerto_libre(); cfg = os.path.join(app, "config", "config.ini")
    if contenido is None: os.remove(cfg)
    else: open(cfg, "wb").write(contenido(pto))
    esperado = pto if puerto_propio else 8765
    p = iniciar(app, esperar_url=f"http://127.0.0.1:{esperado}/")
    vivo = p.poll() is None
    salida = detener(p)
    check(vivo and "funcionando" in salida and (("AVISO" in salida) == avisa),
          f"{nombre}: {'abre' if vivo else 'NO abre'}{' y avisa del problema' if avisa else ''}")
    if not (vivo and "funcionando" in salida and (("AVISO" in salida) == avisa)): print("      salida del programa:", repr(salida[:400]))
    shutil.rmtree(os.path.dirname(app), ignore_errors=True)
    time.sleep(0.3)

print("2. Consola de Windows (cp1252) y ruta con tildes y espacios")
app = copiar_app("Margia de José Pérez/app"); pto = puerto_libre(); configurar(app, puerto=pto)
p = iniciar(app, env={"PYTHONIOENCODING": "cp1252:strict"}, esperar_url=f"http://127.0.0.1:{pto}/")
vivo = p.poll() is None; salida = detener(p, "cp1252")
check(vivo and "funcionando" in salida and "UnicodeEncodeError" not in salida, "arranca con la consola en cp1252, sin errores de codificación")
check(os.path.isfile(os.path.join(app, "data", "costos.db")), "la base de datos se crea dentro de la carpeta con tildes y espacios")
r = subprocess.run([sys.executable, "iniciar.py", "--verificar"], cwd=app, env=dict(os.environ, PYTHONIOENCODING="cp1252:strict"), capture_output=True)
check(r.returncode == 0 and b"todo listo" in r.stdout, "--verificar pasa con la consola en cp1252")
shutil.rmtree(os.path.dirname(os.path.dirname(app)), ignore_errors=True)

app = copiar_app("Пользователь 用户/app"); pto = puerto_libre(); configurar(app, puerto=pto)
p = iniciar(app, env={"PYTHONIOENCODING": "cp1252:strict"}, esperar_url=f"http://127.0.0.1:{pto}/")
vivo = p.poll() is None; salida = detener(p, "cp1252")
check(vivo and "funcionando" in salida and "UnicodeEncodeError" not in salida, "una ruta con letras que la consola de Windows no puede mostrar no tumba el arranque")
shutil.rmtree(os.path.dirname(os.path.dirname(app)), ignore_errors=True)

print("3. Entorno empaquetado (PyInstaller simulado): recursos solo dentro del .exe, datos junto a él")
base = tempfile.mkdtemp(prefix="exe_"); mei = os.path.join(base, "_internal"); carpeta_exe = os.path.join(base, "Margia")
os.makedirs(os.path.join(mei, "backend", "db")); os.makedirs(carpeta_exe); os.makedirs(os.path.join(base, "codigo"))
shutil.copytree(os.path.join(RAIZ, "frontend"), os.path.join(mei, "frontend")); shutil.copy(os.path.join(RAIZ, "backend", "db", "schema.sql"), os.path.join(mei, "backend", "db"))
shutil.copytree(os.path.join(RAIZ, "config"), os.path.join(carpeta_exe, "config"))
shutil.copytree(os.path.join(RAIZ, "backend"), os.path.join(base, "codigo", "backend"), ignore=shutil.ignore_patterns("__pycache__", "schema.sql"))
shutil.copy(os.path.join(RAIZ, "iniciar.py"), os.path.join(base, "codigo"))
pto = puerto_libre(); cfg = os.path.join(carpeta_exe, "config", "config.ini")
_t = open(cfg, encoding="utf-8").read().replace("abrir_navegador = si", "abrir_navegador = no").replace("puerto = 8765", f"puerto = {pto}")
open(cfg, "w", encoding="utf-8").write(_t)
envoltorio = os.path.join(base, "como_exe.py")
open(envoltorio, "w").write(f"import sys, os\nsys.frozen = True\nsys._MEIPASS = {mei!r}\nsys.executable = {os.path.join(carpeta_exe, 'Margia.exe')!r}\n"
                            f"sys.path.insert(0, {os.path.join(base, 'codigo')!r})\nos.chdir(os.path.expanduser('~'))\nsys.argv = ['Margia.exe'] + sys.argv[1:]\n"
                            "import runpy; runpy.run_path(os.path.join(sys.path[0], 'iniciar.py'), run_name='__main__')\n")
r = subprocess.run([sys.executable, envoltorio, "--verificar"], capture_output=True, text=True)
check(r.returncode == 0 and "todo listo" in r.stdout, "--verificar encuentra interfaz, esquema, Excel y PDF dentro del entorno empaquetado")
p = subprocess.Popen([sys.executable, envoltorio], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
_abiertos.append(p)
fin = time.time() + 12
while time.time() < fin:
    try: urllib.request.urlopen(f"http://127.0.0.1:{pto}/", timeout=1); break
    except Exception: time.sleep(0.25)
st, rr = api(f"http://127.0.0.1:{pto}/", "login", {"username": "admin", "password": "admin123"})
html = urllib.request.urlopen(f"http://127.0.0.1:{pto}/").read().decode()
check(st == 200 and "login-usuario" in html, "sirve la interfaz y permite iniciar sesión, abierto desde otra carpeta")
detener(p)
check(os.path.isfile(os.path.join(carpeta_exe, "data", "costos.db")), "los datos se guardan junto al ejecutable, no en la carpeta temporal")
shutil.rmtree(base, ignore_errors=True)

print("4. Instalado en una carpeta sin permiso de escritura (Archivos de programa)")
base = tempfile.mkdtemp(prefix="sinperm_"); lad = os.path.join(base, "AppData"); os.makedirs(lad)
app = copiar_app("app", base); shutil.rmtree(os.path.join(app, "data")); open(os.path.join(app, "data"), "w").write("no es una carpeta")
pto = puerto_libre(); configurar(app, puerto=pto)
p = iniciar(app, env={"LOCALAPPDATA": lad}, esperar_url=f"http://127.0.0.1:{pto}/"); salida = detener(p)
check(os.path.isfile(os.path.join(lad, "Margia", "data", "costos.db")), "sin permiso para escribir junto al programa, guarda los datos en %LOCALAPPDATA%\\Margia")
check("funcionando" in salida and "Margia" in salida and lad in salida, "y lo dice en la consola")
shutil.rmtree(base, ignore_errors=True)

print("5. Abrirlo dos veces y puerto ocupado por otro programa")
app = copiar_app(); pto = puerto_libre(); configurar(app, puerto=pto)
p1 = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/")
p2 = subprocess.run([sys.executable, "iniciar.py"], cwd=app, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15)
check(p2.returncode == 0 and "ya estaba abierto" in p2.stdout, "segunda ventana: no falla, avisa que ya estaba abierto")
detener(p1)
ocupante = socket.socket(); ocupante.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); ocupante.bind(("127.0.0.1", pto)); ocupante.listen(1)
p3 = subprocess.run([sys.executable, "iniciar.py"], cwd=app, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15); ocupante.close()
check(p3.returncode == 1 and "otro programa" in p3.stdout and "config.ini" in p3.stdout, "puerto ocupado por otro programa: explica qué hacer")
shutil.rmtree(os.path.dirname(app), ignore_errors=True)

print("6. Modo de red (host = 0.0.0.0)")
ip = ip_red(); app = copiar_app(); pto = puerto_libre(); configurar(app, host="0.0.0.0", puerto=pto)
r = subprocess.run([sys.executable, "iniciar.py"], cwd=app, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15)
check(r.returncode == 1 and "POR SEGURIDAD" in r.stdout and "admin" in r.stdout, "con la contraseña de fábrica de admin, se niega a abrirse a la red y explica los 3 pasos")
try: urllib.request.urlopen(f"http://127.0.0.1:{pto}/", timeout=2); escuchando = True
except Exception: escuchando = False
check(not escuchando, "y no queda ningún puerto abierto")
configurar(app, host="127.0.0.1", puerto=pto); pl = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/")
st, r = api(f"http://127.0.0.1:{pto}/", "login", {"username": "admin", "password": "admin123"}); tok = r["token"]
api(f"http://127.0.0.1:{pto}/", "cambiar-clave", {"actual": "admin123", "nueva": "Clave-Segura-1"}, tok); detener(pl)
configurar(app, host="0.0.0.0", puerto=pto); pr = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/")
check(pr.poll() is None, "tras cambiar la contraseña de admin, sí se abre a la red")
if ip:
    st, r = api(f"http://{ip}:{pto}/", "login", {"username": "admin", "password": "Clave-Segura-1"})
    check(st == 200, f"otro equipo de la red entra por http://{ip}:{pto}/")
else: print("  - (sin IP de red en esta máquina: se omite la conexión desde otro equipo)")
salida = detener(pr)
check("Desde otros equipos" in salida and (not ip or ip in salida) and "0.0.0.0:" not in salida and "estudiante" in salida,
      "la consola muestra la dirección real para otros equipos (no 0.0.0.0), avisa de «estudiante» y de que no está cifrado")
shutil.rmtree(os.path.dirname(app), ignore_errors=True)

print("7. Respaldos automáticos y actualizaciones")
app = copiar_app(); pto = puerto_libre(); configurar(app, puerto=pto); data = os.path.join(app, "data"); resp = os.path.join(data, "respaldos")
p = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/"); detener(p)
check(not os.path.isdir(resp) or not os.listdir(resp), "primer inicio (aún no hay datos): no genera respaldos vacíos")
p = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/"); salida = detener(p)
diarios = [f for f in os.listdir(resp) if f.startswith("costos_")]
check(len(diarios) == 1 and "Respaldo automático" in salida, "segundo inicio: crea el respaldo del día y lo informa")
p = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/"); detener(p)
check(len([f for f in os.listdir(resp) if f.startswith("costos_")]) == 1, "varios inicios el mismo día: un solo respaldo diario")
c = sqlite3.connect(os.path.join(resp, diarios[0])); check(c.execute("PRAGMA integrity_check").fetchone()[0] == "ok" and c.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 2, "el respaldo es íntegro y trae los datos"); c.close()
for d in range(1, 21): open(os.path.join(resp, f"costos_2020-01-{d:02d}.db"), "wb").write(b"x")
p = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/"); detener(p)
check(len([f for f in os.listdir(resp) if f.startswith("costos_")]) == 14, "con 21 respaldos acumulados, conserva solo los 14 más recientes")
open(os.path.join(data, ".version"), "w").write("0.9.0")
c = sqlite3.connect(os.path.join(data, "costos.db")); c.execute("INSERT INTO empresas (codigo, razon_social, nit, moneda) VALUES ('X','Dato previo','1','COP')"); c.commit(); c.close()
p = iniciar(app, esperar_url=f"http://127.0.0.1:{pto}/"); salida = detener(p)
previos = [f for f in os.listdir(resp) if f.startswith("antes_de_actualizar_0.9.0_a_1.0.0")]
check(len(previos) == 1, "al detectar una versión nueva, guarda «antes_de_actualizar_0.9.0_a_1.0.0»")
c = sqlite3.connect(os.path.join(data, "costos.db")); n = c.execute("SELECT COUNT(*) FROM empresas WHERE razon_social='Dato previo'").fetchone()[0]; c.close()
check(n == 1, "los datos existentes sobreviven a la actualización")
check(open(os.path.join(data, ".version")).read() == "1.0.0", "y se registra la versión nueva")
st, meta = (lambda t: api(f"http://127.0.0.1:{pto}/", "meta", token=t))(api(f"http://127.0.0.1:{pto}/", "login", {"username": "estudiante", "password": "estudiante123"})[1]["token"]) if False else (None, None)
shutil.rmtree(os.path.dirname(app), ignore_errors=True)

print("8. Un fallo al iniciar no cierra la ventana sin explicar")
app = copiar_app()
open(os.path.join(app, "romper.py"), "w").write("import sys; sys.path.insert(0, '.')\nfrom backend import server\ndef mala(): raise RuntimeError('fallo de prueba')\nserver.main = mala\nimport runpy; sys.argv=['iniciar.py']; runpy.run_path('iniciar.py', run_name='__main__')\n")
r = subprocess.run([sys.executable, "romper.py"], cwd=app, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15)
log = os.path.join(app, "data", "margia_errores.log")
check(r.returncode == 1 and "error inesperado" in r.stdout and "fallo de prueba" in r.stdout and "margia_errores.log" in r.stdout, "muestra el error y dónde quedó el detalle (sin teclado conectado tampoco se cuelga)")
check(os.path.isfile(log) and "RuntimeError: fallo de prueba" in open(log, encoding="utf-8").read(), "el detalle queda guardado en data/margia_errores.log")
shutil.rmtree(os.path.dirname(app), ignore_errors=True)

print("9. Varias personas a la vez y respaldos descargados en pleno movimiento")
app = copiar_app(); pto = puerto_libre(); configurar(app, puerto=pto); url = f"http://127.0.0.1:{pto}/"
p = iniciar(app, esperar_url=url); st, r = api(url, "login", {"username": "admin", "password": "admin123"}); T = r["token"]
E = api(url, "empresas", {"codigo": "E", "razon_social": "E", "nit": "1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, T)[1]["id"]
und = next(u["id"] for u in api(url, "unidades_medida", token=T)[1] if u["codigo"] == "UND")
errores, guardados, lock, parar = [], [0], threading.Lock(), threading.Event()
def escribir(n):
    tok = api(url, "login", {"username": "admin", "password": "admin123"})[1]["token"]
    for i in range(25):
        s, r = api(url, "productos", {"codigo": f"U{n}-{i}", "descripcion": "x", "unidad_id": und, "precio_venta": 1, "horas_mod_std": 0, "horas_maquina_std": 0, "empresa_id": E}, tok)
        with lock:
            if s == 200: guardados[0] += 1
            else: errores.append((s, r.get("error", "")[:60]))
def respaldos_continuos():
    malos = []
    while not parar.is_set():
        q = urllib.request.Request(url + "api/respaldo"); q.add_header("Authorization", "Bearer " + T)
        ruta = os.path.join(tempfile.mkdtemp(), "r.db"); open(ruta, "wb").write(urllib.request.urlopen(q).read())
        c = sqlite3.connect(ruta); ok = c.execute("PRAGMA integrity_check").fetchone()[0]; c.close()
        if ok != "ok": malos.append(ok)
        respaldos_continuos.hechos += 1
    respaldos_continuos.malos = malos
respaldos_continuos.hechos = 0; respaldos_continuos.malos = []
hr = threading.Thread(target=respaldos_continuos); hr.start()
hilos = [threading.Thread(target=escribir, args=(n,)) for n in range(12)]; [h.start() for h in hilos]; [h.join() for h in hilos]; parar.set(); hr.join()
check(guardados[0] == 300 and not errores, f"12 personas guardando 300 registros a la vez: {guardados[0]} guardados, errores: {errores[:2] or 'ninguno'}")
check(not respaldos_continuos.malos and respaldos_continuos.hechos >= 3, f"{respaldos_continuos.hechos} respaldos descargados durante ese trabajo: todos íntegros")
st, meta = api(url, "meta", token=T)
check(meta.get("version") == "1.0.0", "la versión se informa a la interfaz (se muestra al pie del menú)")
detener(p); shutil.rmtree(os.path.dirname(app), ignore_errors=True)

print("RESULTADO:", "TODO OK" if not fallos else f"{len(fallos)} FALLOS: {fallos}")
sys.exit(1 if fallos else 0)
