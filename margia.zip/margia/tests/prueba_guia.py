"""Guía de primeros pasos del dashboard, de un sistema vacío a la primera orden cerrada (navegador real).
Usa una base de datos temporal: no toca data/costos.db."""
import os, sys, json, time, tempfile, threading, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.db import database
_T = os.path.join(tempfile.mkdtemp(), "prueba.db"); database.db_path = lambda: _T
import backend.server as server
from playwright.sync_api import sync_playwright
database.init()
srv, host, puerto = server.crear_servidor()
threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/"
os.makedirs("capturas_prueba", exist_ok=True)
def call(m, r, b=None, t=None):
    q = urllib.request.Request(URL + "api/" + r, data=json.dumps(b).encode() if b is not None else None, method=m)
    q.add_header("Content-Type", "application/json")
    if t: q.add_header("Authorization", "Bearer " + t)
    with urllib.request.urlopen(q) as x: return json.loads(x.read())
errores, fallos = [], []
def check(cond, texto):
    (print("  ✓", texto) if cond else (fallos.append(texto), print("  ✗", texto)))
DESTINO = {"empresa": "empresas", "periodo": "periodos", "materias": "materias_primas", "mano_obra": "trabajadores", "cif": "cif_conceptos",
           "productos": "productos", "recetas": "hoja_costo", "orden": "ordenes", "cierre": "ordenes"}

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 950})
    pg.on("pageerror", lambda ex: errores.append(f"pageerror: {ex}"))
    pg.on("console", lambda m: m.type == "error" and errores.append(f"console: {m.text}"))
    pg.goto(URL)
    pg.fill("#login-usuario", "admin"); pg.fill("#login-clave", "admin123")
    pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
    pg.click("text=Más tarde"); time.sleep(0.3)
    t = call("POST", "login", {"username": "admin", "password": "admin123"})["token"]

    def dashboard():
        pg.click("#menu button[data-item='dashboard']"); time.sleep(0.7)
    def cuenta(): return pg.inner_text(".guia-cuenta")
    def siguiente(): return pg.get_attribute(".guia-paso.actual", "data-paso")
    def ayuda(paso): return pg.inner_text(f".guia-paso[data-paso='{paso}'] .guia-ayuda")

    print("Sistema vacío")
    check(pg.get_attribute("#menu button.activo", "data-item") == "dashboard", "al entrar se abre el dashboard")
    check(cuenta() == "0 de 9 pasos" and siguiente() == "empresa", "0 de 9, siguiente: crear la empresa")
    check(pg.locator(".guia-paso.bloqueado").count() == 8, "los otros 8 pasos esperan a que exista la empresa")
    pg.click(".guia-paso[data-paso='periodo']"); time.sleep(0.4)
    check(pg.get_attribute("#menu button.activo", "data-item") == "dashboard", "un paso bloqueado no navega")
    pg.screenshot(path="capturas_prueba/g0_vacio.png")
    pg.click(".guia-cabeza .primario"); time.sleep(0.6)
    check(pg.get_attribute("#menu button.activo", "data-item") == "empresas", "«Continuar» lleva a Empresas")

    print("Avance paso a paso")
    e = call("POST", "empresas", {"codigo": "DELI", "razon_social": "Delipinchitos SAS", "nit": "900123456-1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, t)["id"]
    pg.reload(); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
    check(cuenta() == "1 de 9 pasos" and siguiente() == "periodo", "con la empresa: 1 de 9, siguiente: periodo")
    per = call("POST", "periodos", {"codigo": "SEP26", "nombre": "Septiembre 2026", "fecha_inicio": "2026-09-01", "fecha_fin": "2026-09-30", "estado": "abierto", "empresa_id": e}, t)["id"]
    dashboard()
    check(siguiente() == "periodo" and "Falta cargar las unidades presupuestadas" in ayuda("periodo"), "periodo sin unidades presupuestadas: sigue pendiente y lo explica")
    call("PUT", f"periodos/{per}", {"codigo": "SEP26", "nombre": "Septiembre 2026", "fecha_inicio": "2026-09-01", "fecha_fin": "2026-09-30", "estado": "abierto", "unidades_presupuestadas": 3000, "empresa_id": e}, t)
    kg = next(u["id"] for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "KG")
    und = next(u["id"] for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "UND")
    m1 = call("POST", "materias_primas", {"codigo": "MP01", "descripcion": "Marshmallows", "unidad_id": kg, "unidad_estandar_id": kg, "costo_estandar": 12000, "eficiencia_pct": 98, "empresa_id": e}, t)["id"]
    tr = call("POST", "trabajadores", {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Repostera", "salario_mensual": 1423500, "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192, "empresa_id": e}, t)["id"]
    dashboard()
    check(cuenta() == "4 de 9 pasos" and siguiente() == "cif", "con periodo, materias y mano de obra: 4 de 9, siguiente: CIF")
    bmod = next(x["id"] for x in call("GET", f"bases_aplicacion?empresa_id={e}", None, t) if x["codigo"] == "mano_obra_directa")
    c = call("POST", "cif_conceptos", {"codigo": "CIF01", "descripcion": "Gas", "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 0, "real": 0, "empresa_id": e}, t)["id"]
    dashboard()
    check(siguiente() == "cif" and "no tienen valor presupuestado" in ayuda("cif"), "CIF en cero: sigue pendiente y lo explica")
    call("PUT", f"cif_conceptos/{c}", {"codigo": "CIF01", "descripcion": "Gas", "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 120000, "real": 0, "empresa_id": e}, t)
    p1 = call("POST", "productos", {"codigo": "P01", "descripcion": "Pinchito de marshmallows", "unidad_id": und, "precio_venta": 1500, "horas_mod_std": 0.0167, "horas_maquina_std": 0, "empresa_id": e}, t)["id"]
    p2 = call("POST", "productos", {"codigo": "P02", "descripcion": "Galleta Oreo con chocolate", "unidad_id": und, "precio_venta": 2000, "horas_mod_std": 0.0083, "horas_maquina_std": 0, "empresa_id": e}, t)["id"]
    call("POST", f"receta/{p1}", {"materia_prima_id": m1, "cantidad_estandar": 0.025, "empresa_id": e}, t)
    dashboard()
    check(siguiente() == "recetas" and "1 de 2 productos tienen receta" in ayuda("recetas"), "receta incompleta: «1 de 2 productos tienen receta»")
    call("POST", f"receta/{p2}", {"materia_prima_id": m1, "cantidad_estandar": 0.02, "empresa_id": e}, t)
    o = call("POST", "ordenes", {"numero": "OP-001", "producto_id": p1, "periodo_id": per, "fecha": "2026-09-10", "cantidad_planeada": 300, "empresa_id": e}, t)["id"]
    dashboard()
    check(cuenta() == "8 de 9 pasos" and siguiente() == "cierre", "con la orden: 8 de 9, siguiente: cerrarla")
    pg.screenshot(path="capturas_prueba/g1_avance.png", full_page=True)

    print("Cada «ir →» lleva a su pantalla")
    for paso, item in DESTINO.items():
        dashboard()
        pg.click(f".guia-paso[data-paso='{paso}'] .guia-ir"); time.sleep(0.6)
        activo = pg.get_attribute("#menu button.activo", "data-item")
        check(activo == item and pg.locator("#contenido .mod-cabeza h2").count() == 1, f"{paso} → {item}")

    print("Primera orden cerrada")
    call("POST", f"ordenes/{o}/consumo", {"materia_prima_id": m1, "cantidad_real": 7.8, "precio_real": 12200, "empresa_id": e}, t)
    call("POST", f"ordenes/{o}/mod", {"trabajador_id": tr, "horas_reales": 5, "tarifa_real": 11300, "empresa_id": e}, t)
    call("POST", f"ordenes/{o}/cif", {"concepto_id": c, "monto_real": 9000, "empresa_id": e}, t)
    call("POST", f"ordenes/{o}/cerrar", {"cantidad_producida": 300, "empresa_id": e}, t)
    dashboard()
    check(pg.locator(".guia").count() == 0 and pg.locator(".tarjetas-kpi").count() == 1, "9 de 9: la guía desaparece y aparecen los indicadores")

    print("Faltan pasos después de tener indicadores")
    call("POST", "productos", {"codigo": "P03", "descripcion": "Delibolsita de gomitas", "unidad_id": und, "precio_venta": 3000, "horas_mod_std": 0.01, "horas_maquina_std": 0, "empresa_id": e}, t)
    dashboard()
    check(pg.locator(".guia").count() == 1 and pg.locator(".tarjetas-kpi").count() == 1 and siguiente() == "recetas",
          "producto nuevo sin receta: la guía vuelve (8 de 9) junto con los indicadores")
    pg.click("text=Ocultar guía de inicio"); time.sleep(0.6)
    check(pg.locator(".guia").count() == 0 and "Ver guía de inicio (8 de 9)" in pg.inner_text("#contenido"), "«Ocultar guía» la pliega")
    pg.reload(); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
    check(pg.locator(".guia").count() == 0, "la guía sigue oculta al volver a entrar")
    pg.click("text=Ver guía de inicio (8 de 9)"); time.sleep(0.6)
    check(pg.locator(".guia").count() == 1, "«Ver guía de inicio» la muestra otra vez")
    pg.screenshot(path="capturas_prueba/g2_con_indicadores.png", full_page=True)
    b.close()
srv.shutdown()
print("ERRORES JS:", errores or "ninguno")
print("FALLOS:", fallos or "ninguno")
