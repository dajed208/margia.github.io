"""Corregir órdenes de producción (editar, reabrir, eliminar) solo con el código de autorización del administrador.
Sin navegador, por HTTP real contra el servidor, con una base temporal: no toca data/costos.db."""
import json, os, sqlite3, sys, tempfile, threading, time, urllib.error, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.db import database
_T = os.path.join(tempfile.mkdtemp(), "p.db"); database.db_path = lambda: _T
import backend.server as server
from backend import security

database.init()
srv, host, puerto = server.crear_servidor()
threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/api/"
fallos = []
def check(c, t): print(("  ✓ " if c else "  ✗ ") + t); (not c) and fallos.append(t)
def llamar(m, r, b=None, t=None):
    q = urllib.request.Request(URL + r, data=json.dumps(b).encode() if b is not None else None, method=m)
    q.add_header("Content-Type", "application/json")
    if t: q.add_header("Authorization", "Bearer " + t)
    try:
        with urllib.request.urlopen(q) as x: return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b"{}")
def sql(consulta, *p):
    c = sqlite3.connect(_T); c.row_factory = sqlite3.Row
    try: return c.execute(consulta, p).fetchall()
    finally: c.close()
def uno(consulta, *p): return sql(consulta, *p)[0][0]

_, r = llamar("POST", "login", {"username": "admin", "password": "admin123"}); A = r["token"]
_, r = llamar("POST", "login", {"username": "estudiante", "password": "estudiante123"}); S = r["token"]
_, e = llamar("POST", "empresas", {"codigo": "D", "razon_social": "Delipinchitos", "nit": "1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, A); E = e["id"]
un = {u["codigo"]: u["id"] for u in llamar("GET", "unidades_medida", None, A)[1]}
_, r = llamar("POST", "periodos", {"codigo": "S", "nombre": "Sep", "fecha_inicio": "2026-09-01", "fecha_fin": "2026-09-30", "estado": "abierto", "unidades_presupuestadas": 1000, "empresa_id": E}, A); PER = r["id"]
_, r = llamar("POST", "materias_primas", {"codigo": "MP", "descripcion": "Harina", "unidad_id": un["KG"], "unidad_estandar_id": un["KG"], "costo_estandar": 1000, "eficiencia_pct": 100, "empresa_id": E}, A); MP = r["id"]
_, r = llamar("POST", "trabajadores", {"codigo": "T", "nombre": "Ana", "cargo": "x", "salario_mensual": 1000000, "prestaciones_pct": 0, "cargas_pct": 0, "horas_mes": 200, "empresa_id": E}, A); TR = r["id"]
_, r = llamar("POST", "productos", {"codigo": "P1", "descripcion": "Torta", "unidad_id": un["UND"], "precio_venta": 9000, "horas_mod_std": 0.1, "horas_maquina_std": 0, "empresa_id": E}, A); P1 = r["id"]
_, r = llamar("POST", "productos", {"codigo": "P2", "descripcion": "Galleta", "unidad_id": un["UND"], "precio_venta": 2000, "horas_mod_std": 0.1, "horas_maquina_std": 0, "empresa_id": E}, A); P2 = r["id"]
llamar("POST", f"receta/{P1}", {"materia_prima_id": MP, "cantidad_estandar": 0.5, "empresa_id": E}, A)
bmod = next(b["id"] for b in llamar("GET", f"bases_aplicacion?empresa_id={E}", None, A)[1] if b["codigo"] == "mano_obra_directa")
kilos = llamar("POST", "bases_aplicacion", {"codigo": "KILOS", "nombre": "Kilos", "empresa_id": E}, A)[1]["id"]
CIF = llamar("POST", "cif_conceptos", {"codigo": "C1", "descripcion": "Gas", "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 50000, "real": 0, "empresa_id": E}, A)[1]["id"]
llamar("POST", "inventario/movimientos", {"materia_prima_id": MP, "tipo": "entrada", "cantidad": 100, "costo_unitario": 1000, "fecha": "2026-09-01", "empresa_id": E}, A)
def existencias(): return llamar("GET", f"inventario/existencias?empresa_id={E}", None, A)[1]["materiales"][0]["existencias"]
def orden(num, cerrar, consumo=20):
    oid = llamar("POST", "ordenes", {"numero": num, "producto_id": P1, "periodo_id": PER, "fecha": "2026-09-10", "cantidad_planeada": 40, "empresa_id": E}, A)[1]["id"]
    llamar("POST", f"ordenes/{oid}/consumo", {"materia_prima_id": MP, "cantidad_real": consumo, "precio_real": 1000, "empresa_id": E}, A)
    llamar("POST", f"ordenes/{oid}/mod", {"trabajador_id": TR, "horas_reales": 4, "tarifa_real": 5000, "empresa_id": E}, A)
    llamar("POST", f"ordenes/{oid}/cif", {"concepto_id": CIF, "monto_real": 3000, "empresa_id": E}, A)
    llamar("POST", f"ordenes/{oid}/base", {"base_id": kilos, "cantidad_real": 20, "empresa_id": E}, A)
    if cerrar: llamar("POST", f"ordenes/{oid}/cerrar", {"cantidad_producida": 40, "empresa_id": E}, A)
    return oid
O1 = orden("OP-001", True); O2 = orden("OP-002", False, consumo=5)
base = {"empresa_id": E}
stock0 = existencias()

print("El código no existe todavía")
st, r = llamar("GET", "ordenes/codigo", None, A); check(st == 200 and r == {"configurado": False, "puede_configurar": True}, "el administrador ve que falta crearlo")
st, r = llamar("GET", "ordenes/codigo", None, S); check(r["puede_configurar"] is False, "el estudiante no puede configurarlo")
for nombre, ruta, met, cuerpo in (("eliminar", f"ordenes/{O2}/eliminar", "POST", {}), ("reabrir", f"ordenes/{O1}/reabrir", "POST", {}), ("editar", f"ordenes/{O2}", "PUT", {})):
    st, r = llamar(met, ruta, dict(cuerpo, codigo="1234", **base), A)
    check(st == 409 and "todavía no ha creado el código" in r["error"], f"{nombre} sin código creado → 409: el administrador debe crearlo primero")
check(uno("SELECT COUNT(*) FROM ordenes_produccion WHERE empresa_id=?", E) == 2, "no se tocó ninguna orden")

print("Crear y cambiar el código")
st, r = llamar("POST", "ordenes/codigo", {"password": "admin123", "codigo": "abcd"}, S); check(st == 403, "un estudiante no puede crearlo")
st, r = llamar("POST", "ordenes/codigo", {"password": "mala", "codigo": "Cod2026"}, A); check(st == 400 and "password" in r["campos"], "pide la contraseña del administrador y la verifica")
st, r = llamar("POST", "ordenes/codigo", {"password": "admin123", "codigo": "123"}, A); check(st == 400 and "codigo" in r["campos"], "mínimo 4 caracteres")
st, r = llamar("POST", "ordenes/codigo", {"password": "admin123", "codigo": "Cod2026"}, A); check(st == 200 and r["configurado"], "el administrador crea el código")
guardado = uno("SELECT valor FROM ajustes WHERE clave='codigo_ordenes'")
check("Cod2026" not in guardado and "hash" in guardado, "en la base solo queda cifrado: el código no se puede leer")
check("Cod2026" not in json.dumps(llamar("GET", "ordenes/codigo", None, A)[1]), "tampoco lo devuelve la API")
check(llamar("GET", "ordenes/codigo", None, A)[1]["configurado"] is True, "ahora figura como configurado")

print("Código incorrecto: bloqueo y registro")
st, r = llamar("POST", f"ordenes/{O2}/eliminar", dict(base, codigo=""), A); check(st == 400 and "codigo" in r["campos"], "código vacío: pide escribirlo")
st, r = llamar("POST", f"ordenes/{O2}/eliminar", dict(base, codigo="equivocado"), A); check(st == 403 and "codigo" in r["campos"], "código incorrecto → 403")
check(uno("SELECT COUNT(*) FROM bitacora WHERE accion='codigo_incorrecto'") == 1, "el intento fallido queda en la Actividad")
for _ in range(4): llamar("POST", f"ordenes/{O2}/eliminar", dict(base, codigo="x" + str(_)), A)
st, r = llamar("POST", f"ordenes/{O2}/eliminar", dict(base, codigo="Cod2026"), A); check(st == 429, "tras 5 intentos fallidos se bloquea, incluso con el código correcto")
check(uno("SELECT COUNT(*) FROM ordenes_produccion WHERE id=?", O2) == 1, "la orden sigue ahí")
security.limpiar_fallos(f"codigo-ordenes:{1}")

print("Editar una orden abierta")
st, r = llamar("PUT", f"ordenes/{O2}", dict(base, codigo="Cod2026", numero="OP-002", producto_id=P2, periodo_id=PER, fecha="2026-09-12", cantidad_planeada=60, motivo="Se digitó mal el producto"), A)
check(st == 200, "con el código correcto se edita")
o = sql("SELECT * FROM ordenes_produccion WHERE id=?", O2)[0]
check(o["producto_id"] == P2 and o["fecha"] == "2026-09-12" and o["cantidad_planeada"] == 60, "producto, fecha y cantidad cambiaron")
det = uno("SELECT detalle FROM bitacora WHERE accion='editar_orden'")
check("Fecha: 2026-09-10 → 2026-09-12" in det and "Cantidad planeada: 40.0 → 60.0" in det and "Se digitó mal el producto" in det, "la Actividad guarda qué cambió (antes → después) y el motivo")
st, r = llamar("PUT", f"ordenes/{O2}", dict(base, codigo="Cod2026", numero="OP-001", producto_id=P2, periodo_id=PER, fecha="2026-09-12", cantidad_planeada=60), A)
check(st == 400 and "numero" in r["campos"], "no deja repetir el número de otra orden")
st, r = llamar("PUT", f"ordenes/{O2}", dict(base, codigo="Cod2026", numero="OP-002", producto_id=P2, periodo_id=PER, fecha="2026-09-12", cantidad_planeada=60), A)
check(st == 400 and "ningún dato" in r["error"], "avisa si no cambiaste nada")
st, r = llamar("PUT", f"ordenes/{O1}", dict(base, codigo="Cod2026", numero="OP-001", producto_id=P1, periodo_id=PER, fecha="2026-09-10", cantidad_planeada=50), A)
check(st == 400 and "Reabrir" in r["error"], "una orden cerrada no se edita: hay que reabrirla")
llamar("PUT", f"ordenes/{O2}", dict(base, codigo="Cod2026", numero="OP-002", producto_id=P1, periodo_id=PER, fecha="2026-09-12", cantidad_planeada=60), A)

print("Reabrir una orden cerrada")
stock_cerrada = existencias()
cr = sql("SELECT * FROM costos_reales WHERE orden_id=?", O1)[0]
check(uno("SELECT COUNT(*) FROM variaciones WHERE orden_id=?", O1) == 7 and uno("SELECT COUNT(*) FROM movimientos_inventario WHERE orden_id=?", O1) == 1, "antes: 7 variaciones y 1 salida de inventario")
st, r = llamar("POST", f"ordenes/{O1}/reabrir", dict(base, codigo="mal"), A); check(st == 403, "con código incorrecto no se reabre")
st, r = llamar("POST", f"ordenes/{O1}/reabrir", dict(base, codigo="Cod2026", motivo="Faltó registrar una compra"), A)
check(st == 200 and r["orden"]["estado"] == "abierta", "con el código correcto se reabre")
check(uno("SELECT COUNT(*) FROM costos_reales WHERE orden_id=?", O1) == 0 and uno("SELECT COUNT(*) FROM variaciones WHERE orden_id=?", O1) == 0
      and uno("SELECT COUNT(*) FROM cif_aplicado WHERE orden_id=?", O1) == 0, "se descartaron costos reales, variaciones y CIF aplicado")
check(uno("SELECT COUNT(*) FROM movimientos_inventario WHERE orden_id=?", O1) == 0 and abs(existencias() - (stock_cerrada + 20)) < 1e-9, f"las 20 unidades vuelven a la bodega ({stock_cerrada} → {existencias()})")
check(len(r["consumo_mp"]) == 1 and len(r["horas_mod"]) == 1 and len(r["cif_real"]) == 1 and len(r["bases_reales"]) == 1, "los consumos, horas, CIF y bases registrados se conservan")
st, r2 = llamar("POST", f"ordenes/{O1}/reabrir", dict(base, codigo="Cod2026"), A); check(st == 400 and "ya está abierta" in r2["error"], "reabrir una orden ya abierta → aviso")
print("   …se corrige un dato y se vuelve a cerrar")
cid = r["consumo_mp"][0]["id"]
llamar("DELETE", f"ordenes/{O1}/consumo/{cid}?empresa_id={E}", None, A)
llamar("POST", f"ordenes/{O1}/consumo", {"materia_prima_id": MP, "cantidad_real": 24, "precio_real": 1000, "empresa_id": E}, A)
st, r = llamar("POST", f"ordenes/{O1}/cerrar", {"cantidad_producida": 40, "empresa_id": E}, A)
check(st == 200 and r["costo_real"]["costo_mp"] == 24000 and r["costo_real"]["total"] != cr["total"], f"el costo real se recalcula con el dato corregido: MP {r['costo_real']['costo_mp']:.0f} (antes {cr['costo_mp']:.0f})")
check(uno("SELECT COUNT(*) FROM movimientos_inventario WHERE orden_id=?", O1) == 1 and abs(existencias() - (stock_cerrada + 20 - 24)) < 1e-9, "la salida de inventario se vuelve a generar una sola vez, con 24")
check(uno("SELECT COUNT(*) FROM variaciones WHERE orden_id=?", O1) == 7, "y vuelven a calcularse las 7 variaciones")

print("Eliminar")
check(llamar("DELETE", f"ordenes/{O2}?empresa_id={E}", None, A)[0] == 400, "el borrado directo sin código ya no existe (DELETE → 400)")
st, r = llamar("POST", f"ordenes/{O1}/eliminar", dict(base, codigo="mal"), A); check(st == 403, "con código incorrecto no se elimina")
st, r = llamar("POST", f"ordenes/{O1}/eliminar", dict(base, codigo="Cod2026", motivo="Orden duplicada"), A)
check(st == 200, "orden CERRADA con una base personalizada registrada: se elimina (antes fallaba por integridad)")
for t in ("consumo_mp", "horas_mod", "cif_real_orden", "orden_base_real", "costos_reales", "variaciones", "cif_aplicado", "movimientos_inventario"):
    check(uno(f"SELECT COUNT(*) FROM {t} WHERE orden_id=?", O1) == 0, f"no queda nada en {t}")
check(abs(existencias() - (stock_cerrada + 20)) < 1e-9, "el inventario que había consumido vuelve a la bodega")
check("Orden duplicada" in uno("SELECT detalle FROM bitacora WHERE accion='eliminar_orden'"), "la Actividad registra quién, qué orden y el motivo")
st, r = llamar("POST", f"ordenes/{O2}/eliminar", dict(base, codigo="Cod2026"), A); check(st == 200, "una orden abierta también se elimina con el código")
check(uno("SELECT COUNT(*) FROM ordenes_produccion WHERE empresa_id=?", E) == 0, "no quedan órdenes")

print("Permisos y cambio de código")
O3 = orden("OP-003", False, consumo=1)
st, r = llamar("POST", f"ordenes/{O3}/eliminar", dict(base, codigo="Cod2026"), S); check(st == 403 and "permiso" in r["error"], "un estudiante SIN permiso de producción no puede, aunque conozca el código")
llamar("PUT", "usuarios/2", {"nombre": "Estudiante", "rol": "estudiante", "activo": True, "permisos": {"ordenes": True}}, A)
st, r = llamar("PUT", f"ordenes/{O3}", dict(base, codigo="Cod2026", numero="OP-003B", producto_id=P1, periodo_id=PER, fecha="2026-09-10", cantidad_planeada=40), S)
check(st == 200, "con permiso de producción y el código, un estudiante sí puede")
check(uno("SELECT COUNT(*) FROM bitacora WHERE accion='editar_orden' AND usuario='estudiante'") == 1, "y queda registrado a nombre del estudiante")
llamar("POST", "ordenes/codigo", {"password": "admin123", "codigo": "Nuevo-77"}, A)
st, r = llamar("POST", f"ordenes/{O3}/eliminar", dict(base, codigo="Cod2026"), A); check(st == 403, "al cambiar el código, el anterior deja de servir")
security.limpiar_fallos("codigo-ordenes:1")

print("Importar desde Excel con «actualizar»")
import base64, io, openpyxl
def libro(filas):
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Órdenes"
    ws.append(["Número de orden *", "Código del producto *", "Código del periodo *", "Fecha *", "Cantidad planeada *"])
    for f in filas: ws.append(f)
    b = io.BytesIO(); wb.save(b); return base64.b64encode(b.getvalue()).decode()
arch = libro([["OP-003B", "P1", "S", "2026-09-20", 77], ["OP-NUEVA", "P1", "S", "2026-09-21", 10]])
st, r = llamar("POST", "importar/ordenes/confirmar", dict(base, archivo=arch, actualizar=True), A)
check(st in (400, 409) and "código" in r["error"].lower(), f"actualizar una orden existente desde un archivo exige el código ({st})")
check(uno("SELECT COUNT(*) FROM ordenes_produccion WHERE numero='OP-NUEVA'") == 0, "y no se importó nada a medias")
st, r = llamar("POST", "importar/ordenes/confirmar", dict(base, archivo=arch, actualizar=True, codigo="Nuevo-77"), A)
check(st == 200 and r == {"creadas": 1, "actualizadas": 1, "omitidas": 0}, f"con el código se importa: {r}")
st, r = llamar("POST", "importar/ordenes/confirmar", dict(base, archivo=libro([["OP-OTRA", "P1", "S", "2026-09-22", 5]])), A)
check(st == 200 and r["creadas"] == 1, "crear órdenes nuevas desde un archivo NO pide código")
check(llamar("POST", "importar/ordenes/revisar", dict(base, archivo=arch, actualizar=True), A)[0] == 200, "la vista previa tampoco lo pide")

print("Respaldos antiguos")
c = sqlite3.connect(_T); c.execute("DROP TABLE ajustes"); c.commit(); c.close()  # como un respaldo hecho antes de existir el código
con = database.connect(); database._migrar(con); con.close()  # lo que hace la restauración
st, r = llamar("GET", "ordenes/codigo", None, A)
check(st == 200 and r["configurado"] is False, "tras restaurar un respaldo antiguo, el código figura como no creado (en vez de fallar) y se puede volver a crear")
check(llamar("POST", "ordenes/codigo", {"password": "admin123", "codigo": "Otro-99"}, A)[0] == 200, "y el administrador puede crearlo de nuevo")

srv.shutdown()
print("RESULTADO:", "TODO OK" if not fallos else f"{len(fallos)} FALLOS: {fallos}")
sys.exit(1 if fallos else 0)
