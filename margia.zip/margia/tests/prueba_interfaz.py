import os, threading, time, json, urllib.request, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import backend.server as server
from backend.db import database
from playwright.sync_api import sync_playwright

import tempfile
_BD_TEMPORAL = os.path.join(tempfile.mkdtemp(), "prueba.db")
database.db_path = lambda: _BD_TEMPORAL  # nunca toca data/costos.db
os.makedirs('capturas_prueba', exist_ok=True)
database.init()
srv, host, puerto = server.crear_servidor()
threading.Thread(target=srv.serve_forever, daemon=True).start(); time.sleep(0.3)
URL = f"http://{host}:{puerto}/"
def call(m, r, b=None, t=None):
    req = urllib.request.Request(URL + "api/" + r, data=json.dumps(b).encode() if b is not None else None, method=m)
    req.add_header("Content-Type", "application/json")
    if t: req.add_header("Authorization", "Bearer " + t)
    with urllib.request.urlopen(req) as x: return json.loads(x.read())

# --- datos de ejemplo vía API ---
t = call("POST", "login", {"username": "admin", "password": "admin123"})["token"]
e = call("POST", "empresas", {"codigo": "DELI", "razon_social": "Delipinchitos SAS", "nit": "900123456-1", "regimen": "comun", "responsable_iva": "no", "moneda": "COP"}, t)["id"]
kg = next(u for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "KG")["id"]
und = next(u for u in call("GET", "unidades_medida", None, t) if u["codigo"] == "UND")["id"]
per = call("POST", "periodos", {"codigo": "2026", "nombre": "Año 2026", "fecha_inicio": "2026-01-01", "fecha_fin": "2026-12-31", "estado": "abierto", "unidades_presupuestadas": 2000, "empresa_id": e}, t)["id"]
mp1 = call("POST", "materias_primas", {"codigo": "MP01", "descripcion": "Pechuga de pollo", "unidad_id": kg, "unidad_estandar_id": kg, "costo_estandar": 14000, "proveedor": "Avícola del Sinú", "eficiencia_pct": 95, "stock_minimo": 10, "empresa_id": e}, t)["id"]
mp2 = call("POST", "materias_primas", {"codigo": "MP02", "descripcion": "Palitos de bambú", "unidad_id": und, "unidad_estandar_id": und, "costo_estandar": 40, "eficiencia_pct": 100, "stock_minimo": 500, "empresa_id": e}, t)["id"]
p1 = call("POST", "productos", {"codigo": "P01", "descripcion": "Pincho de pollo", "unidad_id": und, "precio_venta": 6500, "horas_mod_std": 0.05, "horas_maquina_std": 0.01, "empresa_id": e}, t)["id"]
call("POST", f"receta/{p1}", {"materia_prima_id": mp1, "cantidad_estandar": 0.12, "empresa_id": e}, t)
call("POST", f"receta/{p1}", {"materia_prima_id": mp2, "cantidad_estandar": 1, "empresa_id": e}, t)
tr = call("POST", "trabajadores", {"codigo": "T01", "nombre": "Ana Pérez", "cargo": "Operaria", "salario_mensual": 1423500, "prestaciones_pct": 22, "cargas_pct": 30, "horas_mes": 192, "empresa_id": e}, t)["id"]
bases = call("GET", f"bases_aplicacion?empresa_id={e}", None, t)
bmod = next(b["id"] for b in bases if b["codigo"] == "mano_obra_directa")
bund = next(b["id"] for b in bases if b["codigo"] == "unidades_producidas")
c1 = call("POST", "cif_conceptos", {"codigo": "CIF01", "descripcion": "Energía y gas", "tipo": "variable", "base_aplicacion_id": bmod, "presupuestado": 600000, "real": 0, "empresa_id": e}, t)["id"]
c2 = call("POST", "cif_conceptos", {"codigo": "CIF02", "descripcion": "Arriendo del local", "tipo": "fijo", "base_aplicacion_id": bund, "presupuestado": 1800000, "real": 0, "empresa_id": e}, t)["id"]
call("POST", "inventario/movimientos", {"materia_prima_id": mp1, "tipo": "entrada", "cantidad": 40, "costo_unitario": 13800, "fecha": "2026-03-01", "nota": "Factura 551", "empresa_id": e}, t)
call("POST", "inventario/movimientos", {"materia_prima_id": mp2, "tipo": "entrada", "cantidad": 800, "costo_unitario": 38, "fecha": "2026-03-01", "empresa_id": e}, t)
o = call("POST", "ordenes", {"numero": "OP-001", "producto_id": p1, "periodo_id": per, "fecha": "2026-03-05", "cantidad_planeada": 200, "empresa_id": e}, t)["id"]
call("POST", f"ordenes/{o}/consumo", {"materia_prima_id": mp1, "cantidad_real": 25.5, "precio_real": 14200, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/consumo", {"materia_prima_id": mp2, "cantidad_real": 205, "precio_real": 40, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/mod", {"trabajador_id": tr, "horas_reales": 11, "tarifa_real": 11500, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cif", {"concepto_id": c1, "monto_real": 70000, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cif", {"concepto_id": c2, "monto_real": 180000, "empresa_id": e}, t)
call("POST", f"ordenes/{o}/cerrar", {"cantidad_producida": 200, "horas_maquina_reales": 2, "empresa_id": e}, t)


errores, fallos = [], []
def check(cond, texto):
    (print("  ✓", texto) if cond else (fallos.append(texto), print("  ✗", texto)))
with sync_playwright() as p:
    b = p.chromium.launch()
    ctx = b.new_context(viewport={"width": 1400, "height": 860}, accept_downloads=True)
    pg = ctx.new_page()
    pg.on("pageerror", lambda ex: errores.append(f"pageerror: {ex}"))
    pg.on("console", lambda m: m.type == "error" and errores.append(f"console: {m.text}"))
    pg.goto(URL)
    pg.fill("#login-usuario", "admin"); pg.fill("#login-clave", "admin123")
    pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.8)
    pg.click("text=Más tarde"); time.sleep(0.3)

    print("Menú lateral")
    pg.evaluate("document.querySelector('.lateral').scrollTop = 9999"); time.sleep(0.2)
    check(pg.is_visible("#menu button[data-item='respaldo']"), "Respaldo alcanzable en el menú (desplazando)")
    pg.screenshot(path="capturas_prueba/a_menu_abajo.png")
    pg.evaluate("document.querySelector('.lateral').scrollTop = 0")

    print("Aviso de contraseña de fábrica")
    check(pg.is_visible("#aviso-clave"), "aviso visible sobre el contenido")

    print("Concordancia de género")
    pg.click("#menu button[data-item='empresas']"); time.sleep(0.5)
    check(pg.inner_text(".mod-cabeza button.primario") == "Nueva empresa", "botón dice «Nueva empresa»")
    pg.click("#menu button[data-item='productos']"); time.sleep(0.5)
    check(pg.inner_text(".mod-cabeza button.primario") == "Nuevo producto", "botón dice «Nuevo producto»")

    print("Buscador")
    pg.click("#menu button[data-item='materias_primas']"); time.sleep(0.5)
    pg.fill(".buscador", "bambú"); time.sleep(0.3)
    filas = pg.locator("#contenido tbody tr").count()
    check(filas == 1, f"filtra a 1 resultado (hay {filas})")
    check("1 de 2" in pg.inner_text(".contador"), "contador «1 de 2»")
    pg.fill(".buscador", "zzz"); time.sleep(0.3)
    check("Ningún registro coincide" in pg.inner_text("#contenido"), "mensaje cuando no hay coincidencias")

    print("Crear desde el formulario")
    pg.click("text=Nueva materia prima"); time.sleep(0.3)
    pg.fill(".campo[data-campo=codigo] input", "MP03")
    pg.fill(".campo[data-campo=descripcion] input", "Salsa BBQ")
    pg.select_option(".campo[data-campo=unidad_id] select", index=1)
    pg.select_option(".campo[data-campo=unidad_estandar_id] select", index=1)
    pg.fill(".campo[data-campo=costo_estandar] input", "-5")
    pg.click("#btn-guardar"); time.sleep(0.4)
    check("negativo" in pg.inner_text(".campo[data-campo=costo_estandar]"), "valida número negativo junto al campo")
    pg.fill(".campo[data-campo=costo_estandar] input", "9000")
    pg.click("#btn-guardar"); time.sleep(0.6)
    check("Materia prima creada." in pg.inner_text("#mensajes"), "mensaje «Materia prima creada.»")

    print("Inventario: movimiento desde el modal")
    pg.click("#menu button[data-item='inventario']"); time.sleep(0.6)
    pg.click("text=Registrar movimiento"); time.sleep(0.3)
    check(pg.is_visible(".campo[data-campo=costo_unitario]"), "entrada pide costo unitario")
    pg.select_option(".campo[data-campo=tipo] select", "salida"); time.sleep(0.2)
    check(not pg.is_visible(".campo[data-campo=costo_unitario]"), "salida oculta el costo (usa promedio)")
    pg.fill(".campo[data-campo=cantidad] input", "5"); pg.click("#btn-mov"); time.sleep(0.8)
    txt = pg.inner_text("#contenido")
    check("9,5" in txt, "existencias de pollo bajan de 14,5 a 9,5")
    check("Reponer" in txt and "Por debajo de la existencia mínima" in txt, "alerta de reposición (mínimo 10)")
    pg.screenshot(path="capturas_prueba/b_inventario.png", full_page=True)
    pg.click("#contenido tbody tr:first-child >> text=Kardex"); time.sleep(0.6)
    check(pg.locator("#contenido tbody tr").count() == 3, "kardex con 3 movimientos (compra, orden, salida)")

    print("Hoja de costo: margen deseado")
    pg.click("#menu button[data-item='hoja_costo']"); time.sleep(0.8)
    check("471 unidades" in pg.inner_text("#contenido"), "punto de equilibrio redondeado a 471 unidades")
    pg.fill(".panel input[type=number][max='95']", "40"); time.sleep(0.3)
    check("5.953,15" in pg.inner_text("#contenido"), "precio sugerido con 40 % = $ 5.953,15")
    pg.screenshot(path="capturas_prueba/c_hoja_costo.png", full_page=True)

    print("Dashboard")
    pg.click("#menu button[data-item='dashboard']"); time.sleep(0.8)
    check(pg.locator("#contenido svg rect").count() == 2, "gráfico con 2 barras (estándar y real)")
    pg.screenshot(path="capturas_prueba/d_dashboard.png", full_page=True)

    print("Respaldo desde el botón")
    pg.click("#menu button[data-item='respaldo']"); time.sleep(0.5)
    with pg.expect_download() as d:
        pg.click("text=Descargar respaldo ahora")
    ruta = d.value.path(); nombre = d.value.suggested_filename
    check(open(ruta, "rb").read(16) == b"SQLite format 3\x00" and nombre.endswith(".db"), f"descarga {nombre}")
    pg.screenshot(path="capturas_prueba/e_respaldo.png", full_page=True)

    print("Reporte Excel desde el botón")
    pg.click("#menu button[data-item='reportes']"); time.sleep(0.5)
    with pg.expect_download() as d:
        pg.locator("#contenido tbody tr:first-child").get_by_role("button", name="Excel", exact=True).click()
    check(d.value.suggested_filename.endswith(".xlsx") and open(d.value.path(), "rb").read(2) == b"PK", f"descarga {d.value.suggested_filename}")
    pg.locator("#contenido tbody tr:first-child").get_by_role("button", name="Vista previa", exact=True).click(); time.sleep(0.6)
    check("P01" in pg.inner_text("#zona-impresion"), "vista imprimible muestra datos legibles")

    print("Cambio de contraseña")
    pg.click("#btn-clave"); time.sleep(0.3)
    pg.fill(".campo[data-campo=actual] input", "admin123")
    pg.fill(".campo[data-campo=nueva] input", "Clave2026!")
    pg.fill(".campo[data-campo=repetir] input", "otra")
    pg.click("#btn-clave-guardar" if pg.locator("#btn-clave-guardar").count() else "#modal #btn-clave"); time.sleep(0.3)
    check("no coinciden" in pg.inner_text("#modal"), "detecta que las contraseñas no coinciden")
    pg.fill(".campo[data-campo=repetir] input", "Clave2026!")
    pg.click("#modal #btn-clave"); time.sleep(0.6)
    check("Contraseña actualizada." in pg.inner_text("#mensajes"), "contraseña actualizada")
    pg.click("#menu button[data-item='empresas']"); time.sleep(0.4)
    check(not pg.is_visible("#aviso-clave"), "el aviso ya no reaparece al navegar")
    pg.click("#btn-salir"); time.sleep(0.8)
    pg.fill("#login-usuario", "admin"); pg.fill("#login-clave", "Clave2026!")
    pg.click("#form-login button[type=submit]"); pg.wait_for_selector("#app:not(.oculto)"); time.sleep(0.6)
    check(not pg.is_visible("#modal-fondo:not(.oculto)") and not pg.is_visible("#aviso-clave"), "entra con la nueva clave, sin avisos")

    print("Pantalla pequeña (portátil 1280x720)")
    pg.set_viewport_size({"width": 1280, "height": 720}); time.sleep(0.3)
    pg.screenshot(path="capturas_prueba/f_1280.png")
    b.close()
srv.shutdown()
print("ERRORES JS:", errores or "ninguno")
print("FALLOS:", fallos or "ninguno")
